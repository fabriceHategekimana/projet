<?php
//put sha1() encrypted password here - example is 'hello'
$password = '5324fe91536f2bea3b26c930f64eedffa223a9db';
//$password = 'e88ca6592d43c77a05b17c3023dcd06093c61647';

session_start();
if (!isset($_SESSION['loggedIn'])) {
    $_SESSION['loggedIn'] = false;
}

if (isset($_POST['password'])) {
    if (sha1($_POST['password']) == $password) {
        $_SESSION['loggedIn'] = true;
    } else {
        die ('Incorrect password');
    }
} 

if (!$_SESSION['loggedIn']): ?>

<html>
<head><title>C-SAW Login</title>
<script language="javascript" src="essay.js" type="text/javascript" ></script>
<link href="form.css" rel="stylesheet" type="text/css" /></head>
  <body>
  <div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
  <div style="margin-left:30%;margin-right:30%;padding: 3em;border: 1pt dashed #9BACB0;">
    <p>You need to login</p>
    <form method="post">
      Password: <input type="password" name="password"/> <br />
      <input type="submit" name="submit" value="Login" class="buttonText"/>
    </form>
    </div>
  </body>
</html>

<?php
exit();
endif;
?>

