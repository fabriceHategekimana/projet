<?php

/* by kalli benetos
Argumentative essay online tool
April 2014
*/

session_start();
error_reporting(E_ALL);

// FROM  http://php.net/manual/en/security.magicquotes.disabling.php
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}

header ("Content-type: application/xhtml+xml");

//HTML global display page functions

function recordTime() {
time();
echo date("d/m/y : H:i:s", time());
}

function head() {
echo '<?xml version="1.0" encoding="ISO-8859-1" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg">
<head><meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>Text view with help</title>
<script language="javascript" src="essay.js" type="text/javascript" />';
// order log/log.js loading, this client-side script defines functions
// to log user's activity
echo '<script language="javascript" src="log/log.js" type="text/javascript"/>';

echo '<link href="form.css" rel="stylesheet" type="text/css" />
</head><body><p align="right"><a href="javascript:window.print();" class="buttonText"><img src="../graphics/print.png" alt="print text" title="print text"/></a><a href="javascript:window.close();"><span class="buttonText"><img src="../graphics/close.png" title="close window"/></span></a>
<a href="javascript:location.reload(true)"><span class="buttonText"><img src="../graphics/refresh.png" title="refresh"/></span></a></p>';}

function footer()
{echo '<br/><br/></body></html>';}

// loading the source xml file
$file = basename($_POST['toPopFile']);

$dom = new domDocument;
if (file_exists($file)) {
	$dom->load($file);
} else {
	exit('Errorr !. Could not load file');
}
$dom = ($dom);
$root = $dom->getElementsByTagName('root');
$arguments =  $dom->getElementsByTagName('arguments');


//html header
head();

//-----------NAME ------------------------------------------------
// name - displays contents only
function nameDisplay($dom){
	$heading = $dom->getElementsByTagName('heading');
foreach ($heading as $head){
	$author=$head->getElementsByTagName('author')->item(0);
	$first_name = $author->getElementsByTagName('first_name')->item(0);
	$last_name = $author->getElementsByTagName('last_name')->item(0);

	echo '<p><legend class="txtBold">Text view with help text</legend></p>
		<p class="content">
		', $first_name->nodeValue ,'
		', $last_name->nodeValue ,'
		</p>';
	}
}

// title - displays content and editing form fields
function titleDisplay($dom){
		$heading = $dom->getElementsByTagName('heading');

	foreach ($heading as $head){
		$author=$head->getElementsByTagName('author')->item(0);
		$essay_title = $head->getElementsByTagName('essay_title')->item(0);
		$title = $essay_title->getElementsByTagName('title')->item(0);
		$subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
		$date = $essay_title->getElementsByTagName('date')->item(0);
		// labels and help
		$essay_titleLabel = $essay_title->getAttribute('label');
		$titleLabel = $title->getAttribute('label');
		$titleHelp = $title->getAttribute('help');
		$subtitleLabel = $subtitle->getAttribute('label');
		$subtitleHelp = $subtitle->getAttribute('help');
		$dateLabel = $date->getAttribute('label');

	echo '<legend class="instruct">'.$essay_titleLabel.'</legend>
		<table width="100%"  border="0" cellpadding="3" cellspacing="0">
		<tr>	<td valign="top" width="65%" class="content">
		<label for="title" class="boxInst">';
	printf('<a class="tip title-help" href="javascript: toggleLabel(\'title\')"><img src="../graphics/help.png" alt="help" border="0" />'.$titleLabel.'</a>');
	echo '</label><span id="title" class="boxPop " style="display:none">'.$titleHelp.'';
	printf('<a class="tip title-help" href="javascript: toggleLabel(\'title\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $title->nodeValue ,'<br/>
		<label for="subtitle" class="boxInst">';
	printf('<a class="tip subtitle-help" href="javascript: toggleLabel(\'subtitle\')"><img src="../graphics/help.png" alt="help" border="0" />'.$subtitleLabel.'</a>');
	echo '</label><span id="subtitle" class="boxPop" style="display:none">'.$subtitleHelp.'';
	printf('<a class="tip subtitle-help" href="javascript: toggleLabel(\'subtitle\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $subtitle->nodeValue ,'<br/>
		<label for="date" class="boxInst">'.$dateLabel.'</label> ', $date->nodeValue ,'
		</td></tr></table>';
		}
}


// --------INTRODUCTION------------------------------------
// introduction - displays current entries with help
function introDisplay($dom){
	$introduction = $dom->getElementsByTagName('introduction');

foreach ($introduction as $intro){
	$thesis=$intro->getElementsByTagName('thesis')->item(0);
	$state_thesis = $thesis->getElementsByTagName('state_thesis')->item(0);
	$outline = $thesis->getElementsByTagName('outline')->item(0);
	$importance = $outline->getElementsByTagName('importance')->item(0);
	$conflict = $outline->getElementsByTagName('conflict')->item(0);
	$solution = $outline->getElementsByTagName('solution')->item(0);

	// Labels and help
	$introLabel=$intro->getAttribute('label');
	$state_thesisLabel = $state_thesis->getAttribute('label');
	$state_thesisHelp = $state_thesis->getAttribute('help');
	$importanceLabel = $importance->getAttribute('label');
	$importanceHelp = $importance->getAttribute('help');
	$conflictLabel = $conflict->getAttribute('label');
	$conflictHelp = $conflict->getAttribute('help');
	$solutionLabel = $solution->getAttribute('label');
	$solutionHelp = $solution->getAttribute('help');

	echo '<legend class="instruct">'.$introLabel.'</legend>
			<table border="0" cellpadding="3" cellspacing="0" width="100%">
				<tr><td valign="top" width="65%" class="content">
				<label for="state_thesis" class="boxInst">
					<a  class="tip intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/help.png" alt="help" border="0" />'.$state_thesisLabel.'</a>
					</label><span id="state_thesis" class="boxPop" style="display:none"> '.$state_thesisHelp.'
					<a class="tip intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/close.png"  alt="close" border="0" /></a>
					</span> ', $state_thesis->nodeValue ,' <label for="importance" class="boxInst">';
					printf('<a class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img src="../graphics/help.png" alt="help" border="0" />'.$importanceLabel.'</a>');
					echo '</label><span id="importance" class="boxPop" style="display:none">'.$importanceHelp.'';
					printf('<a class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img src="../graphics/close.png" border="0" /></a>');
					echo '</span> ', $importance->nodeValue ,'&#160;	<label for="conflict" class="boxInst">';
					printf('<a class="tip intro-conflict-help" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/help.png" alt="help" border="0" />'.$conflictLabel.'</a>');
					echo '</label><span id="conflict" class="boxPop" style="display:none">'.$conflictHelp.'';
					printf('<a class="tip intro-conflict-help" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/close.png" border="0" /></a>');
					echo '</span> ', $conflict->nodeValue ,' <label for="solution" class="boxInst">';
					printf('<a class="tip intro-solution-help" href="javascript: toggleLabel(\'solution\')"><img src="../graphics/help.png" alt="help" border="0" />'.$solutionLabel.'</a>');
					echo '</label><span id="solution" class="boxPop" style="display:none">'.$solutionHelp.'<a class="tip intro-solution-help" href="javascript: toggleLabel(\'solution\')">
						<img src="../graphics/close.png" border="0" /></a> </span> ', $solution->nodeValue ,'
				</td></tr></table>';
		}
}

// ARGUMENT - displays current entries and offers edit, move, add and delete options
function argDisplay($dom){
	$argument = $dom->getElementsByTagName('argument');

foreach ($argument as $arg){
	$id=$arg->getAttribute('id');
	 $argHelp=$arg->getAttribute('help');
	//simple_argument contents
	$simpleArg=$arg->getElementsByTagName('simple_argument')->item(0);

	// for checkbox and svg as grey
        $simple_status=$simpleArg->getAttribute('status'); // for on/off class

	$rating=$simpleArg->getAttribute('rating');
	$stateArg = $arg->getElementsByTagName('state_argument')->item(0);
	$support = $arg->getElementsByTagName('support')->item(0);
		$type=$support->getAttribute('type');
		$source=$support->getAttribute('source');
	$relate = $arg->getElementsByTagName('relate')->item(0);
	//counterargument contents
	$counterArg=$arg->getElementsByTagName('counterargument')->item(0);
	$stateCounterArg=$arg->getElementsByTagName('state_counterargument')->item(0);
		$attackType=$stateCounterArg->getAttribute('attack_type');
		$counter_rating = $stateCounterArg->getAttribute('rating');
	// for checkbox and svg as grey
        $counter_status = $counterArg->getAttribute('status'); // for on/off class

	$comeback=$arg->getElementsByTagName('comeback')->item(0);
	$strategy=$comeback->getAttribute('strategy');
	$comeback_rating = $comeback->getAttribute('rating');
	$response = $comeback->getAttribute('response');

	$concluClaim=$arg->getElementsByTagName('concluClaim')->item(0);
	$concluClaimType=$concluClaim->getAttribute('revise');
	$concluClaim_rating = $concluClaim->getAttribute('rating');

	// labels and help
     $argumentLabel=$arg->getAttribute('label');
        $simpleArgLabel=$simpleArg->getAttribute('label');
        $simpleArgHelp=$simpleArg->getAttribute('help');
        $simpleArgRatingLabel =$simpleArg->getAttribute('ratingLabel');

        $stateArgLabel = $stateArg->getAttribute('label');
        $stateArgHelp = $stateArg->getAttribute('help');
        $argTypeLabel = $stateArg->getAttribute('argTypeLabel');
        $argType=$stateArg->getAttribute('type');
        $argTypeHelp= $stateArg->getAttribute('typeHelp');
        $stateArgConnectTitle = $stateArg->getAttribute('connectiveTitle');
        $stateArgConnect = $stateArg->getAttribute('connective');

        $supportLabel = $support->getAttribute('label');
        $supportHelp= $support->getAttribute('help');
        $supportConnectTitle= $support->getAttribute('connectiveTitle');
        $supportConnect= $support->getAttribute('connective');

        $sourceLabel= $support->getAttribute('sourceLabel');
        $sourceHelp= $support->getAttribute('sourceHelp');
        $source= $support->getAttribute('source');
        $relateLabel = $relate->getAttribute('label');
        $relateHelp = $relate->getAttribute('help');
        $relateConnectTitle = $relate->getAttribute('connectiveTitle');
        $relateConnect = $relate->getAttribute('connective');

        $counterArgLabel = $counterArg->getAttribute('label');
        $counterArgHelp = $counterArg->getAttribute('help');

        $stateCounterArgLabel = $stateCounterArg->getAttribute('label');
        $stateCounterArgHelp = $stateCounterArg->getAttribute('help');
        $stateCounterArgConnectTitle = $stateCounterArg->getAttribute('connectiveTitle');
        $stateCounterArgConnect = $stateCounterArg->getAttribute('connective');

        $counterArgRatingLabel =$stateCounterArg->getAttribute('ratingLabel');

        $attackType = $stateCounterArg->getAttribute('attack_type');
        $attackTypeLabel = $stateCounterArg->getAttribute('attackTypeLabel');
        $attackTypeHelp = $stateCounterArg->getAttribute('attackHelp');

        $comebackLabel = $comeback->getAttribute('label');
        $comebackHelp = $comeback->getAttribute('help');
        $comebackConnectTitle = $comeback->getAttribute('connectiveTitle');
        $comebackConnect = $comeback->getAttribute('connective');
        $responseHelp = $comeback->getAttribute('responseHelp');
        $responseTypeLabel = $comeback->getAttribute('responseTypeLabel');
        $responseType = $comeback->getAttribute('response');
        $strategyTypeLabel = $comeback->getAttribute('strategyTypeLabel');
        $strategyType = $comeback->getAttribute('strategy');
        $strategyHelp = $comeback->getAttribute('strategyHelp');
                            $comebackRatingLabel =$comeback->getAttribute('ratingLabel');

        $concluClaimLabel = $concluClaim->getAttribute('label');
        $concluClaimHelp = $concluClaim->getAttribute('help');
        $concluClaimConnectTitle = $concluClaim->getAttribute('connectiveTitle');
        $concluClaimConnect = $concluClaim->getAttribute('connective');
        $reviseTypeLabel = $concluClaim->getAttribute('reviseTypeLabel');
        $reviseType = $concluClaim->getAttribute('revise');
        $reviseHelp = $concluClaim->getAttribute('reviseHelp');
                         $concluRatingLabel =$concluClaim->getAttribute('ratingLabel');

	echo '<br/>';

//	echo '<label for="id" class="instruct">argument no.:</label> '.$id.'<br/>';
	echo '<legend class="instruct">';
	printf ('<a class="genTip arg-help" href="javascript: toggleLabel(\'argument'.$id.'\')"><img src="../graphics/help.png" alt="help" border="0" />'.$argumentLabel.'</a>'.$id.'');
	echo '</legend><span id="argument'.$id.'" class="boxPop" style="display:none">'.$argHelp.'';
	printf ('<a class="genTip arg-help" href="javascript: toggleLabel(\'argument'.$id.'\')"><img src="../graphics/close.png" border="0" /></a></span>');
	echo'<table width="100%" border="1" cellspacing="0" cellpadding="3">
		<tr>	<td align="left" valign="top" width="65%" class="'.$simple_status.'Print">';
		echo '<legend class="instruct">'.$simpleArgLabel.'</legend>
			<label for="state_argument" class="boxInst">';
		printf ('<a class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$stateArgLabel.'</a>');
		echo '</label><span id="state_argument'.$id.'" class="boxPop" style="display:none">'.$stateArgHelp.'';
		printf ('<a class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span> ', $stateArg->nodeValue ,' <label for="support" class="boxInst">';
		printf ('<a class="tip arg-s-support-help" href="javascript: toggleLabel(\'support'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$supportLabel.' </a>');
		echo '</label>
			<span id="support'.$id.'" class="boxPop" style="display:none"> '.$supportHelp.'';
		printf ('<a class="tip arg-s-support-help" href="javascript: toggleLabel(\'support'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span>' , $support->nodeValue,' <label for="type" class="boxInst">';
		printf ('<a class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$argTypeLabel.'</a>');
		echo '</label><span id="type'.$id.'" class="boxPop" style="display:none"> '.$argTypeHelp.'';
		printf ('<a class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span><span class="txt"> ', $type ,'</span> <label for="source" class="boxInst">';
		printf ('<a class="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$sourceLabel.'</a>');
		echo '</label><span id="source'.$id.'" class="boxPop" style="display:none"> '.$sourceHelp.'';
		printf ('<a lass="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span><span class="txt"> ', $source ,'</span> <label for="relate" class="boxInst">';
		printf ('<a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$relateLabel.'</a>');
		echo '</label> <span id="relate'.$id.'" class="boxPop" style="display:none">'.$relateHelp.'';
		printf ('<a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span>', $relate->nodeValue ,'<br />
		<label for="id" class="instruct">&#160;&#160;&#160;'.$simpleArgRatingLabel.'</label> '.$rating.'
			</td></tr>
			<tr><td class="'.$counter_status.'Print">';
		echo '<legend class="instruct">'.$counterArgLabel.'</legend>
			<label for="state_counterargument" class="boxInst">';
		printf ('<a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$stateCounterArgLabel.'</a>');
		echo '</label> <span id="state_counterargument'.$id.'" class="boxPop" style="display:none">'.$stateCounterArgHelp.'';
		printf ('<a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span>', $stateCounterArg->nodeValue , '
			<label for="attack_type" class="boxInst">';
		printf ('<a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$attackTypeLabel.'</a>');
		echo '</label><span id="attack_type'.$id.'" class="boxPop" style="display:none">'.$attackTypeHelp.'';
		printf ('<a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span> ', $attackType ,' <br/><label for="comeback" class="boxInst">';
		printf ('<a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$comebackLabel.'</a>');
		echo '</label> <span id="comeback'.$id.'" class="boxPop" style="display:none">'.$comebackHelp.'';
		printf ('<a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"><img src="../graphics/close.png" border="0" /></a>');
		echo '</span>', $comeback->nodeValue ,'';

		printf ('<br/><label for="response" class="boxInst">
		        <a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$responseTypeLabel.'</a>
		        <span id="response'.$id.'" class="boxPop" style="display:none">'.$responseHelp.'
		        <a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"><img src="../graphics/close.png" border="0" /></a></span>');
		echo '</label><span class="txt"> ', $response ,' </span>';

		printf ('<label for="strategy" class="boxInst">
		        <span id="strategy'.$id.'" class="boxPop" style="display:none">'.$strategyHelp.'
		        <a class="tip arg-c-strategy-help" href="javascript: toggleLabel(\'strategy'.$id.'\')"><img src="../graphics/close.png" border="0" /></a></span>');
		echo '</label><br/>
			<span class="instruct">'.$strategyTypeLabel.'</span><span class="txt"> ', $strategy ,' </span>';



		echo '<br/>
			<label for="revise" class="boxInst">';
		printf ('<a class="tip arg-c-concluClaim-help" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"> <img src="../graphics/help.png" alt="help" border="0" />'.$concluClaimLabel.'</a>', $concluClaim->nodeValue ,'
		        <br/><span id="concluClaim'.$id.'" class="boxPop" style="display:none">'.$reviseHelp.'
		        <a class="tip arg-c-concluClaim-help" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"><img src="../graphics/close.png" border="0" /></a></span>');
		echo '</label>
			<span class="instruct">'.$reviseTypeLabel.'</span><span class="txt"> ', $concluClaimType ,' </span>
			';
		printf ('');
		echo '<br/>
		        <label class="instruct">'.$counterArgRatingLabel.' </label> '.$counter_rating.'<br/>
			<label class="instruct"> '.$comebackRatingLabel.' </label> '.$comeback_rating.'<br/>
			<label class="instruct"> '.$concluRatingLabel.' </label> '.$concluClaim_rating.'';

		echo '	</td></tr></table>';
		}
}

// CONCLUSION -------------------------------------------------------
function conDisplay($dom){
	$conclusion = $dom->getElementsByTagName('conclusion');

foreach ($conclusion as $con){
	$thesis_summary=$con->getElementsByTagName('thesis_summary')->item(0);
	$argument_summary = $con->getElementsByTagName('argument_summary')->item(0);
	$consequences = $con->getElementsByTagName('consequences')->item(0);
	$closing = $con->getElementsByTagName('closing')->item(0);
	$noteCon = $con->getElementsByTagName('notepad')->item(0);

	$argument_summaryHelp = $argument_summary->getAttribute('help');


	echo '<br /><legend class="instruct">conclusion</legend>
		<table width="100%" border="0" cellspacing="0" cellpadding="3">
		<tr><td valign="top" width="65%" class="content">
		<label for="thesis_summary" class="boxInst">';
	printf('<a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/help.png" alt="help" border="0" />thesis summary</a>');
	echo '</label><span id="thesis_summary" class="boxPop" style="display:none">Summarize your main point taking your arguments into account.';
	printf('<a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $thesis_summary->nodeValue ,'	 <label for="arguments_summaries" class="boxInst">';
	printf ('<a class="tip conclusion-args-help" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/help.png" alt="help" border="0" />summarize main arguments</a>');
	echo '</label><span id="arguments_summaries" class="boxPop" style="display:none">'.$argument_summaryHelp.'';
	printf ('<a class="tip conclusion-args-help" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $argument_summary->nodeValue ,' <label for="consequences" class="boxInst">';
	printf ('<a class="tip conclusion-conseq-help" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/help.png" alt="help" border="0" />consequences*</a>');
	echo '</label><span id="consequences" class="boxPop" style="display:none">Give one or two consequences if your point of view is not adopted by others. Warn of
		what may happen if your point of view is ignored. *This is optional.';
	printf ('<a class="tip conclusion-conseq-help" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $consequences->nodeValue ,' <label for="closing" class="boxInst">';
	printf ('<a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/help.png" alt="help" border="0" />closing</a>');
	echo '</label><span id="closing" class="boxPop" style="display:none"> Write a closing statement. This could be a final remark, a further question,
		a final conclusion that may in the end be different from you original thesis.';
	printf ('<a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/close.png" border="0" /></a>');
	echo '</span> ', $closing->nodeValue ,'
		</td>
		</tr></table>';
	}
}

nameDisplay($dom);
titleDisplay($dom);
introDisplay($dom);
argDisplay($dom);
conDisplay($dom);

footer();
?>
