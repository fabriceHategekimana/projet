<?php

/* by kalli benetos
Argumentative essay online tool
August 2012
*/
//phpinfo();
session_start();
error_reporting(E_ALL);

// FROM  http://php.net/manual/en/security.magicquotes.disabling.php
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}


header ("Content-type: application/xhtml+xml");
//HTML display functions
function head() {
echo '<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg">
<head><meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>Print view of essay</title>
<script language="javascript" src="essay.js" type="text/javascript" />
<link href="print.css" rel="stylesheet" type="text/css" />
</head><body><div style="width:680px;margin-left:auto;margin-right:auto;border: 1px dashed #98A48A;padding: 3em;">
<p align="right"><a href="javascript:window.print();" class="buttonText"><img src="../graphics/print.png" alt="print text" title="imprimer"/></a>
&#13;<a href="javascript:window.close();" class="buttonText"><img src="../graphics/close.png" title="fermer cette fenêtre"/></a>
<a href="javascript:location.reload(true)" class="buttonText"><img src="../graphics/refresh.png" title="recharger le texte"/></a>
</p>';
}

function footer() {echo '</div></body></html>';}

// loading the source xml file
//file = 'essay.xml';
$file = basename($_POST['toPopFile']);

$dom = new domDocument;
if (file_exists($file)) {
	$dom->load($file);
} else {
	exit('Error ! xml file not found.');
}
$dom = ($dom);
$root = $dom->getElementsByTagName('root');
$arguments =  $dom->getElementsByTagName('arguments');


//html header
head();

//-----------NAME ------------------------------------------------

// name - displays contents only
function nameDisplay($dom){
	$heading = $dom->getElementsByTagName('heading');
foreach ($heading as $head){
	$author=$head->getElementsByTagName('author')->item(0);
	$first_name = $author->getElementsByTagName('first_name')->item(0);
	$last_name = $author->getElementsByTagName('last_name')->item(0);

	echo '<p class="content">
		', $first_name->nodeValue ,'
		', $last_name->nodeValue ,'
		</p>';
	}
}

//------TITLE--------------------------------------------------------
// title - displays contents only
function titleDisplay($dom){
		$heading = $dom->getElementsByTagName('heading');

	foreach ($heading as $head){
		$author=$head->getElementsByTagName('author')->item(0);
		$essay_title = $head->getElementsByTagName('essay_title')->item(0);
		$title = $essay_title->getElementsByTagName('title')->item(0);
		$subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
		$date = $essay_title->getElementsByTagName('date')->item(0);
		$noteHead = $head->getElementsByTagName('notepad')->item(0);

	echo ' <h2 align="center">', $title->nodeValue ,'</h2>
		<h3 align="center">
		', $subtitle->nodeValue ,'<br/></h3>
		<p class="content"> ', $date->nodeValue ,'</p>';
		}
}
//------INTRODUCTION--------------------------------------------------------
// introduction - displays current text only
function introDisplay($dom){
	$introduction = $dom->getElementsByTagName('introduction');

foreach ($introduction as $intro){
	$thesis=$intro->getElementsByTagName('thesis')->item(0);
	$state_thesis = $thesis->getElementsByTagName('state_thesis')->item(0);
	$outline = $thesis->getElementsByTagName('outline')->item(0);
	$importance = $outline->getElementsByTagName('importance')->item(0);
	$conflict = $outline->getElementsByTagName('conflict')->item(0);
	$solution = $outline->getElementsByTagName('solution')->item(0);
	$noteIntro = $intro->getElementsByTagName('notepad')->item(0);

	echo '
		<p class="content">', $state_thesis->nodeValue ,' ', $importance->nodeValue ,' ', $conflict->nodeValue ,' ', $solution->nodeValue ,'</p>';
		}
}

//-----------ARGUMENTS ------------------------------------------------
function argDisplay($dom){
	$argument = $dom->getElementsByTagName('argument');

foreach ($argument as $arg){
	$id=$arg->getAttribute('id');
	$rating=$arg->getAttribute('rating');
	//simple_argument contents
	$simpleArg=$arg->getElementsByTagName('simple_argument')->item(0);
	$stateArg = $arg->getElementsByTagName('state_argument')->item(0);
	$support = $arg->getElementsByTagName('support')->item(0);
		$type=$support->getAttribute('type');
		$source=$support->getAttribute('source');
	$relate = $arg->getElementsByTagName('relate')->item(0);
	//counterargument contents
	$counterArg=$arg->getElementsByTagName('counterargument')->item(0);
	$stateCounterArg=$arg->getElementsByTagName('state_counterargument')->item(0);
		$attackType=$stateCounterArg->getAttribute('attack_type');
	$comeback=$arg->getElementsByTagName('comeback')->item(0);
	$strategy=$comeback->getAttribute('strategy');
	$noteArg = $arg->getElementsByTagName('notepad')->item(0);

	$concluClaim=$arg->getElementsByTagName('concluClaim')->item(0);


	    // for checkbox and svg as grey
        $simple_status=$simpleArg->getAttribute('status'); // for checkbox and svg as grey
        $counter_status = $counterArg->getAttribute('status');


	echo '<p ><span class="'.$simple_status.'Print">', $stateArg->nodeValue ,'
	' , $support->nodeValue,'';
	// source print
	echo'',$source,'';
	echo '', $relate->nodeValue,'</span>
	<span class="'.$counter_status.'Print">', $stateCounterArg->nodeValue , '
	', $comeback->nodeValue ,'', $concluClaim->nodeValue ,'</span></p>';
	}

}


//-----------CONCLUSION ------------------------------------------------

// conclusion - displays text only
function conDisplay($dom){
	$conclusion = $dom->getElementsByTagName('conclusion');

foreach ($conclusion as $con){
	$thesis_summary=$con->getElementsByTagName('thesis_summary')->item(0);
	$argument_summary = $con->getElementsByTagName('argument_summary')->item(0);
	$consequences = $con->getElementsByTagName('consequences')->item(0);
	$closing = $con->getElementsByTagName('closing')->item(0);
	$noteCon = $con->getElementsByTagName('notepad')->item(0);

	echo ' <p class="content">', $thesis_summary->nodeValue ,'
		', $argument_summary->nodeValue ,'
		', $consequences->nodeValue ,'
		', $closing->nodeValue ,'</p>';
	}
}

// show appropriate display (edit form or text view)
nameDisplay($dom);
titleDisplay($dom);
introDisplay($dom);
argDisplay($dom);
conDisplay($dom);
footer();
?>
