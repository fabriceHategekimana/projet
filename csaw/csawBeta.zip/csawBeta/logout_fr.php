<?php
    session_start();
    $_SESSION['loggedIn'] = false;
?>

<html><head>
<meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>Login</title>
<script language="javascript" src="essay.js" type="text/javascript"></script>
<link href="form.css" rel="stylesheet" type="text/css" /></head>
  <body>
  <div style="position: absolute; left: 8%;top: 20px;"><img src="../graphics/logo.png" alt="csaw"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
<div style="margin-left:30%;margin-right:30%;padding: 3em;border: 1pt dashed #9BACB0;">
    <p>Vous êtes déconnecté. <br /><br />Vous pouvez <a href="start_fr.php" class="buttonText">vous&#160;connecter</a> à nouveau.</p>

  </div></body>
</html>
