<?xml version="1.0" ?>
<xsl:stylesheet version="1.0" xmlns:xsl="http://www.w3.org/1999/XSL/Transform">
  <xsl:output method="html" />
  <xsl:key name="source" match="event" use="@source" />
  <xsl:template match="/events">
    <html>
      <head>
        <title>CSAW log</title>
        <!--
        no date format function is available in XSLT 1.0
        string replacement function isn't available in XSLT 1.0
        javascript is used instead
        -->
        <script type="text/javascript" src="../jquery-1.8.1.min.js"></script>
        <script type="text/javascript">
        $("body").ready(function() {
          $(".source").each(function() {
            $(this).html($(this).html().replace("-", "&#8209;"));
          });
          $(".datetime").each(function() {
            var date = new Date($(this).html() * 1000);
            $(this).html(date.toUTCString().replace(/\s/g, '&#160;'));
          });
          $("script").remove();
        });
        </script>
        <style type="text/css">
        /* padding, margin, sizing */
        td, th {
          padding: 5px;
        }
        table {
          border-collapse: collapse;
        }
        /* alignment */
        th {
          text-align: left;
        }
        th, td {
          vertical-align: top;
        }
        /* colors */
        tr.dark td {
          background-color: #ddd;
        }
        </style>
      </head>
      <body>
        <h1>Events</h1>
        <h2>Chronology</h2>
        <table>
          <tr>
            <th>Date/Time</th>
            <th>Source</th>
            <th>Value</th>
          </tr>
          <xsl:for-each select="//event">
            <tr>
              <xsl:attribute name="class">
                <xsl:if test="position() mod 2 = 1">dark</xsl:if>
              </xsl:attribute>
              <td class="datetime">
                <xsl:value-of select="@time" />
              </td>
              <td class="source">
                <xsl:value-of select="@source" />
              </td>
              <td>
                <xsl:value-of select="@value" />
              </td>
            </tr>
          </xsl:for-each>
        </table>
        <h2>Statistics</h2>
        <table>
          <tr>
            <th>Source</th>
            <th>Count</th>
          </tr>
          <xsl:for-each select="//event[generate-id() = generate-id(key('source', @source)[1])]">
            <tr>
              <xsl:attribute name="class">
                <xsl:if test="position() mod 2 = 1">dark</xsl:if>
              </xsl:attribute>
              <td class="source">
                <xsl:value-of select="@source" />
              </td>
              <td>
                <xsl:value-of select="count(key('source', @source))" />
              </td>
            </tr>
          </xsl:for-each>
        </table>
      </body>
    </html>
  </xsl:template>
</xsl:stylesheet>