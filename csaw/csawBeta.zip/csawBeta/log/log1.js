// this client-side script logs user's actions

// load jQuery if it's not already loaded
if (typeof jQuery === "undefined") {

  var head = document.getElementsByTagName("head")[0];
  var script = document.createElement("script");
  script.type = "text/javascript";
  script.src = "log/jquery-1.8.1.min.js";
  script.onreadystatechange = script.onload = bindEvents;
  head.appendChild(script);
} else {

  bindEvents();
}

// bind log events to links, buttons, fields, etc
function bindEvents() {

  // make aliases in order to improve the readability of this function
  var _s = singleElementSourceId;
  var _a = argumentElementSourceId;

  // make sure DOM is ready before binding the events
  $("body").ready(function() {

    // global actions
    bindClickEvent($("#user-guide"), _s("user-guide"));
    bindClickEvent($("#view-tips"), _s("view-tips"));
    bindClickEvent($("#print-view"), _s("print-view"));
    bindOpenEvent($("#load-old-essay"), _s("load-old-essay"));
    bindOpenEvent($("#save-as-new-file"), _s("save-as-new-file"));
    
    // title editing
    bindOpenEvent($("#title-edit"), _s("title-edit"));
    bindOpenEvent($(".title-help"), _s("title-help"));
    bindClickEvent($("#title-help-close"), _s("title-help-close"));
    bindClickEvent($("#subtitle-help-close"), _s("subtitle-help-close"));

    bindChangeEvent($("textarea[name=title]"), _s("title-value"));
    bindOpenEvent($(".subtitle-help"), _s("subtitle-help"));
    bindChangeEvent($("textarea[name=subtitle]"), _s("subtitle-value"));
    bindSubmitEvent($("input[name=saveTitle]"), _s("title-save"));
    bindSubmitEvent($("input[name=cancelTitle]"), _s("title-cancel"));
  
    // introduction editing
    bindOpenEvent($("#intro-edit"), _s("intro-edit"));
    bindOpenEvent($(".intro-state-help"), _s("intro-state-help"));
    bindChangeEvent($("textarea[name=state_thesis]"), _s("intro-state-value"));
    bindOpenEvent($(".intro-importance-help"), _s("intro-importance-help"));
    bindClickEvent($("#intro-importance-info"), _s("intro-importance-info"));
    bindClickEvent($("#intro-importance-help-close"), _s("intro-importance-help-close"));
    bindClickEvent($("#intro-importance-info-close"), _s("intro-importance-info-close"));   
   
    bindClickEvent($("#intro-state-help-close"), _s("intro-state-help-close"));
    bindChangeEvent($("textarea[name=importance]"), _s("intro-importance-value"));
    bindOpenEvent($(".intro-conflict-help"), _s("intro-conflict-help"));
    bindClickEvent($("#intro-conflict-help-close"), _s("intro-conflict-help-close"));    
    
    bindClickEvent($("#intro-conflict-info"), _s("intro-conflict-info"));
    bindClickEvent($("#intro-conflict-info-close"), _s("intro-conflict-info-close"));    
    
    bindChangeEvent($("textarea[name=conflict]"), _s("intro-conflict-value"));
    bindOpenEvent($(".intro-solution-help"), _s("intro-solution-help"));
    bindClickEvent($("#intro-solution-info"), _s("intro-solution-info"));
    
    bindClickEvent($("#intro-solution-help-close"), _s("intro-solution-help-close"));
    bindClickEvent($("#intro-solution-info-close"), _s("intro-solution-info-close"));
    
    bindChangeEvent($("textarea[name=solution]"), _s("intro-solution-value"));
    bindSubmitEvent($("input[name=saveIntro]"), _s("intro-save"));
    bindSubmitEvent($("input[name=cancelIntro]"), _s("intro-cancel"));
    bindOpenEvent($("#intro-preview"), _s("intro-preview"));
    bindOpenEvent($("#intro-note-edit"), _s("intro-note-edit"));
    bindChangeEvent($("textarea[name=noteIntro]"), _s("intro-note-value"));
    bindSubmitEvent($("input[name=saveIntroNote]"), _s("intro-note-save"));
    bindSubmitEvent($("#intro-note-cancel"), _s("intro-note-cancel"));
  
    // argument editing
    bindOpenEvent($(".arg-edit"), _a("arg[id]-edit"));
    bindOpenEvent($(".arg-help"), _a("arg[id]-help"));
    bindSubmitEvent($(".arg-delete1"), _a("arg[id]-delete1"));
    bindSubmitEvent($("input[name=addArg]"), _a("arg[id]-add"));
    bindSubmitEvent($("input[name=moveArgDown]"), _a("arg[id]-move-down"));
    bindOpenEvent($(".arg-preview"), _a("arg[id]-preview"));
    bindChangeEvent($("input[name=sArg]"), _a("arg[id]-s-activate"));
    bindOpenEvent($(".arg-s-state-help"), _a("arg[id]-s-state-help"));
    bindOpenEvent($(".arg-s-state-info"), _a("arg[id]-s-state-info"));
    bindClickEvent($("#arg-s-state-help-close"), _a("arg[id]-s-state-help-close"));
    bindClickEvent($("#arg-s-state-info-close"), _a("arg[id]-s-state-info-close"));
    
    bindChangeEvent($("textarea[name=state_argument]"), _a("arg[id]-s-state-value"));
    bindOpenEvent($(".arg-s-support-help"), _a("arg[id]-s-support-help"));
    bindOpenEvent($(".arg-s-support-info"), _a("arg[id]-s-support-info"));
    bindClickEvent($("#support-help-close"), _a("support[id]-help-close"));
    bindClickEvent($("#support-info-close"), _a("support[id]-info-close"));
    
    bindChangeEvent($("textarea[name=support]"), _a("arg[id]-s-support-value"));
    bindOpenEvent($(".arg-s-type-help"), _a("arg[id]-s-type-help"));
    bindClickEvent($("#arg-s-type-help-close"), _a("arg[id]-s-type-help-close"));

    bindChangeEvent($("select[name=type]"), _a("arg[id]-s-type-value"));
    bindOpenEvent($(".arg-s-source-help"), _a("arg[id]-s-source-help"));
    bindChangeEvent($("textarea[name=source]"), _a("arg[id]-s-source-value"));
    bindOpenEvent($(".arg-s-relate-help"), _a("arg[id]-s-relate-help"));
    bindOpenEvent($(".arg-s-relate-info"), _a("arg[id]-s-relate-info"));
    bindChangeEvent($("textarea[name=relate]"), _a("arg[id]-s-relate-value"));
    bindChangeEvent($("select[name=rating]"), _a("arg[id]-s-rating"));
    bindChangeEvent($("input[name=cArg]"), _a("arg[id]-c-activate"));
    bindOpenEvent($(".arg-c-state-help"), _a("arg[id]-c-state-help"));
    bindOpenEvent($(".arg-c-state-info"), _a("arg[id]-c-state-info"));
    bindChangeEvent($("textarea[name=state_counterargument]"),
      _a("arg[id]-c-state-value"));
    bindOpenEvent($(".arg-c-type-help"), _a("arg[id]-c-type-help"));
    bindChangeEvent($("select[name=attack_type]"), _a("arg[id]-c-type-value"));
    bindChangeEvent($("select[name=counter_rating]"), _a("arg[id]-c-rating"));
    bindOpenEvent($(".arg-c-comeback-help"), _a("arg[id]-c-comeback-help"));
    bindOpenEvent($(".arg-c-comeback-info"), _a("arg[id]-c-comeback-info"));
    bindChangeEvent($("textarea[name=comeback]"),
      _a("arg[id]-c-comeback-value"));
    bindOpenEvent($(".arg-c-strategy-help"), _a("arg[id]-c-strategy-help"));
    bindChangeEvent($("select[name=strategy]"), _a("arg[id]-c-strategy-value"));
    bindOpenEvent($(".arg-c-response-help"), _a("arg[id]-c-response-help"));
    bindChangeEvent($("select[name=response]"), _a("arg[id]-c-response-value"));
    bindChangeEvent($("select[name=comeback_rating]"),
      _a("arg[id]-c-comeback-rating"));
    bindOpenEvent($(".arg-c-concluClaim-help"), _a("arg[id]-c-concluClaim-help"));
    bindOpenEvent($(".arg-c-concluClaim-info"), _a("arg[id]-c-concluClaim-info"));
    bindChangeEvent($("textarea[name=concluClaim]"), _a("arg[id]-c-concluClaim-value"));
    bindOpenEvent($(".arg-c-revise-help"), _a("arg[id]-c-revise-help"));
    bindChangeEvent($("select[name=concluClaimType]"), _a("arg[id]-c-concluClaim-type"));
    bindChangeEvent($("select[name=concluClaim_rating]"), _a("arg[id]-c-concluClaim-rating"));
    bindSubmitEvent($(".arg-save"), _a("arg[id]-save"));
    bindSubmitEvent($(".arg-cancel"), _a("arg[id]-cancel"));
    bindSubmitEvent($(".arg-delete2"), _a("arg[id]-delete2"));
    bindOpenEvent($(".arg-note-edit"), _a("arg[id]-note-edit"));
    bindChangeEvent($("textarea[name=noteArg]"), _a("arg[id]-note-value"));
    bindSubmitEvent($(".arg-note-save"), _a("arg[id]-note-save"));
    bindSubmitEvent($(".arg-note-cancel"), _a("arg[id]-note-cancel"));
    
    // conclusion editing
    bindOpenEvent($("#conclusion-edit"), _s("conclusion-edit"));
    bindOpenEvent($(".conclusion-thesis-help"), _s("conclusion-thesis-help"));
    bindClickEvent($("#conclusion-thesis-info"), _s("conclusion-thesis-info"));
    bindChangeEvent($("textarea[name=thesis_summary]"),
      _s("conclusion-thesis-value"));
    bindOpenEvent($(".conclusion-args-help"), _s("conclusion-args-help"));
    bindClickEvent($("#conclusion-args-info"), _s("conclusion-args-info"));
    bindChangeEvent($("textarea[name=argument_summary]"),
      _s("conclusion-args-value"));
    bindOpenEvent($(".conclusion-conseq-help"), _s("conclusion-conseq-help"));
    bindClickEvent($("#conclusion-conseq-info"), _s("conclusion-conseq-info"));
    bindChangeEvent($("textarea[name=consequences]"),
      _s("conclusion-conseq-value"));
    bindOpenEvent($(".conclusion-closing-help"), _s("conclusion-closing-help"));
    bindClickEvent($("#conclusion-closing-info"),
      _s("conclusion-closing-info"));
    bindClickEvent($("#closingListClose"),
      _s("closingListClose"));
    bindChangeEvent($("textarea[name=closing]"),
      _s("conclusion-closing-value"));
    bindSubmitEvent($("input[name=saveCon]"), _s("conclusion-save"));
    bindSubmitEvent($("input[name=cancelCon]"), _s("conclusion-cancel"));
    bindOpenEvent($("#conclusion-note-edit"), _s("conclusion-note-edit"));
    bindChangeEvent($("textarea[name=noteCon]"), _s("conclusion-note-value"));
    bindSubmitEvent($("input[name=saveConNote]"), _s("conclusion-note-save"));
    bindSubmitEvent($("#conclusion-note-cancel"), _s("conclusion-note-cancel"));
    bindOpenEvent($("#conclusion-preview"), _s("conclusion-preview"));

  });

}

// create a function that returns the given source id from any element
function singleElementSourceId(sourceId) {
  
  return function(element) {
    
    return sourceId;
  
  };
  
}

// create a function that generates a source id from an element and the
// given pattern
function argumentElementSourceId(pattern) {
  
  // e.g. if parent form name is "edit_argument_4" and pattern is
  // "arg[id]-element" then the function will return "arg4-element"
  return function(element) {
  
    var form = $(element).parents("form:last");
    var argumentId = /edit_argument_(\d+)/.exec(form.attr("name"))[1];
    return pattern.replace("[id]", argumentId);
     
  };
  
}

// bind click events
function bindClickEvent(jQueryObject, sourceIdGenerator) {

  // for each element retained by jQueryObject
  jQueryObject.each(function(index, element) {
    
    // order to log the event on click
    $(element).click(function() {
      
      logEvent(sourceIdGenerator(element), getTime(), null, null);
      
    });
  
  });

}

// bind open events
function bindOpenEvent(jQueryObject, sourceIdGenerator) {
  
  var isOpen = false;
  var openClick = function(event) {
    
    // event is only registered on open click (not on close click)
    if (!isOpen) {
      
      logEvent(sourceIdGenerator(event.currentTarget), getTime(), null, null);
    }
    isOpen = !isOpen;
    
  };
  
  // for each element retained by jQueryObject
  jQueryObject.each(function(index, element) {
    
    // openClick function must be the same for the elements (i.e. same ref.)
    $(element).click(openClick);
    
  });
  
}

// bind change events
function bindChangeEvent(jQueryObject, sourceIdGenerator) {
  
  // for each element retained by jQueryObject
  jQueryObject.each(function(index, element) {

    // order to log the event on value change
    $(element).change(function() {

      var value;
      if ($(element).attr("type") == "checkbox") { // input checkbox

        value = $(element).is(":checked") ? "on" : "off";
      } else { // textarea, select

        value = $(element).val();
      }
      logEvent(sourceIdGenerator(element), getTime(), value, null);
      
    });
  
  });
  
}

// bind submit events
function bindSubmitEvent(jQueryObject, sourceIdGenerator) {
  
  // for each element retained by jQueryObject
  jQueryObject.each(function(index, element) {
  
    // take priority over the form submit event
    var form = $(element).parents("form:first");
    form.bind("submit", function() {return false;});
    
    $(element).click(function(event) {
      
      // log the event on click
      logEvent(sourceIdGenerator(element), getTime(), null, function() {
        
        // request must be completed before submitting the form
        // otherwise it may not be taken into account
        
        // then perform regular submit
        form.unbind("submit");
        $(element).unbind(event);
        $(element).click();
      
      });
      
    });
  
  });
  
}

// log the event in the XML file
function logEvent(sourceId, time, value, callback) {

  // send a request to the appropriate PHP script
  $.get("log/write.php" +
    "?source=" + encodeURI(sourceId) +
    "&time=" + encodeURI(time) +
    (value != null ? "&value=" + encodeURI(value) : ""),
    callback);

}

// returns the current epoch time in seconds
function getTime() {
  
  return Math.floor((new Date).getTime() / 1000);
  
}
