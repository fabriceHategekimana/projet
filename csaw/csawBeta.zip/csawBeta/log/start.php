<?php

// this script starts the log session
// i.e. it creates a cookie with a session identifier

include_once("config.php");

// assign a log session identifier
setcookie(COOKIE_NAME, uniqid());

?>