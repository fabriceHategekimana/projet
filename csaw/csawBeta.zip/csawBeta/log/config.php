<?php

// this script holds PHP constants required by the log mecanism
// it also configurates the PHP processor

define("COOKIE_NAME", "csaw_log");
define("DEBUG", TRUE);

if (DEBUG) {

 error_reporting(E_ALL);
}

?>