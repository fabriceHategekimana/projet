<?php

// this script physically logs user's action
// in other words, actions are recorded in a XML file

include_once("config.php");

// open or create log file
$file = "logs/".$_COOKIE[COOKIE_NAME].".xml";
$handle = fopen($file, "a+");
flock($handle, LOCK_EX);

// get file content
if (filesize($file) == 0) {

  // file is new/empty, set initial content
  $content = "<?xml-stylesheet type=\"text/xsl\" href=\"../style.xsl\" ?>".
    "<events></events>";
} else {

  while (($line = fgets($handle)) !== FALSE) {

    $content .= $line;
  }
}

// load file content as a DOM document
$document = new DOMDocument();
$document->preserveWhiteSpace = FALSE;
$document->formatOutput = TRUE;
$document->loadXML($content);

// create event element
$element = $document->createElement("event");
$element->setAttribute("source", $_GET["source"]);
$element->setAttribute("time", $_GET["time"]);
if (isset($_GET["value"])) {

  $element->setAttribute("value", $_GET["value"]);
}

// append element to document
$document->lastChild->appendChild($element);

// write file with new content
ftruncate($handle, 0);
$content = $document->saveXML();
fwrite($handle, $content);

// close file
fclose($handle);

?>
