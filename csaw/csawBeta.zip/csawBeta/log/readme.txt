Make sure logs/ directory is always writable.
data.xlsx maps the U.I. controls and event source identifiers.
