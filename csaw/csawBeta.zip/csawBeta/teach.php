<?php

/* by kalli benetos
Argumentative essay online tool
April 2014
Credits:
- noun_152866_cc.svg (dashboard.png) created by ermankutlu from the Noun Project
- noun_388854_cc.svg (students.png) created by AlfredoCreates.com/Icons from the Noun Project
*/

// All files created by this script will have permissions rw-rw-rw/666.
umask(0);

//phpinfo ();
//session_start();

error_reporting(E_ALL);
//phpinfo();

// FROM  http://php.net/manual/en/security.magicquotes.disabling.php
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}



header ("Content-type: application/xhtml+xml");

//HTML global display page functions

function recordTime() {
time();
// date and time display
//echo date("d/m/y : H:i:s", time());
}


function head() {
echo '<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg" xml:lang="en" lang="en">

<head><meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>C-SAW Teach</title>';
// stylesheets
echo'<link href="form.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.structure.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.theme.css" rel="stylesheet" type="text/css" />';


// external jquery standand, ui and form check plugin
echo '<script language="javascript" src="jquery/jquery.js" type="text/javascript" />
<script language="javascript" src="jquery/jquery-ui.js" type="text/javascript" />';

// scripts for c-saw functions
echo '<script language="javascript" src="essay.js" type="text/javascript" />';

// order log/log.js loading, this client-side script defines functions to log user's activity
echo '<script language="javascript" src="log/log.js" type="text/javascript"/>';

echo '
</head><body>
<div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw" title="C-SAW"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
<h3 align="center">template maker</h3>
<div style="position: absolute; right: 8%;top: 40px">
<a id="studentView" href="javascript:viewClick(\'start.php\')" >
<img src="../graphics/students.png" alt="help" border="0" title="student view" class="buttonText" /></a>&#160;&#160;
<a id="dashboard" href="javascript:viewClick(\'teachDash.htm\')" >
<img src="../graphics/dashboard.png" alt="help" border="0" title="teacher dashboard" class="buttonText" /></a>&#160;&#160;
<a id="user-guide" href="javascript:viewClick(\'userguide.htm\')" >
<img src="../graphics/userguide.png" alt="help" border="0" title="User guide" class="buttonText" /></a>&#160;&#160;<a href="logout.php" >
<img src="../graphics/logout.png" alt="logout" border="0" title="Log out" class="buttonText" /></a>
</div>
<!-- TOP MENU ANCHORED LINKS
<h3 align="center"><a href="#heading" class="button">&#160;heading and title&#160;</a>
&#160;&#160; <a href="#intro"  class="button">&#160;introduction&#160;</a>
&#160;&#160; <a href="#arguments" class="button">&#160;arguments&#160;</a>
&#160;&#160; <a href="#conclusion" class="button">&#160;conclusion&#160;</a>
</h3> -->';
}

function newFileSelect(){
   echo'<h3> Current template loaded: '.$GLOBALS["file"].'</h3>';
// buttons for loading other files
// Choose another xml file to load FORM
echo '<div class="container">'; //tabs container
        echo'<div class="tabs" style="display:inline-block"><a id="load-TeachTemplate" class="buttonTab" href="javascript: toggleLabel(\'chooseFileForm\')">load another template</a>
        <div id="chooseFileForm" class="boxFileselect" style="display:none">
        <form name="chooseFile" method ="post" action="' . $_SERVER["PHP_SELF"] . '">

 <select name="loadFile">';
 $dir = "./"; // for tests
 $files = scandir($dir);

 foreach ($files as $file) {

         if (substr_compare($file, ".xml", -4) == 0) {
                 echo "<option value=\"$dir/$file\">$file</option>";
         }
 }

 echo'</select><br/><span class="instruct">Select an existing essay template to load</span>
 <p class="instruct">
 <input type="submit" value="load essay" class="buttonText" style="cursor:pointer"/>&#160;<a id="load-teachTemplateCancel" class="buttonText" href="javascript: toggleLabel(\'chooseFileForm\')">cancel</a></p>
</form></div>
</div>';
// Save as new xml file FORM
echo'<div class="tabs" style="display:inline-block">
        <a id="save-as-new-template" class="buttonTab" href="javascript: toggleLabel(\'saveAsFileForm\')">save as new template</a>

        <div id="saveAsFileForm" class="boxFileselect" style="display:none">
        <form name="saveAsFile" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
        <p class="instruct"><input type="text" cols="40"  id="eFile2" name="saveAsFilename" /><br/>Give your file a new name with a .xml file ending, e.g. MyEssay.xml</p><p><input type="submit" value="save file as" class="buttonText" />&#160;<a id="save-as-new-tempCancel" class="buttonText" href="javascript: toggleLabel(\'saveAsFileForm\')">cancel</a></p></form></div>
        </div>';
// publish file as template -  currently the same as new file FORM above
echo '<div class="tabs" style="display:inline-block">
        <a id="save-as-template" class="buttonTab" href="javascript: toggleLabel(\'saveAsWriteForm\')">publish for student use (inactive)</a>

        <div id="saveAsWriteForm" class="boxFileselect" style="display:none">
        <form name="saveAsWrite" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
        <p class="instruct"><input type="text" cols="40"  id="eFile3" name="saveAsWrite" /><br/>Give your student template a new name with a .xml file ending, e.g. MyEssay.xml</p><p><input type="submit" value="publish file as" class="buttonText" />&#160;<a id="save-as-templateCancel" class="buttonText" href="javascript: toggleLabel(\'saveAsWriteForm\')">cancel</a></p></form></div></div>';


echo '</div><p/>';}


function footer(){
        echo '<div align="center">';
 //<!--      TRACE global loaded '.$GLOBALS["file"].' file='.$file.' -->

        echo'<form name ="helpTextView" method ="post" action="textHelpOnly.php" target="popUp" onsubmit="popup(this);" style="display:inline!important;">
        <input type="hidden" name="toPopFile" value="'.$GLOBALS["file"].'" />
        <input id="view-tips" type="image" value="submit"  class="buttonText" title="text view with help" src="../graphics/viewtips.png" align="middle" />
        <span class="iconText"> view text with help </span></form>

        <form name ="printView" method ="post" action="printOnly.php" target="popUp" onsubmit="popup(this);" style="display:inline!important;">
        <input type="hidden" name="toPopFile" value="'.$GLOBALS["file"].'" />
        <input id="print-view" type="image" value="submit"  class="buttonText" title="print view" src="../graphics/printview.png" align="middle" />
        <span class="iconText"> print view </span></form>
</div>

<fieldset><p align="center" style="font-size:0.8em"><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">C-SAW</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="mailto:kalliopi.benetos@unige.ch" property="cc:attributionName" rel="cc:attributionURL">Kalliopi Benetos</a> is licensed under a <br /><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US">Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License</a>.</p></fieldset></body></html>';}


//-----------NAME ------------------------------------------------
// name - displays content and editing form fields
function nameForm($dom){
        $heading = $dom->getElementsByTagName('heading');

foreach ($heading as $head){
        $author=$head->getElementsByTagName('author')->item(0);
        $first_name = $author->getElementsByTagName('first_name')->item(0);
        $last_name = $author->getElementsByTagName('last_name')->item(0);

        $authorLabel = $author->getAttribute('label');
        $firstNameLabel = $first_name->getAttribute('label');
        $lastNameLabel = $last_name->getAttribute('label');

        echo '<a name="heading"></a>
                <form id="save_name" name ="edit_name" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" /><fieldset>
                <legend>'.$authorLabel.' <input type="text" name="author_label" placeholder="edit author area label" value="" /></legend>

                <table width="100%"  border="0" cellpadding="3" cellspacing="0">
                <tr><td align="center" valign="top" width="5%">
                <input type="image" value="submit" class="buttonText" name="saveName" src="../graphics/save.png " title="save changes to '.$authorLabel.'" align="middle" /><br/>
                <input type="image" value="submit" class="buttonText" name="cancelName" src="../graphics/cancel.png " title="cancel changes to '.$authorLabel.'" align="middle" />
                </td><td width="95%" valign="top">
                <label class="instruct">'.$firstNameLabel.'</label>
                <input type="text" name="first_name" placeholder="edit first name label" value="" />
                <label class="instruct">'.$lastNameLabel.'</label>
                <input type="text" name="last_name" placeholder="edit last name label" value="" />';
        echo'</td></tr></table></fieldset></form>';
        }
}

// name - displays content and give edit option
function nameView($dom){
        $heading = $dom->getElementsByTagName('heading');
foreach ($heading as $head){
        $author=$head->getElementsByTagName('author')->item(0);
        $first_name = $author->getElementsByTagName('first_name')->item(0);
        $last_name = $author->getElementsByTagName('last_name')->item(0);
        $authorLabel = $author->getAttribute('label');
  //      $authorLabel = $head->getAttribute('label');
        $firstNameLabel = $first_name->getAttribute('label');
        $lastNameLabel = $last_name->getAttribute('label');

        echo '<a name="heading"></a><fieldset>
                <legend>'.$authorLabel.'</legend>
	<form name ="edit_name" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                <table width="100%"  border="0" cellpadding="3" cellspacing="0">
                <tr><td align="center" valign="top" width="5%">';

        echo '<input type="image" value="submit" class="buttonText" name="editName" src="../graphics/edit.png" title="edit '.$authorLabel.'" align="middle" />';
        echo '</td><td width="95%" valign="top"><label class="instruct">'.$firstNameLabel.':</label> &#160;&#160;&#160;
                <label class="instruct">'.$lastNameLabel.':</label>';
        echo'</td></tr></table></form></fieldset>';

        }
}

// saves changes to NAME and goes to display view (nameView)
function saveName($dom) {
if(isset($_POST['currentFile'])){$file = $_POST['currentFile']; }
//   $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $heading = $dom->getElementsByTagName('heading')->item(0);
        $author=$heading->getElementsByTagName('author')->item(0);
        $first_name = $author->getElementsByTagName('first_name')->item(0);
        $last_name = $author->getElementsByTagName('last_name')->item(0);

        $authorLabel = $author->getAttribute('label');
  //      $firstNameLabel = $first_name->getAttribute('label');
 //       $lastNameLabel = $last_name->getAttribute('label');

          //REPLACE author_label ----------------------
        $authorLabel=$dom->getElementsByTagName('author')->item(0);
        if (isset($_POST['author_label'])&&($_POST['author_label']!='')){
             $insertAuthorLabel=$_POST['author_label'];
             $authorLabel->setAttribute('label',''. $insertAuthorLabel.'');
            }else{ //do nothing
        };

        //REPLACE first_name ----------------------
        $firstNameLabel=$dom->getElementsByTagName('first_name')->item(0);
        if (isset($_POST['first_name'])&&($_POST['first_name']!='')){
                $insertFirstNameLabel=$_POST['first_name'];
                $firstNameLabel->setAttribute('label',''. $insertFirstNameLabel .'');
        }else{ //do nothing
        };

        //REPLACE last_name ----------------------
        $lastNameLabel=$dom->getElementsByTagName('last_name')->item(0);
        if (isset($_POST['last_name'])&&($_POST['last_name']!='')){
                $insertLastNameLabel=$_POST['last_name'];
                $lastNameLabel->setAttribute('label',''. $insertLastNameLabel .'');
        }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        nameView($dom,$_POST);
        }

// end NAME ---------------------

//------TITLE--------------------------------------------------------

// titleDisplay - displays Title info and view to edit option
function titleDisplay($dom){
                $heading = $dom->getElementsByTagName('heading');

        foreach ($heading as $head){
                $headLabel = $head->getAttribute('label');
                $essay_title = $head->getElementsByTagName('essay_title')->item(0);
                $title = $essay_title->getElementsByTagName('title')->item(0);
                $subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
                $date = $essay_title->getElementsByTagName('date')->item(0);
                $noteHead = $head->getElementsByTagName('notepad')->item(0);
                // labels and help
                $essay_titleLabel = $essay_title->getAttribute('label');
                $titleLabel = $title->getAttribute('label');
                $titleHelp = $title->getAttribute('help');
                $subtitleLabel = $subtitle->getAttribute('label');
                $subtitleHelp = $subtitle->getAttribute('help');
                $dateLabel = $date->getAttribute('label');


        echo '<form name="edit_title" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" /><fieldset><legend>'.$essay_titleLabel.'</legend>
        <table width="100%"  border="0" cellpadding="3" cellspacing="0">
        <tr>
        <td valign="top" align="center" width="5%">';
        printf ('<a id="title-edit" class="genTip" href="javascript: toggleForm(\'titleForm\')"><img id="edittitleForm" src="../graphics/edit.png" alt="view" border="0" title="edit '.$essay_titleLabel.'" class="buttonText" style="display:block;"/></a>
                <input id="canceltitleForm" type="image" value="submit" class="buttonText" name="cancelTitle" src="../graphics/cancel.png" title="cancel changes to '.$essay_titleLabel.'" align="middle" style="display:none;"/>');

        echo '</td>
        <td valign="top" width="30%">';
               echo '<label class="instruct">'.$titleLabel.': </label><br/>
                <label class="instruct optional">'.$subtitleLabel.': </label><br/>
                <label class="instruct">'.$dateLabel.': </label>
        </td>
        <td valign="top" width="65%">';
                echo '<span id="titleForm" class="boxForm" style="display:none">';
                echo '<!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
   <!--     remove        <form id="save_title" name ="edit_title" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />-->

        <table width="100%"  border="0" cellpadding="3" cellspacing="0"><tr>
        <td>'.$essay_titleLabel.': <input type="text" name="essay_label" placeholder="edit '.$essay_titleLabel.' section label" value="" /></td></tr><tr>';
        echo '<td valign="top" ><fieldset class="On">
                <label for="title" class="boxInst">';
        printf('<a class="tip title-help" ><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$titleLabel.'</a>: <input type="text" name="title_label" placeholder="edit '.$titleLabel.' label" value="" />');
        echo '</label><br/>
                <span id="title" class="boxPop" style="display:block">'.$titleHelp.' ';
        printf('<a id="title-help-close" class="title-help"><img src="../graphics/close.png" alt="close" class="buttonHelp" title="close" style="float:right" /></a>');
        echo '</span>
                <textarea name="title_help" cols="50" rows="1" placeholder="edit '.$titleLabel.' help text" value="" />
                <br/>
                <label for="subtitle" class="boxInst">';
        printf('<a class="tip subtitle-help optional"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$subtitleLabel.'</a>: <input type="text" name="subtitle_label" placeholder="edit '.$subtitleLabel.' label" value="" />');
        echo '</label><br/>
                <span id="subtitle" class="boxPop" style="display:block">'.$subtitleHelp.' ';
        printf('<a id="subtitle-help-close" class="subtitle-help"><img src="../graphics/close.png " alt="close" class="buttonHelp" title="close" style="float:right" /></a>');
        echo '</span>
                <textarea name="subtitle_help" rows="1" placeholder="edit '.$subtitleLabel.' help text" value="" /><br/>
                <label for="date" class="instruct">'.$dateLabel.'</label>: <input type="text" name="date_label" placeholder="edit '.$dateLabel.' label" value="" size="25" />
                    </fieldset></td>';
        echo'	</tr><tr><td align="center">';
        echo '<input type="image" value="submit" class="buttonText" name="saveTitle" src="../graphics/save.png " title="save changes to '.$essay_titleLabel.'" align="middle" />&#160;&#160;
                <input type="image" value="submit" class="buttonText" name="cancelTitle" src="../graphics/cancel.png " title="cancel changes to '.$essay_titleLabel.'" align="middle" />';
                echo'</td></tr></table><!--</form>--></span>';
        echo '</td>
        </tr>
        </table>
        </fieldset></form>';

                }
}

// saves changes to TITLE and goes to display view (titleDisplay)
function saveTitle($dom) {
    if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
 //       $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $heading = $dom->getElementsByTagName('heading')->item(0);
        $essay_title=$heading->getElementsByTagName('essay_title')->item(0);


         $title = $essay_title->getElementsByTagName('title')->item(0);
         $subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
         $date = $essay_title->getElementsByTagName('date')->item(0);

         $essay_titleLabel = $essay_title->getAttribute('label');
         $titleLabel = $title->getAttribute('label');
         $subtitleLabel = $subtitle->getAttribute('label');
         $dateLabel = $date->getAttribute('label');
         $titleHelp = $title->getAttribute('help');
         $subtitleHelp = $subtitle->getAttribute('help');
         /*

                $noteHead = $head->getElementsByTagName('notepad')->item(0);
                // labels and help


      */

         //REPLACE essay section label ----------------------
        $essayLabel=$dom->getElementsByTagName('essay_title')->item(0);
        if (isset($_POST['essay_label'])&&($_POST['essay_label']!='')){
                $insertEssayLabel=$_POST['essay_label'];
                $essayLabel->setAttribute('label',''. $insertEssayLabel .'');
        }else{ //do nothing
        };

        //REPLACE title label ----------------------
        $titleLabel=$dom->getElementsByTagName('title')->item(0);
        if (isset($_POST['title_label'])&&($_POST['title_label']!='')){
                $insertTitleLabel=$_POST['title_label'];
                $titleLabel->setAttribute('label',''. $insertTitleLabel .'');
        }else{ //do nothing
        };

     //REPLACE subtitle label ----------------------
        $subtitleLabel=$dom->getElementsByTagName('subtitle')->item(0);
        if (isset($_POST['subtitle_label'])&&($_POST['subtitle_label']!='')){
                $insertSubtitleLabel=$_POST['subtitle_label'];
                $subtitleLabel->setAttribute('label',''. $insertSubtitleLabel .'');
        }else{ //do nothing
        };

        //REPLACE date label----------------------
        $dateLabel=$dom->getElementsByTagName('date')->item(0);
        if (isset($_POST['date_label'])&&($_POST['date_label']!='')){
                $insertDateLabel=$_POST['date_label'];
                $dateLabel->setAttribute('label',''. $insertDateLabel .'');
        }else{ //do nothing
        };

        //REPLACE title help text ----------------------
        $titleHelp=$dom->getElementsByTagName('title')->item(0);
        if (isset($_POST['title_help'])&&($_POST['title_help']!='')){
                $insertTitleHelp=$_POST['title_help'];
                $titleHelp->setAttribute('help',''. $insertTitleHelp .'');
        }else{ //do nothing
        };

        //REPLACE subtitle help text ----------------------
        $subtitleHelp=$dom->getElementsByTagName('subtitle')->item(0);
        if (isset($_POST['subtitle_help'])&&($_POST['subtitle_help']!='')){
                $insertSubtitleHelp=$_POST['subtitle_help'];
                $subtitleHelp->setAttribute('help',''. $insertSubtitleHelp .'');
        }else{ //do nothing
        };


        //REPLACE notepad currently not included in interface -----------------------------
        $noteHead = $heading->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteHead'])){
                $insertNoteHead=$_POST['noteHead'];
                $content = nl2br($insertNoteHead);
                $insertNoteHead = trim($content);
                $noteHead->nodeValue = $insertNoteHead;
                $insertNoteId = "noteHead";
                $noteHead->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        titleDisplay($dom,$_POST);
        }



//-----------INTRODUCTION ------------------------------------------------

// displays svg graphic form, edit and view with text help
function introView($dom){
        $introduction = $dom->getElementsByTagName('introduction');


foreach ($introduction as $intro){
        $thesis=$intro->getElementsByTagName('thesis')->item(0);
        $state_thesis = $thesis->getElementsByTagName('state_thesis')->item(0);

        $outline = $thesis->getElementsByTagName('outline')->item(0);
        $importance = $outline->getElementsByTagName('importance')->item(0);
        $conflict = $outline->getElementsByTagName('conflict')->item(0);
        $solution = $outline->getElementsByTagName('solution')->item(0);

        //svg elements
        $colorPro = "#467A4B";
   //     $colorCon = "#499BC4";
        $colorLine = "#98A48A";

        $labelThesis = $thesis->getAttribute('label');
        $labelThesisId = $thesis->getAttribute('svgLabel');
        $labelStateThesis = $state_thesis->getAttribute('label');
        $labelStateThesisId = $state_thesis->getAttribute('svgLabel');
        $labelConflict = $conflict->getAttribute('label');
        $labelConflictId = $conflict->getAttribute('svgLabel');
        $labelImp = $importance->getAttribute('label');
        $labelImpId = $importance->getAttribute('svgLabel');
        $labelSol = $solution->getAttribute('label');
        $labelSolId = $solution->getAttribute('svgLabel');
        //svg elements end
        $noteIntro = $intro->getElementsByTagName('notepad')->item(0);

        // Labels and help
        $introLabel=$intro->getAttribute('label');
        $thesisLabel = $thesis->getAttribute('label');
        $state_thesisLabel = $state_thesis->getAttribute('label');
        $state_thesisHelp = $state_thesis->getAttribute('help');

        $outlineLabel = $outline->getAttribute('label');
        $importanceLabel = $importance->getAttribute('label');
        $importanceHelp = $importance->getAttribute('help');
        $importanceConnectTitle = $importance->getAttribute('connectiveTitle');
        $importanceConnect = $importance->getAttribute('connective');
        $importanceListState= $importance->getAttribute('connectInclude');


        $conflictLabel = $conflict->getAttribute('label');
        $conflictHelp = $conflict->getAttribute('help');
        $conflictConnectTitle = $conflict->getAttribute('connectiveTitle');
        $conflictConnect = $conflict->getAttribute('connective');
        $conflictListState= $conflict->getAttribute('connectInclude');


        $solutionLabel = $solution->getAttribute('label');
        $solutionHelp = $solution->getAttribute('help');
        $solutionConnectTitle = $solution->getAttribute('connectiveTitle');
        $solutionConnect = $solution->getAttribute('connective');
        $solutionListState= $solution->getAttribute('connectInclude');

        $noteIntroLabel = $noteIntro->getAttribute('label');


// Introduction svg display start

        // SVG graph - detecting if textnodes are whitespace only
        $textThesis = $state_thesis->nodeValue;
        $textThesisNode = $dom->createTextNode("$textThesis");
        $wsThesis = $textThesisNode->isWhitespaceInElementContent();

        $textConflict = $conflict->nodeValue;
        $textConflictNode = $dom->createTextNode("$textConflict");
        $wsConflict = $textConflictNode->isWhitespaceInElementContent();

        $textSol = $solution->nodeValue;
        $textSolNode = $dom->createTextNode("$textSol");
        $wsSol = $textSolNode->isWhitespaceInElementContent();

        $textImp = $importance->nodeValue;
        $textImpNode = $dom->createTextNode("$textImp");
        $wsImp = $textImpNode->isWhitespaceInElementContent();

        $introScale=1;
        if ($wsThesis){$colorThesis='#FFFFFF';}else{$colorThesis='#467A4B';};
        if ($wsConflict){
                $colorConflict='#FFFFFF';
                }else{
                $colorConflict='#467A4B';
                $introScale=$introScale+0.5;};
        if ($wsSol){
                $colorSol='#FFFFFF';
                }else{
                $colorSol='#467A4B';
                $introScale=$introScale+0.5;};
        if ($wsImp){$colorImp='#FFFFFF';}else{$colorImp='#467A4B';};
        if (($wsThesis)||($wsImp)){$colorIntro='#FFFFFF';}else{$colorIntro='#467A4B';};
        if ((!$wsThesis)&&(!$wsImp)){$introScale=$introScale+0.5;};


// Dispay code

        echo '<fieldset>
                <legend>'.$introLabel.'</legend>
                <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
                <form name ="edit_introduction" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <table border="0" cellpadding="3" cellspacing="0" width="100%" id="introTable">
                <tr>
                <td align="center" width="5%" valign="top">';
// buttons for intro  id="intro-edit" class="genTip"
printf ('<a id="intro-edit" class="genTip" href="javascript: toggleForm(\'introForm\')"><img id="editintroForm" src="../graphics/edit.png" alt="edit introduction" border="0" title="edit '.$introLabel.'" class="buttonText" style="display:block;"/></a>
        <input id="cancelintroForm" type="image" value="submit" class="buttonText" name="cancelIntro" src="../graphics/cancel.png" title="cancel changes to '.$introLabel.'" align="middle" style="display:none;"/>');

        echo '</td>
                <td valign="top" width="20%">';
        echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='55' width='180' x='0' y='0'>";
        echo "<defs>

            <rect id='nodeEmpty' width='16' height='16' stroke-width='2' />
            <rect id='nodeEmptySm' width='10' height='10'  stroke-width='2' />

            <rect id='nodeEmpty' width='16' height='6' fill='none'  stroke-width='2' />
            <circle id='optionEmpty' r='5' stroke-width='2' />
            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,34,0' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />

            <symbol id='intro'>
                <use x='18' y='8' xlink:href='#line'  />
                <use x='68' y='0' xlink:href='#lineProAa'  />
                <use x='83' y='0' xlink:href='#lineProAb'  />
                <use x='83' y='15' xlink:href='#lineProAb'  />
            </symbol>

            </defs>";

printf ('<use x="1" y="1" xlink:href="#intro" />
                          <use x="0" y="0" id="svg-thesis" xlink:href="#nodeEmpty"  transform="translate(1,1) scale('.$introScale.')" fill="'.$colorIntro.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelThesisId.'\')" onmouseout="toggleOut(\''.$labelThesisId.'\')"
                          onclick="toggleIcon(\'introText\')" title="'.$thesisLabel.'"><title>'.$thesisLabel.'</title></use>

                          <use x="0" y="0" id="svg-state-thesis"  xlink:href="#nodeEmpty" transform="translate(52,1)" fill="'.$colorThesis.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelStateThesisId.'\'); changeTextClass(\'thesisText\')" onmouseout="toggleOut(\''.$labelStateThesisId.'\'); changeTextClass(\'thesisText\')" title="'.$state_thesisLabel.'"><title>'.$state_thesisLabel.'</title></use>

                          <use x="0" y="0" id="svg-importance" xlink:href="#nodeEmptySm" transform="translate(100,1)" fill="'.$colorImp.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelImpId.'\'); changeTextClass(\'importanceText\')" onmouseout="toggleOut(\''.$labelImpId.'\'); changeTextClass(\'importanceText\')" title="'.$importanceLabel.'"><title>'.$importanceLabel.'</title></use>

                          <use x="0" y="0" id="svg-conflict" xlink:href="#optionEmpty" transform="translate(105,21)" fill="'.$colorConflict.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConflictId.'\'); changeTextClass(\'conflictText\')" onmouseout="toggleOut(\''.$labelConflictId.'\'); changeTextClass(\'conflictText\')" title="'.$conflictLabel.'"><title>'.$conflictLabel.'</title></use>

                          <use x="0" y="0" id="svg-solution" xlink:href="#optionEmpty" transform="translate(105,36)" fill="'.$colorSol.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelSolId.'\'); changeTextClass(\'solutionText\')" onmouseout="toggleOut(\''.$labelSolId.'\'); changeTextClass(\'solutionText\')" ><title>'.$solutionLabel.'</title></use>');
        echo  " </svg>";
// SVG labels
/*        echo "<br /><img src='../graphics/transpixel.png' height='18px' style='float:right' />
                <span id='$labelThesisId' class='svgPop'>$labelThesis</span>
                <span id='$labelStateThesisId' class='svgPop' >$labelStateThesis</span>
                <span id='$labelImpId' class='svgPop' >$labelImp</span>
                <span id='$labelConflictId' class='svgPop' >$labelConflict</span>
                <span id='$labelSolId' class='svgPop'>$labelSol</span>";
*/
//Intro notepad form


        echo	'</td>';

// form for introduction
        echo '<td width="75%" valign="top"><br />';
        echo '<span id="introForm" class="boxForm" style="display:none">';
        echo '<form id="save_intro" name="save_introduction" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
              <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
              <fieldset class="On">
              <p>edit <strong>'.$introLabel.'</strong> section label above: <input type="text" name="intro_label" placeholder="edit '.$introLabel.' section label" value="" /></p>
              <legend><a id="intro-note-edit" class="buttonText" href="javascript: toggleNote(\'introNotepad\')"><img src="../graphics/note.png" id="noteintroNotepad" alt="show notepad" border="0" title="edit note" /></a>&#160;&#160;&#160;'.$thesisLabel.': <input type="text" name="thesis_label" placeholder="edit '.$thesisLabel.' label" size="30" value="" /></legend>';
               printf ('');

               echo' <label for="state_thesis" class="boxInst">';
               printf ('<a class="tip intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$state_thesisLabel.'</a>: <input  size="30"  type="text" name="stateThesis_label" placeholder="edit '.$state_thesisLabel.' label" value="" />');
               echo '</label>';

               echo '<div id="introNotepad" class="boxNote" style="display:none">
               <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                               <fieldset class="notepad">
                                <legend>'.$noteIntroLabel.'</legend>
                                <textarea name="noteIntro" cols="20" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)" placeholder="take notes here">', $noteIntro->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

              echo ' <br/>
               <span id="state_thesis" class="boxPop" style="display:block">'.$state_thesisHelp.' ';
               printf ('<a id="intro-state-help-close" class="intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a>');
               echo '</span>
                        <textarea id="thesisText" class="textOff" name="state_thesisHelp" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'thesisText\')" onblur="changeTextClass(\'thesisText\')"  onkeyup="textAreaAdjust(this)" placeholder="edit '.$state_thesisLabel.' help" value="" /><br/>
                        <fieldset id="importanceWrap" class="On">
                              <legend>'.$outlineLabel.': <input type="text" name="outline_label"  size="30" placeholder="edit '.$outlineLabel.' label" value="" /></legend>';
                        // importance
                        printf('<label for="importance" class="boxInst"><a class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img  src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$importanceLabel.'</a></label>: <input type="text" name="importance_label"  size="30"  placeholder="edit  '.$importanceLabel.' label" value="" />');
                        echo '&#160;<a id="intro-importance-info" href="javascript:toggleInfo(\'importanceList\')"><img id="imgimportanceList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        echo'<span id="importance" class="boxPop" style="display:block">'.$importanceHelp.'';
                        printf('&#160;<a id="intro-importance-help-close" class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                        // importance words popup
                        echo'<div id="importanceList" class="boxFloat" style="display:none"><h4>'.$importanceLabel.' </h4><p class="instruct">'.$importanceConnectTitle.': <input type="text" name="importanceConnect_label"  size="30" placeholder="edit '.$importanceLabel.' help text" value="" /> </p>
                        <p class="maintext">'.$importanceConnect.'</p>
                        <textarea id="importanceConnectList" class="textOff" name="importance_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'importanceConnectList\')" onblur="changeTextClass(\'importanceConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$importanceLabel.' word list" value="" />';
                        printf('&#160;<a id="intro-importance-info-close" class="tip intro-importance-info" href="javascript: toggleInfo(\'importanceList\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                        // importance text field
                        echo '<textarea id="importanceText" class="textOff" name="importance_help" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'importanceText\')" onblur="changeTextClass(\'importanceText\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$importanceLabel.' help" value="" />
                        <br/>';
                        //conflict
                        printf('<label for="conflict" class="boxInst"><a class="tip intro-conflict-help optional" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$conflictLabel.'</a>: <input type="text" name="conflict_label"  size="30" placeholder="edit '.$conflictLabel.' label" value="" /></label>');
                        echo '&#160;<a id="intro-conflict-info" href="javascript:toggleInfo(\'conflictList\')"><img id="imgconflictList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        printf('<span id="conflict" class="boxPop" style="display:block">'.$conflictHelp.'&#160;<a id="intro-conflict-help-close" class="tip intro-conflict-help" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                        // conflict words popup
                        echo '<div id="conflictList" class="boxFloat" style="display:none"><h4>'.$conflictLabel.' </h4><p class="optional">'.$conflictConnectTitle.': <input type="text" name="conflictConnect_label"  size="30" placeholder="edit '.$conflictLabel.' help text" value="" /> </p><p class="maintext">'.$conflictConnect.'</p>
                        <textarea id="conflictConnectList" class="textOff" name="conflict_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'conflictConnectList\')" onblur="changeTextClass(\'conflictConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$conflictLabel.' word list" value="" />';
                        printf('<a id="intro-conflict-info-close" class="intro-conflict-info" href="javascript: toggleInfo(\'conflictList\')"><img  src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></div>');
                        //conflict text field
                        echo '<textarea id="conflictText" class="textOff" name="conflict_help" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'conflictText\')" onblur="changeTextClass(\'conflictText\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$conflictLabel.' label" value="" /><br/>';
                        // solution
                        printf('<label for="solution" class="boxInst">&#160;<a class="tip intro-solution-help optional" href="javascript: toggleLabel(\'solution\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$solutionLabel.'</a>: <input type="text" name="solution_label"  size="30" placeholder="edit '.$solutionLabel.' label" value="" /></label>');
                        echo '&#160;<a id="intro-solution-info" href="javascript:toggleInfo(\'solutionList\')"><img id="imgsolutionList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        printf('<span id="solution" class="boxPop" style="display:block">'.$solutionHelp.'&#160;<a id="intro-solution-help-close" class="tip intro-solution-help" href="javascript: toggleLabel(\'solution\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                        // solution words popup
                        echo '<div id="solutionList" class="boxFloat" style="display:none"><h4>'.$solutionLabel.' </h4><p class="optional">'.$solutionConnectTitle.' <input type="text" name="solutionConnect_label"  size="30" placeholder="edit '.$solutionLabel.' help text" value="" /></p><p class="maintext">'.$solutionConnect.'</p>
                        <textarea id="solutionConnectList" class="textOff" name="solution_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'solutionConnectList\')" onblur="changeTextClass(\'solutionConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$solutionLabel.' word list" value="" />';
                        printf('&#160;<a id="intro-solution-info-close" class="intro-solution-info" href="javascript: toggleInfo(\'solutionList\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                        // solution text field
                        echo '<textarea id="solutionText" class="textOff" name="solution_help" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'solutionText\')" onblur="changeTextClass(\'solutionText\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$solutionLabel.' label" value=""  />
                        </fieldset>';
                        echo '</fieldset>';
                       // save buttons
                        echo '<div align="center"><input id="intro_save" type="image" value="submit" class="buttonText" name="saveIntro" src="../graphics/save.png" title="save changes to introduction" align="middle" />&#160;&#160;
                                <input id="intro_cancel" type="image" value="submit" class="buttonText" name="cancelIntro" src="../graphics/cancel.png" title="cancel changes to introduction" align="middle" />
                                </div>';
                       // end intro form
                        echo '</form></span>';
        echo '</td>';
        echo '</tr>
                </table></form></fieldset>';
                }
}

// saves changes to INTRODUCTION and goes to display view (introView)
function saveIntro($dom) {
   if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
  //      $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');
        $message = str_replace('&#13;', '', $_SESSION["message"]);

        // retrieve the parent elements
        $introduction = $dom->getElementsByTagName('introduction')->item(0);
        $thesis=$introduction->getElementsByTagName('thesis')->item(0);

        $state_thesis = $thesis->getElementsByTagName('state_thesis')->item(0);

        $outline = $thesis->getElementsByTagName('outline')->item(0);
        $importance = $outline->getElementsByTagName('importance')->item(0);
        $conflict = $outline->getElementsByTagName('conflict')->item(0);
        $solution = $outline->getElementsByTagName('solution')->item(0);
        $noteIntro = $introduction->getElementsByTagName('notepad')->item(0);

        // Labels and help
        $introLabel=$introduction->getAttribute('label');
        $thesisLabel = $thesis->getAttribute('label');
        $state_thesisLabel = $state_thesis->getAttribute('label');
        $state_thesisHelp = $state_thesis->getAttribute('help');

        $outlineLabel = $outline->getAttribute('label');
        $importanceLabel = $importance->getAttribute('label');
        $importanceHelp = $importance->getAttribute('help');
        $importanceConnectTitle = $importance->getAttribute('connectiveTitle');
        $importanceConnect = $importance->getAttribute('connective');
        $importanceListState= $importance->getAttribute('connectInclude');


        $conflictLabel = $conflict->getAttribute('label');
        $conflictHelp = $conflict->getAttribute('help');
        $conflictConnectTitle = $conflict->getAttribute('connectiveTitle');
        $conflictConnect = $conflict->getAttribute('connective');
        $conflictListState= $conflict->getAttribute('connectInclude');

        $solutionLabel = $solution->getAttribute('label');
        $solutionHelp = $solution->getAttribute('help');
        $solutionConnectTitle = $solution->getAttribute('connectiveTitle');
        $solutionConnect = $solution->getAttribute('connective');
        $solutionListState= $solution->getAttribute('connectInclude');

        $noteIntroLabel = $noteIntro->getAttribute('label');

        //REPLACE intro section label text ----------------------
        $introLabel=$dom->getElementsByTagName('introduction')->item(0);
        if (isset($_POST['intro_label'])&&($_POST['intro_label']!='')){
                $insertIntroLabel=$_POST['intro_label'];
                $introLabel->setAttribute('label',''. $insertIntroLabel .'');
        }else{ //do nothing
        };

       //REPLACE thesis label text ----------------------
        $thesisLabel=$dom->getElementsByTagName('thesis')->item(0);
        if (isset($_POST['thesis_label'])&&($_POST['thesis_label']!='')){
                $insertThesisLabel=$_POST['thesis_label'];
                $thesisLabel->setAttribute('label',''. $insertThesisLabel .'');
        }else{ //do nothing
        };
        //REPLACE state_thesis label text ----------------------
        $state_thesisLabel=$dom->getElementsByTagName('state_thesis')->item(0);
        if (isset($_POST['stateThesis_label'])&&($_POST['stateThesis_label']!='')){
                $insertStateThesisLabel=$_POST['stateThesis_label'];
                $state_thesisLabel->setAttribute('label',''. $insertStateThesisLabel .'');
        }else{ //do nothing
        };
        //REPLACE state_thesis help text----------------------
        $state_thesisHelp = $dom->getElementsByTagName('state_thesis')->item(0);
        if (isset($_POST['state_thesisHelp'])&&($_POST['state_thesisHelp']!='')) {
                $insertStateThesisHelp=$_POST['state_thesisHelp'];
                $state_thesisHelp->setAttribute('help',''. $insertStateThesisHelp .'');
                }else {	// do nothing`
                };
       //REPLACE outline label text----------------------
        $outlineLabel = $dom->getElementsByTagName('outline')->item(0);
        if (isset($_POST['outline_label'])&&($_POST['outline_label']!='')) {
                $insertOutlineLabel=$_POST['outline_label'];
                $outlineLabel->setAttribute('label',''. $insertOutlineLabel .'');
                }else {	// do nothing`
                };
        //REPLACE importance label text --------------------
        $importanceLabel = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importance_label'])&&($_POST['importance_label']!='')) {
                $insertImportanceLabel=$_POST['importance_label'];
                $importanceLabel->setAttribute('label',''. $insertImportanceLabel .'');
                }else {	// do nothing
                };
        //REPLACE importance help text --------------------
        $importanceHelp = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importance_help'])&&($_POST['importance_help']!='')) {
                $insertImportanceHelp=$_POST['importance_help'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertImportanceHelp);
                $insertImportanceHelp = trim($content);
                $importanceHelp->setAttribute('help',''. $insertImportanceHelp .'');
                }else {	// do nothing
                };
   //REPLACE importance connective list Include --------------------
        $importanceListState = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importanceList_state'])) {
                $insertImportanceListState=$_POST['importanceList_state'];
                $importance->setAttribute('connectIncude',''. $insertImportanceListState .'');
                }else {
                 // do nothing
                };

         //REPLACE importance connective list text --------------------
        $importanceConnectTitle = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importanceConnect_label'])&&($_POST['importanceConnect_label']!='')) {
                $insertImportanceConnectTitle=$_POST['importanceConnect_label'];
                $importanceConnectTitle->setAttribute('connectiveTitle',''. $insertImportanceConnectTitle .'');
                }else {	// do nothing
                };

        //REPLACE importance connective list --------------------
        $importanceConnect = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importance_connectList'])&&($_POST['importance_connectList']!='')) {
                $insertImportanceConnectList=$_POST['importance_connectList'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertImportanceConnectList);
                $insertImportanceConnectList = trim($content);
                $importanceConnect->setAttribute('connective',''. $insertImportanceConnectList .'');
                }else {	// do nothing
                };
        //REPLACE conflict label text --------------------
        $conflictLabel = $dom->getElementsByTagName('conflict')->item(0);
        if (isset($_POST['conflict_label'])&&($_POST['conflict_label']!='')) {
                $insertConflictLabel=$_POST['conflict_label'];
                $conflictLabel->setAttribute('label',''. $insertConflictLabel .'');
                }else {	// do nothing
                };
        //REPLACE conflict help text --------------------
        $conflictHelp = $dom->getElementsByTagName('conflict')->item(0);
        if (isset($_POST['conflict_help'])&&($_POST['conflict_help']!='')) {
                $insertConflictHelp=$_POST['conflict_help'];
                $content = nl2br($insertConflictHelp);
                $insertConflictHelp = trim($content);
                $conflictHelp->setAttribute('help',''. $insertConflictHelp .'');
                }else {	// do nothing
                };
         //REPLACE conflict connective title text --------------------
        $conflictConnectTitle = $dom->getElementsByTagName('conflict')->item(0);
        if (isset($_POST['conflictConnect_label'])&&($_POST['conflictConnect_label']!='')) {
                $insertConflictConnectTitle=$_POST['conflictConnect_label'];
                $conflictConnectTitle->setAttribute('connectiveTitle',''. $insertConflictConnectTitle .'');
                }else {	// do nothing
                };

        //REPLACE conflict connective list --------------------
        $conflictConnect = $dom->getElementsByTagName('conflict')->item(0);
        if (isset($_POST['conflict_connectList'])&&($_POST['conflict_connectList']!='')) {
                $insertConnectList=$_POST['conflict_connectList'];
                $content = nl2br($insertConnectList);
                $insertConnectList = trim($content);
                $conflictConnect->setAttribute('connective',''. $insertConnectList .'');
                }else {	// do nothing
                };

       //REPLACE solution label text --------------------
        $solutionLabel = $dom->getElementsByTagName('solution')->item(0);
        if (isset($_POST['solution_label'])&&($_POST['solution_label']!='')) {
                $insertSolutionLabel=$_POST['solution_label'];
                $solutionLabel->setAttribute('label',''. $insertSolutionLabel .'');
                }else {	// do nothing
                };
        //REPLACE solution help text --------------------
        $solutionHelp = $dom->getElementsByTagName('solution')->item(0);
        if (isset($_POST['solution_help'])&&($_POST['solution_help']!='')) {
                $insertSolutionHelp=$_POST['solution_help'];
                $content = nl2br($insertSolutionHelp);
                $insertSolutionHelp = trim($content);
                $solutionHelp->setAttribute('help',''. $insertSolutionHelp .'');
                }else {	// do nothing
                };

         //REPLACE solution connective list text --------------------
        $solutionConnectTitle = $dom->getElementsByTagName('solution')->item(0);
        if (isset($_POST['solutionConnect_label'])&&($_POST['solutionConnect_label']!='')) {
                $insertSolutionConnectTitle=$_POST['solutionConnect_label'];
                $solutionConnectTitle->setAttribute('connectiveTitle',''. $insertSolutionConnectTitle .'');
                }else {	// do nothing
                };

        //REPLACE solution connective list --------------------
        $solutionConnect = $dom->getElementsByTagName('solution')->item(0);
        if (isset($_POST['solution_connectList'])&&($_POST['solution_connectList']!='')) {
                $insertConnectList=$_POST['solution_connectList'];
                $content = nl2br($insertConnectList);
                $insertConnectList = trim($content);
                $solutionConnect->setAttribute('connective',''. $insertConnectList .'');
                }else {	// do nothing
                };

        //REPLACE notepad-----------------------------
        $noteIntro = $introduction->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteIntro'])&&($_POST['noteIntro']!='')){
                $insertNoteIntro=$_POST['noteIntro'];
                $content = nl2br($insertNoteIntro);
                $insertNoteIntro = trim($content);
                $noteIntro->nodeValue = $insertNoteIntro;
                $insertNoteId = "noteIntro";
                $noteIntro->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        introView($dom,$_POST);
        }



//-----------ARGUMENT ------------------------------------------------


// ARGVIEW - displays SVG graphic tree of arguments, edit (*Form), text view (*Display) options

function argView($dom){
        $arguments = $dom->getElementsByTagName('arguments')->item(0);
        $argument = $dom->getElementsByTagName('argument');
        $argumentsLabel = $dom->getElementsByTagName('arguments')->item(0)->getAttribute('label');
        $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');
        $noId= 0;
        $argsScore=1;
        $argsFill=0; //was =1

        echo '<a name="arguments"></a>
                <fieldset><form name="edit_argHeads" method ="post" action="' . $_SERVER["PHP_SELF"] . '"><legend>'.$argumentsLabel.': <input  size="30"  type="text" name="arguments_label" placeholder="edit '.$argumentsLabel.' section label" value="" /></legend>';
          argButtons($dom);	// argument menu links
          echo ':
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" /><input  size="30"  type="text" name="argument_label" placeholder="edit '.$argumentLabel.' label" value="" />&#160;&#160;<input id="argHead_save" type="image" value="submit" class="buttonText" name="saveArgHeads" src="../graphics/save.png" title="save changes to headings" align="middle" />&#160;&#160;
                                <input id="argHead_cancel" type="image" value="submit" class="buttonText" name="cancelArgHeads" src="../graphics/cancel.png" title="cancel changes to '.$argumentLabel.' heading" align="middle" /></form>';

foreach ($argument as $arg){
        // creating a unique Id for each argument that is in order
        $noId++;
        $insertId='_'.$noId.'';
        $arg->setAttribute('id',''. $insertId .'');
        $argHelp=$arg->getAttribute('help');
        // getting argument by id
        $id=$arg->getAttribute('id');

        $argLength=$dom->getElementsByTagName('argument')->length;
        //simple_argument contents
        $simpleArg=$arg->getElementsByTagName('simple_argument')->item(0);

        $rating=$simpleArg->getAttribute('rating');

                // for checkbox and svg as grey
        $simple_status=$simpleArg->getAttribute('status'); // for checkbox and svg as grey
        $simple_statusInclude=$simpleArg->getAttribute('statusInclude'); // for including simple argument

        // for whitespace "empty" or "full"
        $simple_content=$simpleArg->getAttribute('content');

        $stateArg = $arg->getElementsByTagName('state_argument')->item(0);
        $stateArgWords_status=$stateArg->getAttribute('stateArgWordsStatus'); // for checkbox to display word list edit
        $support = $arg->getElementsByTagName('support')->item(0);
                $argType=$support->getAttribute('type');
                $source=$support->getAttribute('source');
        $relate = $arg->getElementsByTagName('relate')->item(0);

        //counterargument contents
        $counterArg=$arg->getElementsByTagName('counterargument')->item(0);
        $counter_status = $counterArg->getAttribute('status');
        $counter_statusInclude=$counterArg->getAttribute('statusInclude'); // for including counter argument

        $stateCounterArg=$arg->getElementsByTagName('state_counterargument')->item(0);
                $attackType=$stateCounterArg->getAttribute('attack_type');
                $counter_rating = $stateCounterArg->getAttribute('rating');
                $counter_content=$simpleArg->getAttribute('content'); // for whitespace "empty" or "full"


        $comeback=$arg->getElementsByTagName('comeback')->item(0);
        $strategy=$comeback->getAttribute('strategy');
        $comeback_rating = $comeback->getAttribute('rating');

        $responseType = $comeback->getAttribute('response');

 // optional concluding statement
    $concluClaim=$arg->getElementsByTagName('concluClaim')->item(0);
    $concluClaimType=$concluClaim->getAttribute('revise');
    $concluClaim_rating = $concluClaim->getAttribute('rating');



        $args =  $arg->parentNode;

        $noteArg = $arg->getElementsByTagName('notepad')->item(0);
                $insertNoteId='noteArg_'.$noId.'';
                $noteArg->setAttribute('id',''.$insertNoteId.'');
        // labels and help
        $argumentLabel=$arg->getAttribute('label');
        $simpleArgLabel=$simpleArg->getAttribute('label');
        $simpleArgHelp=$simpleArg->getAttribute('help');
        $simpleArgRatingLabel =$simpleArg->getAttribute('ratingLabel');

        $stateArgLabel = $stateArg->getAttribute('label');
        $stateArgHelp = $stateArg->getAttribute('help');
        $argTypeLabel = $stateArg->getAttribute('argTypeLabel');
        $argType=$stateArg->getAttribute('type');
        $argTypeHelp= $stateArg->getAttribute('typeHelp');
        $stateArgConnectTitle = $stateArg->getAttribute('connectiveTitle');
        $stateArgConnect = $stateArg->getAttribute('connective');

        $supportLabel = $support->getAttribute('label');
        $supportHelp= $support->getAttribute('help');
        $supportConnectTitle= $support->getAttribute('connectiveTitle');
        $supportConnect= $support->getAttribute('connective');

        $sourceLabel= $support->getAttribute('sourceLabel');
        $sourceHelp= $support->getAttribute('sourceHelp');
        $source= $support->getAttribute('source');
        $relateLabel = $relate->getAttribute('label');
        $relateHelp = $relate->getAttribute('help');
        $relateConnectTitle = $relate->getAttribute('connectiveTitle');
        $relateConnect = $relate->getAttribute('connective');

        $counterArgLabel = $counterArg->getAttribute('label');
        $counterArgHelp = $counterArg->getAttribute('help');

        $stateCounterArgLabel = $stateCounterArg->getAttribute('label');
        $stateCounterArgHelp = $stateCounterArg->getAttribute('help');
        $stateCounterArgConnectTitle = $stateCounterArg->getAttribute('connectiveTitle');
        $stateCounterArgConnect = $stateCounterArg->getAttribute('connective');
            $counterArgRatingLabel =$stateCounterArg->getAttribute('ratingLabel');

        $attackType = $stateCounterArg->getAttribute('attack_type');
        $attackTypeLabel = $stateCounterArg->getAttribute('attackTypeLabel');
        $attackTypeHelp = $stateCounterArg->getAttribute('attackHelp');

        $comebackLabel = $comeback->getAttribute('label');
        $comebackHelp = $comeback->getAttribute('help');
        $comebackConnectTitle = $comeback->getAttribute('connectiveTitle');
        $comebackConnect = $comeback->getAttribute('connective');
        $responseTypeLabel = $comeback->getAttribute('responseTypeLabel');
        $responseHelp = $comeback->getAttribute('responseHelp');
        $responseType = $comeback->getAttribute('response');
        $strategyTypeLabel = $comeback->getAttribute('strategyTypeLabel');
        $strategyType = $comeback->getAttribute('strategy');
        $strategyHelp = $comeback->getAttribute('strategyHelp');
                    $comebackRatingLabel =$comeback->getAttribute('ratingLabel');

        $concluClaimLabel = $concluClaim->getAttribute('label');
        $concluClaimHelp = $concluClaim->getAttribute('help');
        $concluClaimConnectTitle = $concluClaim->getAttribute('connectiveTitle');
        $concluClaimConnect = $concluClaim->getAttribute('connective');
        $reviseTypeLabel = $concluClaim->getAttribute('reviseTypeLabel');
        $reviseType = $concluClaim->getAttribute('revise');
        $reviseHelp = $concluClaim->getAttribute('reviseHelp');
                 $concluClaimRatingLabel =$concluClaim->getAttribute('ratingLabel');


        $argNoteLegend = $noteArg->getAttribute('legend');
        $argNoteLabel = $noteArg->getAttribute('label');
        // SVG labels
        $labelArgs = $args->getAttribute('label');
        $labelArgsId = $args->nodeName;
        $labelArgsIdSvg = ''.$labelArgsId.''.$noId.'';

        $labelSimpleArg=$simpleArg->getAttribute('label');
        $labelSimpleArgId = $simpleArg->nodeName;
        $labelSimpleArgIdSvg = ''.$labelSimpleArgId.''.$noId.'';

        $labelConArg=$counterArg->getAttribute('label');
        $labelConArgId = $counterArg->nodeName;
        $labelConArgIdSvg = ''.$labelConArgId.''.$noId.'';

        $labelStateArg=$stateArg->getAttribute('label');
        $labelStateArgId = $stateArg->nodeName;
        $labelStateArgIdSvg = ''.$labelStateArgId.''.$noId.'';

        $labelSupport=$support->getAttribute('label');
        $labelSupportId = $support->nodeName;
        $labelSupportIdSvg = ''.$labelSupportId.''.$noId.'';

        $labelRelate=$relate->getAttribute('label');
        $labelRelateId = $relate->nodeName;
        $labelRelateIdSvg = ''.$labelRelateId.''.$noId.'';

        $labelCounter=$stateCounterArg->getAttribute('label');
        $labelCounterId = $stateCounterArg->nodeName;
        $labelCounterIdSvg = ''.$labelCounterId.''.$noId.'';

        $labelComeback=$comeback->getAttribute('label');
        $labelComebackId = $comeback->nodeName;
        $labelComebackIdSvg = ''.$labelComebackId.''.$noId.'';

        $labelConcluClaim=$concluClaim->getAttribute('label');
        $labelConcluClaimId = $concluClaim->nodeName;
        $labelConcluClaimIdSvg = ''.$labelConcluClaimId.''.$noId.'';

        $multi=$id[1]; // = substr($id,-1)
        $argNo=$multi;
        $ypos = ($argNo * 64);
        $xpos = 0;

        $colorArgs = "#467A4B";
        $colorArgsStroke = "#467A4B";

        $colorProAll= "#467A4B";
        $colorProAllStroke= "#467A4B";
        $colorPro = "#467A4B";
        $colorProStroke = "#467A4B";
        $colorSupport = "#467A4B";
        $colorSupportStroke = "#467A4B";
        $colorRelate = "#467A4B";
        $colorRelateStroke = "#467A4B";

        $colorCounterAll= "#499BC4";
        $colorCounterAllStroke= "#499BC4";
        $colorCounter = "#499BC4";
        $colorCounterStroke = "#499BC4";
        $colorComeback='#499BC4';
        $colorComebackStroke='#499BC4';
        $colorConcluClaim='#499BC4';
        $colorConcluClaimStroke='#499BC4';
        $colorLine = "#98A48A";

        $argDis = 'arg';

// detecting if textnodes are whitespace only
        $textStateArg = $stateArg->nodeValue;
        $textStateArgNode = $dom->createTextNode("$textStateArg");
        $wsStateArg = $textStateArgNode->isWhitespaceInElementContent();

        $textSupport = $support->nodeValue;
        $textSupportNode = $dom->createTextNode("$textSupport");
        $wsSupport = $textSupportNode->isWhitespaceInElementContent();

        $textRelate = $relate->nodeValue;
        $textRelateNode = $dom->createTextNode("$textRelate");
        $wsRelate = $textRelateNode->isWhitespaceInElementContent();

        $textCounterArg = $stateCounterArg->nodeValue;
        $textCounterArgNode = $dom->createTextNode("$textCounterArg");
        $wsCounterArg = $textCounterArgNode->isWhitespaceInElementContent();

        $textComeback = $comeback->nodeValue;
        $textComebackNode = $dom->createTextNode("$textComeback");
        $wsComeback = $textComebackNode->isWhitespaceInElementContent();

        $textConcluClaim = $concluClaim->nodeValue;
        $textConcluClaimNode = $dom->createTextNode("$textConcluClaim");
        $wsConcluClaim = $textConcluClaimNode->isWhitespaceInElementContent();


// assigning COLORS - fill for filled nodes - detects whitespace  ALSO form status On/Off 467A4B=green, 499BC4=blue, cccccc=grey

              // for state argument node
              if (($wsStateArg)&&($simple_status=="Off")){$colorPro='#ffffff';$colorProStroke='#cccccc';
                } else if (($wsStateArg)&&($simple_status=="On")){$colorPro='#ffffff';$colorProStroke='#467A4B';
                } else if ((!$wsStateArg)&&($simple_status=="Off")) {$colorPro='#cccccc';$colorProStroke='#cccccc';
                } else {$colorPro='#467A4B';$colorProStroke='#467A4B';
              };
              // for support node
              if (($wsSupport)&&($simple_status=="Off")){$colorSupport='#ffffff';$colorSupportStroke='#cccccc';
                } else if (($wsSupport)&&($simple_status=="On")){$colorSupport='#ffffff';$colorSupportStroke='#467A4B';
                } else if ((!$wsSupport)&&($simple_status=="Off")) {$colorSupport='#cccccc';$colorSupportStroke='#cccccc';
                } else {$colorSupport='#467A4B';$colorSupportStroke='#467A4B';
              };

              // for relate node
              if (($wsRelate)&&($simple_status=="Off")){$colorRelate='#ffffff';$colorRelateStroke='#cccccc';
                } else if (($wsRelate)&&($simple_status=="On")){$colorRelate='#ffffff';$colorRelateStroke='#467A4B';
                } else if ((!$wsRelate)&&($simple_status=="Off")) {$colorRelate='#cccccc';$colorRelateStroke='#cccccc';
                } else {$colorRelate='#467A4B';$colorRelateStroke='#467A4B';
              };

              // for counterArg nodes
              if (($wsCounterArg)&&($counter_status=="Off")){$colorCounter='#ffffff';$colorCounterStroke='#cccccc';
                } else if (($wsCounterArg)&&($counter_status=="On")) {$colorCounter='#ffffff';$colorCounterStroke='#499BC4';
                } else if ((!$wsCounterArg)&&($counter_status=="Off")) {$colorCounter='#cccccc';$colorCounterStroke='#cccccc';
                } else {$colorCounter='#499BC4';$colorCounterStroke='#499BC4';
                };

             // for comeback
             if (($wsComeback)&&($counter_status=="Off")){$colorComeback='#ffffff';$colorComebackStroke='#cccccc';
                } else if (($wsComeback)&&($counter_status=="On")) {$colorComeback='#ffffff';$colorComebackStroke='#467A4B';
                } else if ((!$wsComeback)&&($counter_status=="Off")) {$colorComeback='#cccccc';$colorComebackStroke='#cccccc';
                } else {$colorComeback='#467A4B';$colorComebackStroke='#467A4B';
                };

             // for concluClaim
             if (($wsConcluClaim)&&($counter_status=="Off")){$colorConcluClaim='#ffffff';$colorConcluClaimStroke='#cccccc';
                } else if (($wsConcluClaim)&&($counter_status=="On")) {$colorConcluClaim='#ffffff';$colorConcluClaimStroke='#467A4B';
                } else if ((!$wsConcluClaim)&&($counter_status=="Off")) {$colorConcluClaim='#cccccc';$colorConcluClaimStroke='#cccccc';
                } else {$colorConcluClaim='#467A4B';$colorConcluClaimStroke='#467A4B';
                };


   // for group nodes
   if (($wsStateArg)||($wsRelate)){$colorProAll='#FFFFFF';}else{$colorProAll=$colorPro;};
   if ($simple_status=="Off"){$colorProAllStroke='#cccccc'; }else {$colorProAllStroke='#467A4B';};

   if (($wsCounterArg)||($wsComeback)){$colorCounterAll='#FFFFFF';}else{$colorCounterAll=$colorCounter;};
   if ($counter_status=="Off"){$colorCounterAllStroke='#cccccc'; } else {$colorCounterAllStroke='#499BC4';};

        // argument model different for first argument
        if ($id=='_1') {$argDis = 'arg1';}	else{$argDis = 'arg';};

        // retrieving and summing up the rating and option scores
        if ($rating=='strong') {$argScore=1.5;} else if ($rating=='acceptable'){$argScore=1;} else if ($rating=='weak'){$argScore=0.5;}else{$argScore=0;};
        if ($wsStateArg){$argScore=0;};
        if ($argScore==0){
                $argScore++;
//		$supportScore=NULL;
//		$relateScore=NULL;
        }
        if ($wsSupport){$argScale=$argScore;}else{$argScale=$argScore+0.5;};
        if ($wsRelate){$argScale=$argScore;}else{$argScale=$argScore+0.5;};


        //$supportScale=1; $relateScale=$relateScore
        if ($counter_rating=='strong') {$counterScore= 3;} else if ($counter_rating=='acceptable'){$counterScore= 2;}else{$counterScore= 1;};
        if ($wsCounterArg){$counterScore=0;};

        if ($comeback_rating=='strong') {$comebackScore= 3;} else if ($comeback_rating=='acceptable'){$comebackScore= 2;}else if ($comeback_rating=='weak'){$comebackScore= 1;}else{$comebackScore=0;};
        if ($wsComeback){$comebackScore=0;};

        if ($concluClaim_rating=='strong') {$conClaimScore= 3;} else if ($concluClaim_rating=='acceptable'){$conClaimScore= 2;}else if ($concluClaim_rating=='weak'){$conClaimScore= 1;}else{$conClaimScore=0;};
        if ($wsConcluClaim){$conClaimScore=0;};


        // using scores to manipulate the scaling of graphic nodes
        $ratingScale=($argScore + $counterScore + $comebackScore+$conClaimScore)/2 ;  // 1.5 >scale >1


        $argScale=$argScale;
        //   $argScore=$argScore/2;
        $supportScale=$argScore; // to adapt Arg node
        $relateScale=$argScore/2; // to adapt Arg node

        $counterScale=$counterScore/2;
        $comebackScale=$comebackScore/2;
        $conClaimScale=$conClaimScore/2;
        $conScale=($comebackScale + $counterScale+$conClaimScale/2)/2; //counterArgNode



        // to make nodes show up small and empty if value is zero
        if ($argScale<=0){
        $argScale=1;};
        if ($supportScale<=0){
        $supportScale=1;};
        if ($relateScale<=0){
        $relateScale=1;};

        if ($conScale<=0){$conScale=1;};
        if ($counterScale<=0){
        $counterScale=1;};
        if ($comebackScale<=0){
        $comebackScale=1;};
        if ($conClaimScale<=0){
        $conClaimScale=1;};

        // argument section score

        $argsScore++;
        $argsScale=$argsScore; // only taking the first arg into account

        // fill of args section

        $argsFill++;
        if (($wsStateArg)&&($wsCounterArg)){$argsFill=$argsFill-1;};



        // argsFill - filling general argument section box
        // if ($argsFill>=3){$colorArgs='#467A4B';}else{$colorArgs='#FFFFFF';}; //args box stays white



// form to call up edit argument form

// TRACE scales variables
//echo '<br/>ratingScale='.$ratingScale.'<br/> argsScale='.$argScale.'<br/> argDis='.$argDis.'<br/> argsScore='.$argsScore.', <br/> argsFill='.$argsFill.'<br/>colorArgs='.$colorArgs.'';

// TRACE form status
//  echo '<br/>'.$simple_status.'<br/>'.$counter_status.'<br/>colorPro='.$colorPro.'<br/>colorProStroke='.$colorProStroke.'<br/>colorCounter='.$colorCounter.'<br/>colorCounterStroke='.$colorCounterStroke.'<br/>colorSupportStroke='.$colorSupportStroke.'';


        echo'<form action="' . $_SERVER["PHP_SELF"] . '" method ="post" name ="edit_argument'.$id.'" id="edit_argument'.$id.'" class="whichTable">
                <table width="100%" border="0" cellspacing="0" cellpadding="3" class="underln " id="argTable'.$id.'">
                 <tr>
                 <td width="5%">
                 <input type="hidden" name="no_id" value="'. $noId .'" />
                 <input type="hidden" name="argument_id" value="'. $id .'" />
                 <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                 </td>
                 <td width="20%"><a name="arg'.$id.'"></a></td>
                 <td width="75%">
                 </td>';
// button right view
//        echo '<td width="25%" align="right">';        printf ('&#160;&#160;&#160;<a class="genTip arg-preview" href="javascript: toggleIcon(\'textHelp'.$id.'\')"><img id="imgtextHelp'.$id.'" src="../graphics/tview.png" alt="view" border="0" title="view text for this element" class="buttonText"/>&#160;'.$argumentLabel.'</a><span class="buttonText"> '.$id.'</span>')</td>;
        echo '</tr>
                <tr><td align="center" width="5%" valign="top" >';
 // buttons down side
        printf ('<a class="genTip arg-help" href="javascript: toggleLabel(\'argument'.$id.'\')"><img id="imgargument'.$id.'" src="../graphics/help.png" alt="help" title="help for this element" border="0" class="buttonText" /></a>');
        echo '<br /><div id="argument'.$id.'" class="boxArg" style="display:none; text-align:left;">';
        echo '<form action="' . $_SERVER["PHP_SELF"] . '" method ="post" name ="edit_argHelp'.$id.'" id="edit_argHelp'.$id.'">
                <input type="hidden" name="no_id" value="'. $noId .'" />
                 <input type="hidden" name="argHelp_id" value="'. $id .'" />
                 <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />';
 // argHelp form
        echo '<span class="stick">'.$argHelp.'</span>
         <textarea id="argumentHelp" class="textOff" name="argument_help" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'argumentHelp\')" onblur="changeTextClass(\'argumentHelp\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$argumentLabel.' section help text" value="" />

        <a class="genTip arg-help" id="argHelp-info" href="javascript: toggleLabel(\'argument'.$id.'\')"><img id="imgargHelp" src="../graphics/close.png"  class="buttonHelp" title="close" style="float:right" border="0" align="absbottom" /></a>
        <input id="argHelp_save" type="image" value="submit" class="buttonText" name="saveArgHelp" src="../graphics/save.png" title="save changes to '.$argumentLabel.' help text" align="middle" />&#160;&#160;
                                <input id="argHelp_cancel" type="image" value="submit" class="buttonText" name="cancelArgHelp" src="../graphics/cancel.png" title="cancel changes to '.$argumentLabel.' help text" align="middle" /></form>';
// end argHelp form
       echo '</div>';
        echo '<a class="genTip arg-edit" href="javascript: toggleForm(\'argForm'.$id.'\')"><img id="editargForm'.$id.'" src="../graphics/edit.png" alt="edit argument'.$id.'" title="edit '.$argumentLabel.''.$id.'" border="0" class="buttonText" /></a> <input id="cancelargForm'.$id.'" type="image" value="submit" class="buttonText arg-cancel" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" style="display:none;"/>';

        echo '<input type="image" value="submit" name="addArg" src="../graphics/addArg.png" border="0" title="add new '.$argumentLabel.' at end" align="absmiddle" class="buttonText"  /><br/>';

        // no delete allowed if only one argument exists -> removes delete button

        if (($noId==$argLength) && ($argLength==1)){// no delete button available
                echo'';
        } else {
                echo'<input type="image" value="submit" class="buttonText arg-delete1" name="deleteArg" src="../graphics/delete.png" border="0" title="delete '.$argumentLabel.''.$id.'" align="absmiddle" /><br/>';
        };

        // if there are no arguments to move

        if ($noId!=$dom->getElementsByTagName('argument')->length){
        echo'<input type="image" value="submit"  name="moveArgDown" src="../graphics/moveDown.png" border="0" title="move '.$argumentLabel.''.$id.' down" align="absmiddle" class="buttonText" />';}
        else { //show no button
        };

        // argsFill - filling general argument section box
           if ($argLength>=3){$colorArgs='#467A4B';}else{$colorArgs='#FFFFFF';}; //args box stays white


// END buttons
        echo '</td>';

// set class in a status related variable and adjust in css  to include simple argument or not
              $statusSimpleChecked=($simple_status=="On") ? "checked='checked'" : " "; // enable form
 //             $statusSimpleInclude=($simple_statusInclude=="formOn") ? "checked='checked'" : " "; // show form

              $statusCounterChecked=($counter_status=="On") ? "checked='checked'" : " ";
    //          $statusCounterInclude=($counter_statusInclude=="formOn") ? "checked='checked'" : " "; // enable form

 // set class in a status related variable and adjust in css  to include simple argument or not
              $stateArgWordsChecked=($stateArgWords_status=="inline") ? "checked='checked'" : " ";

        echo '<td align="left" valign="top" width="20%">';

//-- SVG start

// SVG ComplexArg
echo '<div id="complexArgSVGInclude'.$id.'" style="display:block">';
//-- SVG start
    echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='96' width='180' x='0' y='0'>";
    echo "<defs>

            <rect id='argEmpty' width='16' height='6' stroke-width='2'  />
            <rect id='conEmpty' width='16' height='6' stroke-width='2'  />
            <circle id='optionEmpty' r='5' stroke-width='2'  />

            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,40,0' />
            <polyline id='lineSm' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,16,0' />
            <polyline id='lineArgA' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,0,75' />
            <polyline id='lineArg' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,0,14,16,14' />

            <polyline id='lineCon' fill='none' stroke='$colorLine' stroke-width='2' points='0,10,16,10,16,48,32,48,32,42,48,42' />
            <polyline id='lineConA' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />
            <polyline id='lineConB' fill='none' stroke='$colorLine' stroke-width='2' points='1,4,1,20,16,20' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />
            <polyline id='lineProAc' fill='none' stroke='$colorLine' stroke-width='2' points='1,20,1,36,16,36' />

            <symbol id='args'>
                <use x='0' y='0' xlink:href='#nodeEmpty' />
            </symbol>

            <symbol id='argPro'>
                <use x='69' y='8' xlink:href='#lineSm'  />
                <use x='85' y='0' xlink:href='#lineProAa'  />
                <use x='100' y='0' xlink:href='#lineProAb'  />
                <use x='100' y='15' xlink:href='#lineProAb'  />
            </symbol>

            <symbol id='argCon'>
                <use x='69' y='8' xlink:href='#lineCon'  />
                <use x='100' y='44' xlink:href='#lineConA'  />
                <use x='100' y='60' xlink:href='#lineConB'  />
            </symbol>

            <symbol id='arg'>
                <use x='65' y='14' xlink:href='#lineArgA'  />
                <use x='65' y='0' xlink:href='#lineArg'  />
                <use x='30' y='0' xlink:href='#argPro'  />
                <use x='30' y='0' xlink:href='#argCon'  />
            </symbol>

            <symbol id='arg1'>
                <use x='65' y='14' xlink:href='#lineArgA'  />
                <use x='44' y='14' xlink:href='#line'  />
                <!-- head args -->
                <use x='0' y='0' xlink:href='#args' transform='translate(1,6) scale(".$argsScale.")' fill='".$colorArgs."' stroke='#467A4B' />
                <use x='30' y='0' xlink:href='#argPro'  />
                <use x='30' y='0' xlink:href='#argCon'  />
            </symbol>

            </defs>";

// loop to display the nodes generated by svg
        printf ('<use x="0" y="0" xlink:href="#'.$argDis.'" onmouseover="toggleIn(\''.$labelArgsIdSvg.'\')" onmouseout="toggleOut(\''.$labelArgsIdSvg.'\')" title="'.$argumentLabel.'"><title>'.$argumentLabel.'</title></use>

<use x="0" y="0" xlink:href="#argEmpty"  id="stateArgNode" transform="translate(146,2) scale('.$argScore.')" fill="'.$colorPro.'"  stroke="'.$colorProStroke.'" onmouseover="toggleIn(\''.$labelStateArgIdSvg.'\'); changeTextClass(\'stateArgText'.$id.'\')" onmouseout="toggleOut(\''.$labelStateArgIdSvg.'\'); changeTextClass(\'stateArgText'.$id.'\')"  title="'.$stateArgLabel.'"><title>'.$stateArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#optionEmpty"  id="supportNode" transform="translate(150,20)" fill="'.$colorSupport.'"   stroke="'.$colorSupportStroke.'" onmouseover="toggleIn(\''.$labelSupportIdSvg.'\'); changeTextClass(\'supportText'.$id.'\')" onmouseout="toggleOut(\''.$labelSupportIdSvg.'\'); changeTextClass(\'supportText'.$id.'\')" title="'.$supportLabel.'"><title>'.$supportLabel.'</title></use>

                <use x="0" y="0" xlink:href="#argEmpty" id="relateNode" transform="translate(146,32)" fill="'.$colorRelate.'"  stroke="'.$colorProStroke.'" onmouseover="toggleIn(\''.$labelRelateIdSvg.'\'); changeTextClass(\'relateText'.$id.'\')" onmouseout="toggleOut(\''.$labelRelateIdSvg.'\'); changeTextClass(\'relateText'.$id.'\')" title="'.$relateLabel.'"><title>'.$relateLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty"  id="counterArgNode" transform="translate(146,48) scale('.$counterScale.')" fill="'.$colorCounter.'"  stroke="'.$colorCounterStroke.'" onmouseover="toggleIn(\''.$labelCounterIdSvg.'\'); changeTextClass(\'counterText'.$id.'\')" onmouseout="toggleOut(\''.$labelCounterIdSvg.'\'); changeTextClass(\'counterText'.$id.'\')" title="'.$stateCounterArgLabel.'"><title>'.$stateCounterArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty" id="comebackNode" transform="translate(146,62) scale('.$comebackScale.')" fill="'.$colorComeback.'"  stroke="'.$colorComebackStroke.'" onmouseover="toggleIn(\''.$labelComebackIdSvg.'\'); changeTextClass(\'comebackText'.$id.'\')" onmouseout="toggleOut(\''.$labelComebackIdSvg.'\'); changeTextClass(\'comebackText'.$id.'\')" title="'.$comebackLabel.'"><title>'.$comebackLabel.'</title></use>

                <use x="0" y="0" xlink:href="#argEmpty"  id="simpleArgNode" transform="translate(82,6) scale('.$argScale.')" fill="'.$colorProAll.'" stroke="'.$colorProAllStroke.'" onmouseover="toggleIn(\''.$labelSimpleArgIdSvg.'\')" onmouseout="toggleOut(\''.$labelSimpleArgIdSvg.'\')" title="'.$simpleArgLabel.'"><title>'.$simpleArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty"  id="counterNode" transform="translate(82,15) scale('.$conScale.')" fill="'.$colorCounterAll.'" stroke="'.$colorCounterAllStroke.'" onmouseover="toggleIn(\''.$labelConArgIdSvg.'\')" onmouseout="toggleOut(\''.$labelConArgIdSvg.'\')" title="'.$counterArgLabel.'"><title>'.$counterArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#optionEmpty"  id="concluClaimNode" transform="translate(150,80) scale('.$conClaimScale.')" fill="'.$colorConcluClaim.'"   stroke="'.$colorConcluClaimStroke.'" onmouseover="toggleIn(\''.$labelConcluClaimIdSvg.'\'); changeTextClass(\'concluClaimText'.$id.'\')" onmouseout="toggleOut(\''.$labelConcluClaimIdSvg.'\'); changeTextClass(\'concluClaimText'.$id.'\')" title="'.$concluClaimLabel.'"><title>'.$concluClaimLabel.'</title></use>
                ');
        echo "</svg><br />";
        echo "</div>";
        echo '</td>';
        echo '<td width="75%" valign="top" >';

// START form edit display
        echo '<span id="argForm'.$id.'" class="boxForm" style="display:none">';
                echo '
                <form action="' . $_SERVER["PHP_SELF"] . '" method ="post" name ="save_argument" id="save_argument">
                <table width="100%" border="0" cellspacing="0" cellpadding="3">
                <input type="hidden" name="no_id" value="'. $noId .'" />
                <input type="hidden" name="argument_id" value="'. $id .'" />
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <tr><td>
                <table width="100%">
                <tr><td class="button"><a class="buttonText arg-note-edit" href="javascript: toggleNote(\'argNotepad'.$id.'\')"><img src="../graphics/note.png" alt="edit note" border="0" title="edit note'.$id.'" id="noteargNotepad'.$id.'" /></a>
                &#160;&#160;<label for="id" >'.$argumentLabel.'</label>'.$id.'

                </td>
                <td align="right">
                <input type="image" value="submit" class="buttonText arg-save" name="saveArg" src="../graphics/save.png" border="0" title="save changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;
                <input type="image" value="submit" class="buttonText arg-cancel" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" />  </td></tr></table>

        </td></tr>
                        <tr><td valign="top">';

// give activation option otherwise its active
//              echo' <br/><input type="checkbox" ' . $statusSimpleChecked . ' name="sArgActive" onclick="changeClass(\'simpleArgument'.$id.'\')" /> include activation option (otherwise area will be always activated)<br/>';

               // start argument element

               echo  '<fieldset class="'.$simple_status.'" id="simpleArgument'.$id.'">';

               echo '<div id="argNotepad'. $id .'" class="boxNote" style="display:none">
                                <fieldset class="notepad">
                                <legend>'.$argNoteLegend.''.$id.'</legend>
                                <textarea name="noteArg" cols="22" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)" placeholder="take notes here">', $noteArg->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

               echo '<legend>';

               printf (''.$simpleArgLabel.': <input  size="30"  type="text" name="simpleArg_label" placeholder="edit '.$simpleArgLabel.' label" value="" />
                 <br/><input type="checkbox" ' . $statusSimpleChecked . ' name="sArg" onclick="changeClass(\'simpleArgument'.$id.'\')" />');
                echo '<span class="inst">'.$simpleArgHelp.': <input  size="30"  type="text" name="simpleArgHelp_label" placeholder="edit '.$simpleArgHelp.' text" value="" /></span></legend>';

                // state argument
                printf('<label for="state_argument" class="boxInst"><a class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"><img id="imgstate_argument'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element"/> '.$stateArgLabel.'</a></label>: <input  size="30"  type="text" name="stateArg_label" placeholder="edit '.$stateArgLabel.' label" value="" />');
               // word list activation

                // wordlist pop open
                echo '<span ><input type="checkbox" ' . $stateArgWordsChecked . ' name="stateArgWords" onclick="toggleInline(\'stateArgWords'.$id.'\')" />activate connecting word list '.$stateArgWords_status.': ' . $stateArgWordsChecked . '';
                echo '<span class="boxPop" id="stateArgWords'.$id.'" style="display:'.$stateArgWords_status.'">';
                // info words icon and popup
                echo'<a class="tip arg-s-state-info" href="javascript: toggleInfo(\'state_argumentList'.$id.'\')"><img id="imgstate_argumentList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /></a> click to edit connecting word list</span>';
                echo'<span id="state_argument'.$id.'" class="boxPop" style="display:block">'.$stateArgHelp.'';
                printf('&#160;<a id="arg-s-state-help-close" class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                echo'</span>';

                // stateArg words
                echo'<div id="state_argumentList'.$id.'" class="boxFloat" style="display:none"><h4>'.$stateArgLabel.' </h4><p class="instruct">'.$stateArgConnectTitle.': <input type="text" name="stateArgConnect_label"  size="30" placeholder="edit '.$stateArgLabel.' word list help" value="" /></p><p class="maintext">'.$stateArgConnect.'</p>
                <textarea id="stateArgConnectList" class="textOff" name="stateArgConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'stateArgConnectList\')" onblur="changeTextClass(\'stateArgConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$stateArgLabel.' word list" value="" />';
                printf('&#160;<a id="arg-s-state-info-close" class="tip arg-s-state-info" href="javascript: toggleInfo(\'state_argumentList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                // stateArg text field
                echo '<textarea id="stateArgHelp'.$id.'" class="textOff" name="state_argumentHelp" rows="2" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'stateArgHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" onblur="changeTextClass(\'stateArgText'.$id.'\')" placeholder="edit '.$stateArgLabel.' help text" /><br/>';

                // support
                printf('<label for="support" class="boxInst"><a class="tip arg-s-support-help optional" href="javascript: toggleLabel(\'support'.$id.'\')"><img id="imgsupport'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$supportLabel.'</a></label>: <input  size="30"  type="text" name="support_label" placeholder="edit '.$supportLabel.' label" value=""  />');
                printf('<a class="tip arg-s-support-info" href="javascript: toggleInfo(\'supportList'.$id.'\')"><img id="imgsupportList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText"  title="connecting words"/> </a>');
                echo'<span id="support'.$id.'" class="boxPop" style="display:block">'.$supportHelp.'';
                printf('&#160;<a id="arg-s-support-help-close" class="tip arg-s-support-help" href="javascript: toggleLabel(\'support'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                 // support words
                echo'<div id="supportList'.$id.'" class="boxFloat" style="display:none"><h4>'.$supportLabel.' </h4><p class="instruct">'.$supportConnectTitle.': <input type="text" name="supportConnect_label"  size="30" placeholder="edit '.$supportLabel.' word list help" value="" /></p><p class="maintext">'.$supportConnect.'</p>
                <textarea id="supportConnectList" class="textOff" name="supportConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'supportConnectList\')" onblur="changeTextClass(\'supportConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$supportLabel.' word list" value="" />';
                printf('&#160;<a id="arg-s-support-info-close" class="arg-s-support-info" href="javascript: toggleInfo(\'supportList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></div>');
                // support text field
                echo '<textarea id="supportHelpText'.$id.'" class="textOff" name="support_help" rows="2" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'supportHelpText'.$id.'\')" onblur="changeTextClass(\'supportHelpText'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$supportLabel.' help text" /><br/>';

                // argument type
                printf ('<label for="type" class="boxInst"><a class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"> <img id="imgtype'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" />&#160;'.$argTypeLabel.'</a>
                    : <input  size="30"  type="text" name="argType_label" placeholder="edit '.$argTypeLabel.' label" value=""  />');
                echo '</label><span id="type'.$id.'" class="boxPop" style="display:block">'.$argTypeHelp.'<a id="argStypeHelpClose" class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a>';
                echo '</span>
                <textarea id="argTypeHelp'.$id.'" class="textOff" name="argType_help" rows="2" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'argTypeHelp'.$id.'\')" onblur="changeTextClass(\'argTypeHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$argTypeLabel.' help text" />
                <select id="typeSarg" name="type" onfocus="enableSimpleArg(this.form)" >
                                                <option selected="selected">', $argType ,'</option>
                                                <option disabled="disabled">select one</option>
                                                <option>fact</option>
                                                <option>statistics and signs</option>
                                                <option>an example</option>
                                                <option>an analogy</option>
                                                <option>cause and effect</option>
                                                <option>authority</option>
                                                <option>common values</option>
                                                <option>a need to take action</option>
                                        </select><br/>';
                // source
    // source non-print optional                            printf ('<label for="source" class="boxOptional"><a class="tip arg-s-source-help optional" href="javascript: toggleLabel(\'source'.$id.'\')"> <img id="imgsource'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$sourceLabel.'</a>: <input  size="30"  type="text" name="source_label" placeholder="edit '.$sourceLabel.' label" value=""  /></label>');

                printf ('<label for="source" class="boxInst"><a class="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"> <img id="imgsource'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$sourceLabel.'</a>: <input  size="30"  type="text" name="source_label" placeholder="edit '.$sourceLabel.' label" value=""  /></label>');
                echo '<br/><span id="source'.$id.'" class="boxPop" style="display:block">'.$sourceHelp.'<a class="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>';
                // source text
                echo '<textarea id="sourceHelp'.$id.'" class="textOff" name="source_help" rows="2" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'sourceHelp'.$id.'\')" onblur="changeTextClass(\'sourceHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$sourceLabel.' help text" /><br/>';

                // relate
                printf('<label for="relate" class="boxInst"><a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"><img id="imgrelate'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element"  /> '.$relateLabel.'</a>: <input  size="30"  type="text" name="relate_label" placeholder="edit '.$relateLabel.' label" value=""  /></label>');
                printf('<a class="tip arg-s-relate-info" href="javascript: toggleInfo(\'relateList'.$id.'\')"><img id="imgrelateList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /> </a>');
                echo'<span id="relate'.$id.'" class="boxPop" style="display:block">'.$relateHelp.'';
                printf('&#160;<a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                // relate words
                echo'<div id="relateList'.$id.'" class="boxFloat" style="display:none"><h4>'.$relateLabel.' </h4><p class="instruct">'.$relateConnectTitle.': <input type="text" name="relateConnect_label"  size="30" placeholder="edit '.$relateLabel.' word list help" value="" /></p>
                <p class="maintext">'.$relateConnect.'</p>
                <textarea id="relateConnectList" class="textOff" name="relateConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'relateConnectList\')" onblur="changeTextClass(\'relateConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$relateLabel.' word list" value="" />';
                printf('&#160;<a class="arg-s-relate-info" href="javascript: toggleInfo(\'relateList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                // relate text field
                echo '<textarea id="relateHelpText'.$id.'" class="textOff" name="relate_help" rows="2" onfocus="enableSimpleArg(this.form);textAreaAdjust(this);changeTextClass(\'relateHelpText'.$id.'\')" onblur="changeTextClass(\'relateHelpText'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$relateLabel.' help text" value="" /><br />';

                // rating
                echo '<label for="rating" class="instruct">'.$simpleArgRatingLabel.': <input type="text" name="simpleArgRating_label"  size="30" placeholder="edit '.$simpleArgRatingLabel.' label" value="" /></label> <br/>
                        <select name="rating"  onfocus="enableSimpleArg(this.form)">
                                <option selected="selected">'.$rating.'</option>
                                <option disabled="disabled">none</option>
                                <option>strong</option>
                                <option>acceptable</option>
                                <option>weak</option>
                        </select>';
                echo '</fieldset></td></tr>';
// end simple argument element

// ---------- counterargument ----------------------
                echo '<tr><td><fieldset class="'.$counter_status.'" id="counterArgument'.$id.'"><legend>';

                echo ''.$counterArgLabel.': <input  size="30"  type="text" name="counterArg_label" placeholder="edit '.$counterArgLabel.' label" value="" /><br/>';
                 printf ('<input type="checkbox" ' . $statusCounterChecked . ' name="cArg" onclick="changeClass(\'counterArgument'.$id.'\')" />');
                echo '<span class="inst">&#160;'.$counterArgHelp.'</span>: <input  size="30"  type="text" name="counterArgHelp_label" placeholder="edit '.$counterArgHelp.' text" value="" /></legend>';

                // state counterargument
                echo '<div class="boxBg">';
                printf('<label for="state_counterargument" class="boxInst"><a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"><img id="imgstate_counterargument'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$stateCounterArgLabel.'</a>: <input  size="30"  type="text" name="stateCounterArgHelp_label" placeholder="edit '.$stateCounterArgLabel.' label" value="" /></label>');
                printf('<a class="tip arg-c-state-info" href="javascript: toggleInfo(\'counterList'.$id.'\')"><img id="imgcounterList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words"/> </a>');
                echo'<span id="state_counterargument'.$id.'" class="boxPop" style="display:block">'.$stateCounterArgHelp.'';
                printf('&#160;<a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                // state counterargument words
                echo'<div id="counterList'.$id.'" class="boxFloat" style="display:none"><h4>'.$stateCounterArgLabel.' </h4><p class="instruct">'.$stateCounterArgConnectTitle.': <input type="text" name="stateCounterArgConnect_label"  size="30" placeholder="edit '.$stateCounterArgLabel.' word list help" value="" /></p>
                <p class="maintext">'.$stateCounterArgConnect.'</p>
                <textarea id="stateCounterArgConnectList" class="textOff" name="stateCounterArgConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'stateCounterArgConnectList\')" onblur="changeTextClass(\'stateCounterArgConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$stateCounterArgLabel.' word list" value="" />';
                printf('&#160;<a class="arg-c-state-info" href="javascript: toggleInfo(\'counterList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                //state counterargument textfield
                echo '<textarea  id="counterTextHelp'.$id.'" class="textOff" name="stateCounterArg_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'counterTextHelp'.$id.'\')" onblur="changeTextClass(\'counterTextHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$stateCounterArgLabel.' help text"/><br/>';

                // attack c-arg type
                printf ('<label for="attack_type" class="boxInst"><a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"> <img id="imgattack_type'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element"/> '.$attackTypeLabel.' </a> : <input  size="30"  type="text" name="attackTypeHelp_label" placeholder="edit '.$attackTypeLabel.' label" value="" /></label>');

                echo '<span id="attack_type'.$id.'" class="boxPop" style="display:block">'.$attackTypeHelp.'<a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>
                <textarea  id="attackTypeHelp'.$id.'" class="textOff" name="attackType_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'attackTypeHelp'.$id.'\')" onblur="changeTextClass(\'attackTypeHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$attackTypeLabel.' help text"/>';
                echo '<select name="attack_type" onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">', $attackType ,'</option>
                                        <option disabled="disabled">select one</option>
                                        <option>being not logical</option>
                                        <option>being untrue</option>
                                        <option>assuming that</option>
                                        <option>perhaps meaning that</option>
                                        <option>being opposed by other evidence</option>
                                        <option>alternate interpretations</option>
                                </select>
                                <p>
                        <label for="counter_rating" class="instruct">'.$counterArgRatingLabel.': <input type="text" name="counterArgRating_label"  size="30" placeholder="edit '.$counterArgRatingLabel.' label" value="" /></label>
                        <select name="counter_rating"  onfocus="enableCounterArg(this.form)">
                                <option selected="selected">'.$counter_rating.'</option>
                                <option disabled="disabled">none</option>
                                <option>strong</option>
                                <option>acceptable</option>
                                <option>weak</option>
                        </select></p>';
                echo '</div>';

               // comeback
                echo '<div class="boxBg">';
                printf('<p><label for="comeback" class="boxInst"><a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"><img id="imgcomeback'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element"/> '.$comebackLabel.'</a>: <input type="text" name="comeback_label"  size="30" placeholder="edit '.$comebackLabel.' label" value="" /></label>');
                printf('<a class="tip arg-c-comeback-info" href="javascript: toggleInfo(\'comebackList'.$id.'\')"><img id="imgcomebackList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words"/> </a>');
                echo'<span id="comeback'.$id.'" class="boxPop" style="display:block">'.$comebackHelp.'';
                printf('&#160;<a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                // comeback words
                echo'<div id="comebackList'.$id.'" class="boxFloat" style="display:none"><h4>'.$comebackLabel.'</h4><p class="instruct">'.$comebackConnectTitle.': <input type="text" name="comebackConnect_label"  size="30" placeholder="edit '.$comebackLabel.' word list help" value="" /></p>
                <p class="maintext">'.$comebackConnect.'</p>
                <textarea id="comebackConnectList" class="textOff" name="comebackConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'comebackConnectList\')" onblur="changeTextClass(\'comebackConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$comebackLabel.' word list" value="" />';
                printf('&#160;<a class="arg-c-comeback-info" href="javascript: toggleInfo(\'comebackList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></div>');
                // comeback text field
                echo '<textarea id="comebackTextHelp'.$id.'" class="textOff" name="comeback_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'comebackTextHelp'.$id.'\')" onblur="changeTextClass(\'comebackTextHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$comebackLabel.' help text" /></p>';

                // response
                printf ('<label for="response" class="boxInst"><a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"> <img id="imgresponse'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$responseTypeLabel.'</a>: <input type="text" name="responseType_label"  size="30" placeholder="edit '.$responseTypeLabel.' label" value="" /></label>');
                echo  '<span id="response'.$id.'" class="boxPop" style="display:block">'.$responseHelp.'<a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>
                <textarea id="responseTextHelp'.$id.'" class="textOff" name="responseText_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'responseTextHelp'.$id.'\')" onblur="changeTextClass(\'responseTextHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$responseTypeLabel.' help text" />';

                echo '<br/>
                        <span class="instruct">This response reveals</span>
                        <select name="response" onfocus="enableCounterArg(this.form)">
                                <option selected="selected">', $responseType ,'</option>
                                <option disabled="disabled">select one</option>
                                <option>opposing or alternate facts or evidence</option>
                                <option>other statistics, signs</option>
                                <option>a counter-example</option>
                                <option>an exception</option>
                                <option>an analogy</option>
                                <option>faulty logic</option>
                                <option>false data</option>
                                <option>assumptions made</option>
                                <option>alternate interpretations</option>
                        </select> <br/> ';


                // strategy
                printf ('<br/><label for="strategy" class="boxInst"><a class="tip arg-c-strategy-help" href="javascript: toggleLabel(\'strategy'.$id.'\')"> <img id="imgstrategy'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element" /> '.$strategyTypeLabel.'</a>: <input type="text" name="strategyType_label"  size="30" placeholder="edit '.$strategyTypeLabel.' label" value="" /></label>
                   <span id="strategy'.$id.'" class="boxPop" style="display:block">'.$strategyHelp.'<a class="tip arg-c-strategy-help" href="javascript: toggleLabel(\'strategy'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>
                    <textarea id="strategyTextHelp'.$id.'" class="textOff" name="strategyText_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'strategyTextHelp'.$id.'\')" onblur="changeTextClass(\'strategyTextHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$strategyTypeLabel.' help text" />');
                echo '<br/>
                        <span class="instruct">This '.$comebackLabel.'</span>
                        <select name="strategy" onfocus="enableCounterArg(this.form)">
                                <option selected="selected">', $strategyType ,'</option>
                                <option disabled="disabled">select one</option>
                                <option>refutes</option>
                                <option>acknowledges in part</option>
                                <option>revises claim</option>
                                <option>concedes to</option>
                        </select>


                        ';
                echo '<p>
                                <label for="comeback_rating" class="instruct">'.$comebackRatingLabel.': <input type="text" name="comebackRating_label"  size="30" placeholder="edit '.$comebackRatingLabel.' label" value="" /></label>
                                <select name="comeback_rating"  onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">'.$comeback_rating.'</option>
                                        <option disabled="disabled">none</option>
                                        <option>strong</option>
                                        <option>acceptable</option>
                                        <option>weak</option>
                                </select></p>';
                echo '</div>';

                // concluding statement
                echo '<div class="boxBg">';
                printf('<label for="concluClaim" class="boxInst"><a class="tip arg-c-concluClaim-help optional" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"><img id="imgconcluClaim'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$concluClaimLabel.'</a>: <input type="text" name="concluClaim_label"  size="30" placeholder="edit '.$concluClaimLabel.' label" value="" /></label>');
                printf('<a class="tip arg-c-concluClaim-info" href="javascript: toggleInfo(\'concluClaimList'.$id.'\')"><img id="imgconcluClaimList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /> </a>');
                echo'<span id="concluClaim'.$id.'" class="boxPop" style="display:block">'.$concluClaimHelp.'';
                printf('&#160;<a class="tip arg-c-concluClaim-help" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                // concluClaim words
                echo'<div id="concluClaimList'.$id.'" class="boxFloat" style="display:none"><h4>'.$concluClaimLabel.'</h4><p class="optional">'.$concluClaimConnectTitle.': <input type="text" name="concluClaimConnect_label"  size="30" placeholder="edit '.$concluClaimLabel.' word list help" value="" /></p><p class="maintext">'.$concluClaimConnect.'</p>
                <textarea id="concluClaimConnectList" class="textOff" name="concluClaimConnect_list" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'concluClaimConnectList\')" onblur="changeTextClass(\'concluClaimConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$concluClaimLabel.' word list" value="" />';
                printf('&#160;<a class="arg-c-concluClaim-info" href="javascript: toggleInfo(\'concluClaimList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></div>');
                // concluClaim text field
                echo '<textarea id="concluClaimHelp'.$id.'" class="textOff" name="concluClaim_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'concluClaimHelp'.$id.'\')" onblur="changeTextClass(\'concluClaimHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$concluClaimLabel.' help text" /><br/>';

                // concluClaim Type
                printf ('<label for="revise" class="boxInst"><a class="tip arg-c-revise-help" href="javascript: toggleLabel(\'revise'.$id.'\')"> <img id="imgrevise'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/>&#160;'.$reviseTypeLabel.'</a>: <input type="text" name="reviseType_label"  size="30" placeholder="edit '.$reviseTypeLabel.' label" value="" /></label>
                <span id="revise'.$id.'" class="boxPop" style="display:block">'.$reviseHelp.'<a class="tip arg-c-revise-help" href="javascript: toggleLabel(\'revise'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>
                <textarea id="reviseTextHelp'.$id.'" class="textOff" name="reviseText_help" rows="2" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'reviseTextHelp'.$id.'\')" onblur="changeTextClass(\'reviseTextHelp'.$id.'\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$reviseTypeLabel.' help text" />');
                echo '<br/>
                        <span class="instruct">Basis for '.$reviseTypeLabel.': </span>
                        <select id="typeCarg" name="concluClaimType" onfocus="enableCounterArg(this.form)" >
                                                <option selected="selected">', $concluClaimType ,'</option>
                                                <option disabled="disabled">select one</option>
                                                <option>fact</option>
                                                <option>statistics and signs</option>
                                                <option>an example</option>
                                                <option>an analogy</option>
                                                <option>cause and effect</option>
                                                <option>an authority</option>p
                                                <option>common values</option>
                                                <option>a need to take action</option>
                                        </select>';
                echo '<p>
                                <label for="concluClaim_rating" class="instruct">'.$concluClaimRatingLabel.': <input type="text" name="concluClaimRating_label"  size="30" placeholder="edit '.$concluClaimRatingLabel.' label" value="" /></label>
                                <select name="concluClaim_rating"  onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">'.$concluClaim_rating.'</option>
                                        <option disabled="disabled">none</option>
                                        <option>strong</option>
                                        <option>acceptable</option>
                                        <option>weak</option>
                                </select></p>';
                echo '</div>';
                echo '</fieldset></td></tr><tr><td colspan="2" align="center">';

                // argument form buttons
                echo '<input type="image" value="submit" class="buttonText arg-save" name="saveArg" src="../graphics/save.png" border="0" title="save changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;
                                <input type="image" value="submit" class="buttonText arg-cancel" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;';
   //   <!--          <input type="image" value="submit" class="buttonText arg-delete2" name="deleteArg" src="../graphics/delete.png" border="0" title="delete argument" align="absmiddle" />-->
        echo '</td></tr></table></form>';
        echo '</span></td>';

// END form display


        echo '</tr></table></form>';
        }
        echo'</fieldset>';

}
// END argView

// save changes to arguments section HEADINGS
function saveArgHeads($dom) {
    if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
    //   $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');
       //  REPLACE argument section label----------------------
        $arguments = $dom->getElementsByTagName('arguments')->item(0);
        if (isset($_POST['arguments_label'])&&($_POST['arguments_label']!='')) {
                $insertArgumentsLabel=$_POST['arguments_label'];
                $arguments->setAttribute('label',''.$insertArgumentsLabel.'');
        }else {	// do nothing
        };
        //  REPLACE argument label----------------------
 //      $arguments = $dom->getElementsByTagName('arguments')->item(0);
        $argument = $arguments->getElementsByTagName('argument')->item(0);
        if (isset($_POST['argument_label'])&&($_POST['argument_label']!='')) {
                $insertArgumentLabel=$_POST['argument_label'];
                $argument->setAttribute('label',''.$insertArgumentLabel.'');
        }else {	// do nothing
        };
        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
   //     argView($dom,$_POST);
}

function saveArgHelp($dom, $file) {
       if (isset($_POST['argHelp_id'])) {
                $id  = $_POST['argHelp_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);

       //REPLACE argumentHelp text ----------------------
        $arguments = $dom->getElementsByTagName('arguments')->item(0);
       $argHelp = $arguments->getElementsByTagName('argument')->item(0);
        if (isset($_POST['argument_help'])&&($_POST['argument_help']!='')) {
                $insertArgHelp=$_POST['argument_help'];
                $content = nl2br($insertArgHelp);
                $insertArgHelp = trim($content);
               $argHelp->setAttribute('help',''. $insertArgHelp .'');
        }else {	// do nothing
        };
 /*    */        //save the DOMDocument into the xml file
        $dom->save($file);
       }
}

// saves changes to ARGUMENT and goes to display view (argView)
function saveArg($dom,$file) {
        if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);
     //


        //REPLACE state_argument label----------------------
        $simpleArg = $arg->getElementsByTagName('simple_argument')->item(0);
        $stateArgLabel = $simpleArg->getElementsByTagName('state_argument')->item(0);
        $stateArg = $simpleArg->getElementsByTagName('state_argument')->item(0);

        if (isset($_POST['stateArg_label'])&&($_POST['stateArg_label']!='')) {
                $insertStateArgLabel=$_POST['stateArg_label'];
                $stateArgLabel->setAttribute('label',''. $insertStateArgLabel .'');
        //     $insertRating=$_POST['rating'];
        //     $simpleArg->setAttribute('rating',''. $insertRating .'');
        // keep form activation status
                $insertStatus=$_POST['simple_status'];
                $simpleArg->setAttribute('status',''. $insertStatus .'');
        }else {	// do nothing
        };

       // find checked status "on" or "off"
        if (isset($_POST['sArg'])&&('checked=="checked"')) {
                                $simpleArg->setAttribute('status','On');
                                }  else {
                                $simpleArg->setAttribute('status','Off');
                                }

        // find wordlist checked status to change display to "inline" or "none"
        if (isset($_POST['stateArgWords'])&&('checked=="checked"')) {
                                $stateArg->setAttribute('stateArgWordsStatus','inline');
                                }  else {
                                $stateArg->setAttribute('stateArgWordsStatus','none');
                                }


        //REPLACE simple_arg rating label----------------------
        $simpleArgRatingLabel = $arg->getElementsByTagName('simple_argument')->item(0);
        if (isset($_POST['simpleArgRating_label'])&&($_POST['simpleArgRating_label']!='')) {
                $insertSimpleArgRatingLabel=$_POST['simpleArgRating_label'];
                $simpleArgRatingLabel->setAttribute('ratingLabel',''. $insertSimpleArgRatingLabel .'');
        }else {	// do nothing
        };
        //REPLACE simple_arg label----------------------
        $simpleArgLabel = $arg->getElementsByTagName('simple_argument')->item(0);
        if (isset($_POST['simpleArg_label'])&&($_POST['simpleArg_label']!='')) {
                $insertSimpleArgLabel=$_POST['simpleArg_label'];
                $simpleArgLabel->setAttribute('label',''. $insertSimpleArgLabel .'');
        }else {	// do nothing
        };
        //REPLACE simpleArgHelp_label ----------------------
        $simpleArgHelp = $arg->getElementsByTagName('simple_argument')->item(0);
        //  $stateArgLabel = $simpleArg->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['simpleArgHelp_label'])&&($_POST['simpleArgHelp_label']!='')) {
                $insertSimpleArgHelp=$_POST['simpleArgHelp_label'];
                $content = nl2br($insertSimpleArgHelp);
                $insertSimpleArgHelp = trim($content);
                $simpleArgHelp->setAttribute('help',''. $insertSimpleArgHelp .'');
        }else {	// do nothing
        };

         //REPLACE state_argumentHelp text ----------------------
        $stateArgHelp=$simpleArg->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['state_argumentHelp'])&&($_POST['state_argumentHelp']!='')){
                $insertStateArgHelp=$_POST['state_argumentHelp'];
                $stateArgHelp->setAttribute('help',''. $insertStateArgHelp .'');
        }else{ //do nothing
        };

       //REPLACE stateArgConnect_label connective title text --------------------
        $stateArgConnectTitle = $dom->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['stateArgConnect_label'])&&($_POST['stateArgConnect_label']!='')) {
                $insertstateArgConnectTitle=$_POST['stateArgConnect_label'];
                $stateArgConnectTitle->setAttribute('connectiveTitle',''. $insertstateArgConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE stateArgConnect_list connective list --------------------
        $stateArgConnect = $dom->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['stateArgConnect_list'])&&($_POST['stateArgConnect_list']!='')) {
                $insertstateArgConnect=$_POST['stateArgConnect_list'];
                $content = nl2br($insertstateArgConnect);
                $insertstateArgConnect = trim($content);
                $stateArgConnect->setAttribute('connective',''. $insertstateArgConnect .'');
                }else {	// do nothing
                };

        //  REPLACE support label----------------------
        $supportLabel = $dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['support_label'])&&($_POST['support_label']!='')) {
                $insertSupportLabel=$_POST['support_label'];
                $supportLabel->setAttribute('label',''.$insertSupportLabel.'');
        }else {	// do nothing
        };

        //REPLACE support_help text ----------------------
        $supportHelp=$dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['support_help'])&&($_POST['support_help']!='')){
                $insertSupportHelp=$_POST['support_help'];
                $supportHelp->setAttribute('help',''. $insertSupportHelp .'');
        }else{ //do nothing
        };
         //REPLACE supportConnect_label connective title text --------------------
        $supportConnectTitle = $dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['supportConnect_label'])&&($_POST['supportConnect_label']!='')) {
                $insertSupportConnectTitle=$_POST['supportConnect_label'];
                $supportConnectTitle->setAttribute('connectiveTitle',''. $insertSupportConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE supportConnect_list connective list --------------------
        $supportConnect = $dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['supportConnect_list'])&&($_POST['supportConnect_list']!='')) {
                $insertsupportConnect=$_POST['supportConnect_list'];
                $content = nl2br($insertsupportConnect);
                $insertsupportConnect = trim($content);
                $supportConnect->setAttribute('connective',''. $insertsupportConnect .'');
                }else {	// do nothing
                };

        //  REPLACE argType label ----------------------
        $argTypeLabel = $dom->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['argType_label'])&&($_POST['argType_label']!='')) {
                $insertArgTypeLabel=$_POST['argType_label'];
                $argTypeLabel->setAttribute('argTypeLabel',''.$insertArgTypeLabel.'');
        }else {	// do nothing
        };
         //REPLACE argType_help text ----------------------
        $argTypeHelp=$dom->getElementsByTagName('state_argument')->item(0);
        if (isset($_POST['argType_help'])&&($_POST['argType_help']!='')){
                $insertArgTypeHelp=$_POST['argType_help'];
                $content = nl2br($insertArgTypeHelp);
                $insertArgTypeHelp = trim($content);
                $argTypeHelp->setAttribute('typeHelp',''. $insertArgTypeHelp .'');
        }else{ //do nothing
        };

         //  REPLACE source label ----------------------
        $sourceLabel = $dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['source_label'])&&($_POST['source_label']!='')) {
                $insertSourceLabel=$_POST['source_label'];
                $sourceLabel->setAttribute('sourceLabel',''.$insertSourceLabel.'');
        }else {	// do nothing
        };
        $sourceHelp = $dom->getElementsByTagName('support')->item(0);
        if (isset($_POST['source_help'])&&($_POST['source_help']!='')) {
                $insertSourceHelp=$_POST['source_help'];
                $sourceHelp->setAttribute('sourceHelp',''.$insertSourceHelp.'');
        }else {	// do nothing
        };
         //  REPLACE relate label----------------------
        $relateLabel = $dom->getElementsByTagName('relate')->item(0);
        if (isset($_POST['relate_label'])&&($_POST['relate_label']!='')) {
                $insertRelateLabel=$_POST['relate_label'];
                $relateLabel->setAttribute('label',''.$insertRelateLabel.'');
        }else {	// do nothing
        };

        //REPLACE relate_help text ----------------------
        $relateHelp=$dom->getElementsByTagName('relate')->item(0);
        if (isset($_POST['relate_help'])&&($_POST['relate_help']!='')){
                $insertRelateHelp=$_POST['relate_help'];
                $relateHelp->setAttribute('help',''. $insertRelateHelp .'');
        }else{ //do nothing
        };
         //REPLACE relateConnect_label connective title text --------------------
        $relateConnectTitle = $dom->getElementsByTagName('relate')->item(0);
        if (isset($_POST['relateConnect_label'])&&($_POST['relateConnect_label']!='')) {
                $insertRelateConnectTitle=$_POST['relateConnect_label'];
                $relateConnectTitle->setAttribute('connectiveTitle',''. $insertRelateConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE relateConnect_list connective list --------------------
        $relateConnect = $dom->getElementsByTagName('relate')->item(0);
        if (isset($_POST['relateConnect_list'])&&($_POST['relateConnect_list']!='')) {
                $insertrelateConnect=$_POST['relateConnect_list'];
                $content = nl2br($insertrelateConnect);
                $insertrelateConnect = trim($content);
                $relateConnect->setAttribute('connective',''. $insertrelateConnect .'');
                }else {	// do nothing
                };


        //REPLACE state_counterargument and its attribute --------------------------
        // retrieved parent element arg
        $counterArg=$arg->getElementsByTagName('counterargument')->item(0);
        //retrieve the first element with name state_argument to be replaced
        $stateCounterArg = $counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['state_counterargument'])){
                $insertStateCounterArg=$_POST['state_counterargument'];
                $stateCounterArg->nodeValue = $insertStateCounterArg;
                $insertAttackType = $_POST['attack_type'];
                $stateCounterArg->setAttribute('attack_type',''. $insertAttackType .'');
                $insertCounterRating = $_POST['counter_rating'];
                $stateCounterArg->setAttribute('rating',''. $insertCounterRating .'');
                $counterStatus = $_POST['counter_status'];
                $counterArg->setAttribute('status',''. $counterStatus .'');
                $insertStatusInclude=$_POST['counter_statusInclude'];

        }else{ //do nothing
        };

        //REPLACE counterargument label----------------------
        // retrieved parent element arg
        $counterArg=$arg->getElementsByTagName('counterargument')->item(0);
        //retrieve the first element with name state_argument to be replaced
        $counterArgLabel = $dom->getElementsByTagName('counterargument')->item(0);
        if (isset($_POST['counterArg_label'])&&($_POST['counterArg_label']!='')) {
                $insertCounterArgLabel=$_POST['counterArg_label'];
                $counterArgLabel->setAttribute('label',''. $insertCounterArgLabel .'');
        }else {	// do nothing
        };
        //REPLACE counterArgHelp_label ----------------------
      $counterArgHelp = $dom->getElementsByTagName('counterargument')->item(0);
        if (isset($_POST['counterArgHelp_label'])&&($_POST['counterArgHelp_label']!='')) {
                $insertCounterArgHelp=$_POST['counterArgHelp_label'];
                $counterArgHelp->setAttribute('help',''. $insertCounterArgHelp .'');
        }else {	// do nothing
        };

          if (isset($_POST['cArg'])&&('checked=="checked"')) {
                                $counterArg->setAttribute('status','On');
                                }  else {
                                $counterArg->setAttribute('status','Off');
                                }

      //REPLACE stateCounterArgHelp_label label ----------------------
        $stateCounterArgLabel=$counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['stateCounterArgHelp_label'])&&($_POST['stateCounterArgHelp_label']!='')){
                $insertStateCounterArgLabel=$_POST['stateCounterArgHelp_label'];
                $stateCounterArgLabel->setAttribute('label',''. $insertStateCounterArgLabel .'');
        }else{ //do nothing
        };

    //REPLACE state_counterargumentHelp text ----------------------
        $stateCounterArgHelp=$counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['stateCounterArg_help'])&&($_POST['stateCounterArg_help']!='')){
                $insertStateCounterArgHelp=$_POST['stateCounterArg_help'];
                $stateCounterArgHelp->setAttribute('help',''. $insertStateCounterArgHelp .'');
        }else{ //do nothing
        };

       //REPLACE stateCounterArgConnect_label connective title text --------------------
        $stateCounterArgConnectTitle = $dom->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['stateCounterArgConnect_label'])&&($_POST['stateCounterArgConnect_label']!='')) {
                $insertCounterArgConnectTitle=$_POST['stateCounterArgConnect_label'];
                $stateCounterArgConnectTitle->setAttribute('connectiveTitle',''. $insertCounterArgConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE stateCounterArgConnect_list connective list --------------------
        $stateCounterArgConnect = $dom->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['stateCounterArgConnect_list'])&&($_POST['stateCounterArgConnect_list']!='')) {
                $insertCounterArgConnect=$_POST['stateCounterArgConnect_list'];
                $content = nl2br($insertCounterArgConnect);
                $insertCounterArgConnect = trim($content);
                $stateCounterArgConnect->setAttribute('connective',''. $insertCounterArgConnect .'');
                }else {	// do nothing
                };

        //REPLACE attackType label ----------------------
        $attackTypeLabel=$counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['attackTypeHelp_label'])&&($_POST['attackTypeHelp_label']!='')){
                $insertAttackTypeLabel=$_POST['attackTypeHelp_label'];
                $attackTypeLabel->setAttribute('attackTypeLabel',''. $insertAttackTypeLabel .'');
        }else{ //do nothing
        };

    //REPLACE attackType help text ----------------------
        $attackTypeHelp=$counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['attackType_help'])&&($_POST['attackType_help']!='')){
                $insertAttackTypeHelp=$_POST['attackType_help'];
                $content = nl2br($insertAttackTypeHelp);
                $insertAttackTypeHelp = trim($content);
                $attackTypeHelp->setAttribute('attackHelp',''. $insertAttackTypeHelp .'');
        }else{ //do nothing
        };

        //REPLACE counterArgRating label ----------------------
        $counterArgRatingLabel=$counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['counterArgRating_label'])&&($_POST['counterArgRating_label']!='')){
                $insertCounterArgRatingLabel=$_POST['counterArgRating_label'];
                $counterArgRatingLabel->setAttribute('ratingLabel',''. $insertCounterArgRatingLabel .'');
        }else{ //do nothing
        };

       //REPLACE comeback_label label ----------------------
        $comebackLabel=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comeback_label'])&&($_POST['comeback_label']!='')){
                $insertComebackLabel=$_POST['comeback_label'];
                $comebackLabel->setAttribute('label',''. $insertComebackLabel .'');
        }else{ //do nothing
        };
    //REPLACE comebackHelp help text ----------------------
        $comebackHelp=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comeback_help'])&&($_POST['comeback_help']!='')){
                $insertComebackHelp=$_POST['comeback_help'];
                $content = nl2br($insertComebackHelp);
                $insertComebackHelp = trim($content);
                $comebackHelp->setAttribute('help',''. $insertComebackHelp .'');
        }else{ //do nothing
        };

       //REPLACE comeback Connect_label connective title text --------------------
        $comebackConnectTitle = $dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comebackConnect_label'])&&($_POST['comebackConnect_label']!='')) {
                $insertComebackConnectTitle=$_POST['comebackConnect_label'];
                $comebackConnectTitle->setAttribute('connectiveTitle',''. $insertComebackConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE comebackConnect_list connective list --------------------
        $comebackConnect = $dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comebackConnect_list'])&&($_POST['comebackConnect_list']!='')) {
                $insertComebackConnect=$_POST['comebackConnect_list'];
                $content = nl2br($insertComebackConnect);
                $insertComebackConnect = trim($content);
                $comebackConnect->setAttribute('connective',''. $insertComebackConnect .'');
                }else {	// do nothing
                };

         //REPLACE responseType label ----------------------
        $responseTypeLabel=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['responseType_label'])&&($_POST['responseType_label']!='')){
                $insertResponseTypeLabel=$_POST['responseType_label'];
                $responseTypeLabel->setAttribute('responseTypeLabel',''. $insertResponseTypeLabel .'');
        }else{ //do nothing
        };

        //REPLACE responseHelp help text ----------------------
        $responseHelp=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['responseText_help'])&&($_POST['responseText_help']!='')){
                $insertResponseHelp=$_POST['responseText_help'];
                $content = nl2br($insertResponseHelp);
                $insertResponseHelp = trim($content);
                $responseHelp->setAttribute('responseHelp',''. $insertResponseHelp .'');
        }else{ //do nothing
        };

       //REPLACE strategyType label ----------------------
        $strategyTypeLabel=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['strategyType_label'])&&($_POST['strategyType_label']!='')){
                $insertStrategyTypeLabel=$_POST['strategyType_label'];
                $strategyTypeLabel->setAttribute('strategyTypeLabel',''. $insertStrategyTypeLabel .'');
        }else{ //do nothing
        };

        //REPLACE strategyHelp help text ----------------------
        $strategyHelp=$dom->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['strategyText_help'])&&($_POST['strategyText_help']!='')){
                $insertStrategyHelp=$_POST['strategyText_help'];
                $content = nl2br($insertStrategyHelp);
                $insertStrategyHelp = trim($content);
                $strategyHelp->setAttribute('strategyHelp',''. $insertStrategyHelp .'');
        }else{ //do nothing
        };

        //REPLACE comebackRating label ----------------------
        $comebackRatingLabel=$counterArg->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comebackRating_label'])&&($_POST['comebackRating_label']!='')){
                $insertComebackRatingLabel=$_POST['comebackRating_label'];
                $comebackRatingLabel->setAttribute('ratingLabel',''. $insertComebackRatingLabel .'');
        }else{ //do nothing
        };

         //REPLACE concluClaim_label label ----------------------
        $concluClaimLabel=$dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaim_label'])&&($_POST['concluClaim_label']!='')){
                $insertconcluClaimLabel=$_POST['concluClaim_label'];
                $concluClaimLabel->setAttribute('label',''. $insertconcluClaimLabel .'');
        }else{ //do nothing
        };

       //REPLACE reviseType label ----------------------
        $reviseTypeLabel=$dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['reviseType_label'])&&($_POST['reviseType_label']!='')){
                $insertReviseTypeLabel=$_POST['reviseType_label'];
                $reviseTypeLabel->setAttribute('reviseTypeLabel',''. $insertReviseTypeLabel .'');
        }else{ //do nothing
        };

      //REPLACE reviseHelp help text ----------------------
        $reviseHelp=$dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['reviseText_help'])&&($_POST['reviseText_help']!='')){
                $insertReviseHelp=$_POST['reviseText_help'];
                $content = nl2br($insertReviseHelp);
                $insertReviseHelp = trim($content);
                $reviseHelp->setAttribute('reviseHelp',''. $insertReviseHelp .'');
        }else{ //do nothing
        };
/*    */

         //REPLACE comebackHelp help text ----------------------
        $concluClaimHelp=$dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaim_help'])&&($_POST['concluClaim_help']!='')){
                $insertConcluClaimHelp=$_POST['concluClaim_help'];
                $content = nl2br($insertConcluClaimHelp);
                $insertConcluClaimHelp = trim($content);
                $concluClaimHelp->setAttribute('help',''. $insertConcluClaimHelp .'');
        }else{ //do nothing
        };

     //REPLACE concluClaim Connect_label connective title text --------------------
        $concluClaimConnectTitle = $dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaimConnect_label'])&&($_POST['concluClaimConnect_label']!='')) {
                $insertConcluClaimConnectTitle=$_POST['concluClaimConnect_label'];
                $concluClaimConnectTitle->setAttribute('connectiveTitle',''. $insertConcluClaimConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE concluClaimConnect_list connective list --------------------
        $concluClaimConnect = $dom->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaimConnect_list'])&&($_POST['concluClaimConnect_list']!='')) {
                $insertconcluClaimConnect=$_POST['concluClaimConnect_list'];
                $content = nl2br($insertconcluClaimConnect);
                $insertconcluClaimConnect = trim($content);
                $concluClaimConnect->setAttribute('connective',''. $insertconcluClaimConnect .'');
                }else {	// do nothing
                };

       //REPLACE concluClaimRating label ----------------------
        $concluClaimRatingLabel=$counterArg->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaimRating_label'])&&($_POST['concluClaimRating_label']!='')){
                $insertConcluClaimRatingLabel=$_POST['concluClaimRating_label'];
                $concluClaimRatingLabel->setAttribute('ratingLabel',''. $insertConcluClaimRatingLabel .'');
        }else{ //do nothing
        };

 // set SVG complex arg

  /*      if (isset(($_POST['sArgInclude'])&&('checked=="checked"'))&&(($_POST['cArgInclude'])&&('checked=="checked"')) ) {
                                $simpleArg->setAttribute('statusInclude','formOn');
                                $counterArg->setAttribute('statusInclude','formOn');
                                }  else {
                                $simpleArg->setAttribute('statusInclude','formOff');
                                $counterArg->setAttribute('statusInclude','formOff');
                                }

  /*
  // csaw retrievals
  //REPLACE comeback and its attributes --------------------------
        // retrieved parent element counter_argument
        //retrieve the first element with name comeback to be replaced
        $comeback = $counterArg->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comeback'])){
                $insertComeback=$_POST['comeback'];
                $comeback->nodeValue = $insertComeback;
                $insertStrategy = $_POST['strategy'];
                $comeback->setAttribute('strategy',''. $insertStrategy .'');
                $comebackRating = $_POST['comeback_rating'];
                $comeback->setAttribute('rating',''. $comebackRating .'');
        }else{ //do nothing
        };

         //REPLACE concluding claim and its attributes --------------------------
        // retrieved parent element counter_argument
        //retrieve the first element with name concluClaim to be replaced
        $concluClaim = $counterArg->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaim'])){
                $insertConcluClaim=$_POST['concluClaim'];
                $concluClaim->nodeValue = $insertConcluClaim;
                $insertRevise= $_POST['concluClaimType'];
                $concluClaim->setAttribute('revise',''. $insertRevise .'');
                $concluClaimRating = $_POST['concluClaim_rating'];
                $concluClaim->setAttribute('rating',''. $concluClaimRating .'');
        }else{ //do nothing
        };
  */
        //REPLACE notepad for argument-----------------------------
        $noteArg = $arg->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteArg'])){
                $insertNoteArg=$_POST['noteArg'];
                $content = nl2br($insertNoteArg);
                $insertNoteArg = trim($content);
                $noteArg->nodeValue = $insertNoteArg;
                $insertNoteId = "noteArg$id";
                $noteArg->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        argView($dom);
        }
}


// deleteArg - ARGUMENT - delete an argument
// testidValue - deletes an ARGUMENT only if there is more than 1 -> when id is more than 1
function deleteArg($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);

if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);
                //remove argument with id retreived above
                $oldArgs = $arguments->removeChild($arg);

//	$noId= $dom->getElementsByTagName('argument')->length;

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        argView($dom);
        }
}

// moveArgDown - ARGUMENT - moves argument down one step
function moveArgDown($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);
                $arg=$dom->getElementsByTagName('argument');
if (isset($_POST['argument_id'])) {
$id  = $_POST['argument_id'];
                $noId  = $_POST['no_id'];
                $itemId = $noId-1;  //match item no. to id selection
                $itemIdNext = $itemId+1;

                $argUnder = $arg->item($itemId);
                $argAbove = $arg->item($itemIdNext);
                $parent = $arg->item(0)->parentNode;

                $parent->insertBefore($argAbove, $argUnder);

        //save the DOMDocument into the xml file
        $dom->save($file);
 //	echo "clicked: $noId, itemsent: $itemId , 	inserted before item: $itemIdNext "; // testing variables
        //show text view
        argView($dom);
        }
}
// addArg = ARGUMENT - adds argument at end and displays (argDisplay)
function addArg($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);
                $argument = $dom->getElementsByTagName('argument')->item(0);

        if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);

                //adjusting the new id
                $noId= $dom->getElementsByTagName('argument')->length;
                $noId++;
                $newId='_'.$noId.'';
                // for testing increments
   //             $itemId = $noId+1;  //match item no. to id selection
    //            $itemIdNew = $itemId+1;

                //labels
                $argumentLabel = $arguments->getElementsByTagName('argument')->item(0)->getAttribute('label');
                // help text variables to modify for language to TRANSLATE
                $argHelp = $arguments->getElementsByTagName('argument')->item(0)->getAttribute('help');
                $simpleArgLabel =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('label');
                $simpleArgHelp =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('help');
                $simple_statusInclude=$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('statusInclude'); // only in writer version??
                $simpleArgRatingLabel =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('ratingLabel');

                $stateArgLabel=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('label');
                $stateArgHelp=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('help');
                $stateArgConnectTitle=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('connectiveTitle');
                $stateArgConnect=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('connective');

                $stateArgWordsStatus=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('stateArgWordsStatus');
                $argType=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('type');
                $argTypeHelp= $argument->getElementsByTagName('state_argument')->item(0)->getAttribute('typeHelp');
                $argTypeLabel= $argument->getElementsByTagName('state_argument')->item(0)->getAttribute('argTypeLabel');

                $supportLabel= $argument->getElementsByTagName('support')->item(0)->getAttribute('label');
                $supportHelp= $argument->getElementsByTagName('support')->item(0)->getAttribute('help');
                $supportConnectTitle=$argument->getElementsByTagName('support')->item(0)->getAttribute('connectiveTitle');
                $supportConnect=$argument->getElementsByTagName('support')->item(0)->getAttribute('connective');

                $sourceLabel= $argument->getElementsByTagName('support')->item(0)->getAttribute('sourceLabel');
                $sourceHelp= $argument->getElementsByTagName('support')->item(0)->getAttribute('sourceHelp');
                $source=$argument->getElementsByTagName('support')->item(0)->getAttribute('source');
                $relateLabel = $argument->getElementsByTagName('relate')->item(0)->getAttribute('label');
                $relateHelp = $argument->getElementsByTagName('relate')->item(0)->getAttribute('help');
                $relateConnectTitle=$argument->getElementsByTagName('relate')->item(0)->getAttribute('connectiveTitle');
                $relateConnect=$argument->getElementsByTagName('relate')->item(0)->getAttribute('connective');

                $counterArgLabel=$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('label');
                $counterArgHelp =$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('help');
                $counter_statusInclude==$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('statusInclude'); // only in writer version??

                $stateCounterArgHelp = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('help');
                $stateCounterArgLabel= $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('label');;
                $stateCounterArgConnectTitle=$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('connectiveTitle');
                $stateCounterArgConnect=$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('connective');
                $counterArgRatingLabel =$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('ratingLabel');

                $attackType = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attack_type');
                $attackTypeLabel = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attackTypeLabel');
                $attackTypeHelp = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attackHelp');

                $comebackLabel = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('label');
                $comebackHelp = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('help');
                $comebackConnectTitle=$argument->getElementsByTagName('comeback')->item(0)->getAttribute('connectiveTitle');
                $comebackConnect=$argument->getElementsByTagName('comeback')->item(0)->getAttribute('connective');
                $responseTypeLabel =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('responseTypeLabel');
                $responseHelp =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('responseHelp');
                $responseType = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('response');
                $strategyTypeLabel = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategyTypeLabel');
                $strategyType = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategy');
                $strategyHelp = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategyHelp');
                $comebackRatingLabel =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('ratingLabel');

                $concluClaimLabel=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('label');
                $concluClaimHelp=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('help');
                $concluClaimConnectTitle=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('connectiveTitle');
                $concluClaimConnect=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('connective');
                $reviseTypeLabel=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('reviseTypeLabel');
                $reviseType=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('revise');
                $reviseHelp=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('reviseHelp');
                $concluClaimRatingLabel =$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('ratingLabel');


        $newArg= $dom->createElement('argument');
        $newArg->setAttribute('id',''. $newId.'');
        $newArg->setAttribute('label',''.$argumentLabel.'');
        $newArg->setAttribute('help',''.$argHelp.'');

        $simpleArg = $dom->createElement('simple_argument');
        $simpleArg->setAttribute('label',''.$simpleArgLabel.'');
        $simpleArg->setAttribute('rating','none');
        $simpleArg->setAttribute('status','Off');
        $simpleArg->setAttribute('statusInclude','formOn');
        $simpleArg->setAttribute('content','Empty');
        $simpleArg->setAttribute('help',''.$simpleArgHelp.'');
        $simpleArg->setAttribute('ratingLabel',''.$simpleArgRatingLabel.'');


        $stateArg = $dom->createElement('state_argument');
        $stateArg->setAttribute('label',''.$stateArgLabel.'');
        $stateArg->setAttribute('help',''.$stateArgHelp.'');
        $stateArg->setAttribute('connectiveTitle',''.$stateArgConnectTitle.'');
        $stateArg->setAttribute('connective',''.$stateArgConnect.'');

        $stateArg->setAttribute('stateArgWordsStatus',''.$stateArgWordsStatus.'');
       //  $stateArg->setAttribute('stateArgWordsStatus','none'); if to be always off when new

        $stateArg->setAttribute('type','select one');
        $stateArg->setAttribute('typeHelp',''.$argTypeHelp.'');
        $stateArg->setAttribute('argTypeLabel',''.$argTypeLabel.'');

        $support = $dom->createElement('support');
        $support->setAttribute('label',''.$supportLabel.'');
        $support->setAttribute('source','');
        $support->setAttribute('help',''.$supportHelp.'');
        $support->setAttribute('sourceLabel',''.$sourceLabel.'');
        $support->setAttribute('sourceHelp',''.$sourceHelp.'');
        $support->setAttribute('connectiveTitle',''.$supportConnectTitle.'');
        $support->setAttribute('connective',''.$supportConnect.'');

        $relate = $dom->createElement('relate');
        $relate->setAttribute('label',''.$relateLabel.'');
        $relate->setAttribute('help',''.$relateHelp.'');
        $relate->setAttribute('connectiveTitle',''.$relateConnectTitle.'');
        $relate->setAttribute('connective',''.$relateConnect.'');

        $counterArg = $dom->createElement('counterargument');
        $counterArg->setAttribute('label',''.$counterArgLabel.'');
        $counterArg->setAttribute('help',''.$counterArgHelp.'');
        $counterArg->setAttribute('status','Off');
        $counterArg->setAttribute('statusInclude','formOn');


        $stateCounterArg = $dom->createElement('state_counterargument');
        $stateCounterArg->setAttribute('label',''.$stateCounterArgLabel.'');
        $stateCounterArg->setAttribute('help',''.$stateCounterArgHelp.'');
        $stateCounterArg->setAttribute('attack_type','select one');
        $stateCounterArg->setAttribute('attackHelp',''.$attackTypeHelp.'');
        $stateCounterArg->setAttribute('attackTypeLabel',''.$attackTypeLabel.'');
        $stateCounterArg->setAttribute('rating','none');
        $stateCounterArg->setAttribute('ratingLabel',''.$counterArgRatingLabel.'');

        $stateCounterArg->setAttribute('content','Empty');
        $stateCounterArg->setAttribute('connectiveTitle',''.$stateCounterArgConnectTitle.'');
        $stateCounterArg->setAttribute('connective',''.$stateCounterArgConnect.'');

        $comeback = $dom->createElement('comeback');
        $comeback->setAttribute('label',''.$comebackLabel.'');
        $comeback->setAttribute('help',''.$comebackHelp.'');
        $comeback->setAttribute('connectiveTitle',''.$comebackConnectTitle.'');
        $comeback->setAttribute('connective',''.$comebackConnect.'');
        $comeback->setAttribute('rating','none');
        $comeback->setAttribute('ratingLabel',''.$comebackRatingLabel.'');
        $comeback->setAttribute('strategy','select one');
        $comeback->setAttribute('strategyHelp',''.$strategyHelp.'');
                        $comeback->setAttribute('strategyTypeLabel',''.$strategyTypeLabel.'');

        $comeback->setAttribute('response','select one');
        $comeback->setAttribute('responseHelp',''.$responseHelp.'');
               $comeback->setAttribute('responseTypeLabel',''.$responseTypeLabel.'');

        $concluClaim = $dom->createElement('concluClaim');
        $concluClaim->setAttribute('label',''.$concluClaimLabel.'');
        $concluClaim->setAttribute('help',''.$concluClaimHelp.'');
        $concluClaim->setAttribute('connectiveTitle',''.$concluClaimConnectTitle.'');
        $concluClaim->setAttribute('connective',''.$concluClaimConnect.'');
        $concluClaim->setAttribute('rating','none');
        $concluClaim->setAttribute('ratingLabel',''.$concluClaimRatingLabel.'');
        $concluClaim->setAttribute('reviseTypeLabel',''.$reviseTypeLabel.'');
        $concluClaim->setAttribute('revise','select one');
        $concluClaim->setAttribute('reviseHelp',''.$reviseHelp.'');

        $notepad = $dom->createElement('notepad');
        $notepad->setAttribute('id','noteArg'.$newId.'');
        $notepad->setAttribute('legend','notepad for '.$argumentLabel.'');
        $notepad->setAttribute('label','notes for '.$concluClaimLabel.'');

        $arguments->appendChild($newArg);
                $newArg->appendChild($simpleArg);
                        $simpleArg->appendChild($stateArg);
                        $simpleArg->appendChild($support);
                        $simpleArg->appendChild($relate);
                $newArg->appendChild($counterArg);
                        $counterArg->appendChild($stateCounterArg);
                        $counterArg->appendChild($comeback);
                        $counterArg->appendChild($concluClaim);
                $newArg->appendChild($notepad);

        //save the DOMDocument into the xml file
        $dom->save($file);
 //   	echo "clicked: $noId, itemsent: $itemId , 	inserted as item: $itemIdNew "; // testing variables

        //show edit view
        argView($dom);
        }
}

// argButtons - ARGUMENT - sets the links in anchored links buttons
function argButtons($dom){
        $argument = $dom->getElementsByTagName('argument');
        $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');
        $noId= 0;
        $args =  $dom->getElementsByTagName('arguments');
        $argsFill = 0;
        $argLength=$dom->getElementsByTagName('argument')->length;

// TRACE args box related variables
//echo '<p>argsLength='.$argLength.', argsFill='.$argsFill.' </p>';     //argsFill undefined

foreach ($argument as $arg){
        $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');
        $noId++;
        $argsFill ++;
        echo '<a href="#arg_'.$noId.'" class="button">&#160;'.$argumentLabel .' '.$noId.'&#160;</a>&#160;&#160;';
        }
}

//-----------end ARGUMENTs ------------------------------------------------


//-----------CONCLUSION ------------------------------------------------
// CONCLUSION - displays graphic and offers edit and view text help options
function conView($dom){

        $conclusion = $dom->getElementsByTagName('conclusion');

foreach ($conclusion as $con){
        $thesis_summary=$con->getElementsByTagName('thesis_summary')->item(0);
        $argument_summary = $con->getElementsByTagName('argument_summary')->item(0);
        $consequences = $con->getElementsByTagName('consequences')->item(0);
        $closing = $con->getElementsByTagName('closing')->item(0);
        $noteCon = $con->getElementsByTagName('notepad')->item(0);
        $concluLabel=$con->getAttribute('label');

        //labels and help
        $summaryLabel = $con->getAttribute('summaryLabel');
        $argSumLabel = $con->getAttribute('argSumLabel');
        $thesis_summaryLabel = $thesis_summary->getAttribute('label');
        $thesis_summaryHelp=$thesis_summary->getAttribute('help');
        $thesis_summaryConnectTitle=$thesis_summary->getAttribute('connectiveTitle');
        $thesis_summaryConnect=$thesis_summary->getAttribute('connective');

        $argument_summaryLabel = $argument_summary->getAttribute('label');
        $argument_summaryHelp = $argument_summary->getAttribute('help');
        $argument_summaryConnectTitle=$argument_summary->getAttribute('connectiveTitle');
        $argument_summaryConnect=$argument_summary->getAttribute('connective');

        $consqLabel = $consequences->getAttribute('label');
        $consqHelp = $consequences->getAttribute('help');
        $consqConnectTitle=$consequences->getAttribute('connectiveTitle');
        $consqConnect=$consequences->getAttribute('connective');

        $closingLabel = $closing->getAttribute('label');
        $closingHelp = $closing->getAttribute('help');
        $closingConnectTitle=$closing->getAttribute('connectiveTitle');
        $closingConnect=$closing->getAttribute('connective');

        $noteConLabel=$noteCon->getAttribute('label');

        // SVG variables for CONCLUSION -----------
        $labelConclu=$con->nodeName;
   //     $labelConcluId = $con->getAttribute('label');
        $labelConcluId = $con->getAttribute('svgLabel');
        $labelThSum=$thesis_summary->getAttribute('label');
        $labelThSumHelp=$thesis_summary->getAttribute('help');
   //     $labelThSumId = $thesis_summary->getAttribute('label');
        $labelThSumId = $thesis_summary->getAttribute('svgLabel');
        $labelArgSum = $argument_summary->getAttribute('label');
        $labelArgSumHelp = $argument_summary->getAttribute('help');
  //      $labelArgSumId = $argument_summary->getAttribute('label');
        $labelArgSumId = $argument_summary->getAttribute('svgLabel');
        $labelConsq = $consequences->getAttribute('label');
  //      $labelConsqId = $consequences->getAttribute('label');
        $labelConsqId = $consequences->getAttribute('svgLabel');
        $labelClosing = $closing->getAttribute('label');
        $labelClosingHelp = $closing->getAttribute('help');
  //      $labelClosingId = $closing->getAttribute('label');
        $labelClosingId = $closing->getAttribute('svgLabel');

        $colorPro = "#467A4B";
     //   $colorCon = "#499BC4";
        $colorLine = "#98A48A";

        echo '<a name="conclusion"></a>	<fieldset>
                <legend>'.$concluLabel.'</legend>
                <form name="save_conclusion" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <table width="100%" border="0" cellspacing="0" cellpadding="3"  id="concluTable">
                <tr><td>&#160;</td><td>&#160;</td><td>&#160;</td>';
     // conclusion text view button
     /*
                echo '<td align="right" width="25%">';
                printf ('<a id="conclusion-preview" class="genTip conclu-preview" href="javascript: toggleIcon(\'concluText\')">
                        <img id="imgconcluText" src="../graphics/tview.png" alt="view" border="0" title="view text for this element" class="buttonText"/> conclusion text</a>');

                echo '</td>';
      */
                echo '</tr><tr>
                <td align="center" width="5%" valign="top">';
   // buttons down side
        printf ('<a id="conclusion-edit" class="genTip" href="javascript: toggleForm(\'conForm\')"><img id="editconForm" src="../graphics/edit.png" alt="edit '.$concluLabel.'" border="0" title="edit conclusion" class="buttonText" /></a>
                <input id="cancelconForm" type="image" value="submit" class="buttonText" name="cancelCon" src="../graphics/cancel.png" title="cancel changes to '.$concluLabel.'"  style="display:none;" />');


        echo '</td>
                <td valign="top" width="20%">';
                echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='68' width='180' x='0' y='0'>";

                // SVG for CONCLUSION -----------
        echo "<defs>

            <rect id='nodeEmpty' width='16' height='16' stroke-width='2' />
            <rect id='nodeEmptySm' width='10' height='10' stroke-width='2' />
            <circle id='optionEmpty' r='5'  stroke-width='2' />
            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,34,0' />
            <polyline id='lineSm' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,16,0' />
            <polyline id='lineConclu' fill='none' stroke='$colorLine' stroke-width='2' points='34,8,34,38,52,38' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />

            <symbol id='conclu'>
                <use x='18' y='8' xlink:href='#line'  />
                <use x='68' y='0' xlink:href='#lineProAa'  />
                <use x='83' y='0' xlink:href='#lineProAb'  />
                <use x='0' y='0' xlink:href='#lineConclu'  />
            </symbol>
          </defs>";

// detecting if textnodes are whitespace only
        $textThSum = $thesis_summary->nodeValue;
        $textThSumNode = $dom->createTextNode("$textThSum");
        $wsThSum = $textThSumNode->isWhitespaceInElementContent();

        $textArgSum = $argument_summary->nodeValue;
        $textArgSumNode = $dom->createTextNode("$textArgSum");
        $wsArgSum = $textArgSumNode->isWhitespaceInElementContent();

        $textConsq = $consequences->nodeValue;
        $textConsqNode = $dom->createTextNode("$textConsq");
        $wsConsq = $textConsqNode->isWhitespaceInElementContent();

        $textClosing = $closing->nodeValue;
        $textClosingNode = $dom->createTextNode("$textClosing");
        $wsClosing = $textClosingNode->isWhitespaceInElementContent();

 // adjusting fills
        if($wsThSum){$colorThSum='#FFFFFF';}else{$colorThSum='#467A4B';};
        if ($wsArgSum){$colorArgSum='#FFFFFF';}else{$colorArgSum='#467A4B';};
        if ($wsConsq){$colorConsq='#FFFFFF';}else{$colorConsq='#467A4B';};
        if ($wsClosing){$colorClosing='#FFFFFF';}else{$colorClosing='#467A4B';};
        // filling node if all necessary components are filled
        if (($wsThSum)||($wsClosing)){$colorConclu='#FFFFFF';}else{$colorConclu='#467A4B';}


        // scoring and scaling
        $concluScale=1;
        $wsConclu=$concluScale;
        if (!$wsConclu){$concluScale=$concluScale+0.4;};
        if (!$wsConsq){$concluScale=$concluScale+0.4;};
        if (($wsThSum)||($wsClosing)){$concluScale=1;};

        printf ('<use x="0" y="0" xlink:href="#conclu"  />
        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(1,1) scale('.$concluScale.')" fill="'.$colorConclu.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConcluId.'\')" onmouseout="toggleOut(\''.$labelConcluId.'\')" title="'.$summaryLabel.'"><title>'.$summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(52,1)" fill="'.$colorThSum.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelThSumId.'\')" onmouseout="toggleOut(\''.$labelThSumId.'\')" title="'.$thesis_summaryLabel.'"><title>'.$thesis_summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#optionEmpty" transform="translate(105,6)" fill="'.$colorArgSum.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelArgSumId.'\')" onmouseout="toggleOut(\''.$labelArgSumId.'\')" title="'.$argument_summaryLabel.'"><title>'.$argument_summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#optionEmpty" transform="translate(105,21)" fill="'.$colorConsq.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConsqId.'\')" onmouseout="toggleOut(\''.$labelConsqId.'\')" title="'.$consqLabel.'"><title>'.$consqLabel.'</title></use>

        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(52,32)" fill="'.$colorClosing.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelClosingId.'\')" onmouseout="toggleOut(\''.$labelClosingId.'\')" title="'.$closingLabel.'"><title>'.$closingLabel.'</title></use>');
        echo "</svg>";

//	pop-up SVG labels
/*
echo "<img src='../graphics/transpixel.png' height='18px' style='float:right' />
            <span id='$labelConcluId' class='svgPop'>$labelConclu</span>
                  <span id='$labelThSumId' class='svgPop'>$labelThSum</span>
                  <span id='$labelArgSumId' class='svgPop'>$labelArgSum</span>
                  <span id='$labelConsqId' class='svgPop'>$labelConsq</span>
                  <span id='$labelClosingId' class='svgPop'>$labelClosing</span>";
*/
  // ----- end SVG for CONCLUSION -----------

/* notepad form*/

        echo'</td><td width="75%" valign="top">';

// ------------ conclusion form-------------------
        echo '<a name="conclusion"></a><span id="conForm" class="boxForm" style="display:none">
        <form name="edit_conclusion" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                <table width="100%" border="0" cellspacing="0" cellpadding="3" >
                <tr>
                <td valign="top" width="90%">';

        // thesis summary
        echo '<fieldset class="On">
        <legend>&#160;<a id="conclusion-note-edit" class="genTip" href="javascript: toggleNote(\'conNotepad\')"><img src="../graphics/note.png" id="noteconNotepad" alt="edit note" border="0" title="edit note" class="buttonText" /></a>&#160;&#160;'.$summaryLabel.': <input type="text" name="summary_label" placeholder="edit '.$summaryLabel.' label" size="30" value="" /></legend>';

       echo '<div id="conNotepad" class="boxNote" style="display:none">
                        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                                <fieldset class="notepad">
                                <legend>'.$noteConLabel.'</legend>
                                <textarea name="noteCon" cols="20" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)">', $noteCon->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

        printf(' <p>edit <strong>'.$concluLabel.'</strong> section label above: <input type="text" name="conclu_label" placeholder="edit '.$concluLabel.' section label" value="" /></p>
            <label for="thesis_summary" class="boxInst"><a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$thesis_summaryLabel.'</a>: <input  size="30"  type="text" name="thesisSummary_label" placeholder="edit '.$thesis_summaryLabel.' label" value="" /></label>');
        echo '&#160;<a id="conclusion-thesis-info" href="javascript:toggleInfo(\'thesis_summaryList\')"><img id="imgthesis_summaryList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words"  border="0" align="absbottom" /></a><br/>';
        echo'<span id="thesis_summary" class="boxPop" style="display:block">'.$thesis_summaryHelp.'';
        printf('&#160;<a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>');
        // thesis summary words
        echo'<div id="thesis_summaryList" class="boxFloat" style="display:none"><h4>'.$thesis_summaryLabel.' </h4><p class="instruct">'.$thesis_summaryConnectTitle.': <input type="text" name="thesisSummaryConnect_label"  size="30" placeholder="edit '.$thesis_summaryLabel.' word help text" value="" /></p>
        <p class="maintext">'.$thesis_summaryConnect.'</p><textarea id="thesisSummaryConnectList" class="textOff" name="thesisSummary_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'thesisSummaryConnectList\')" onblur="changeTextClass(\'thesisSummaryConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$thesis_summaryLabel.' word list" value="" />';
        printf('&#160;<a class="conclusion-thesis-info" href="javascript: toggleInfo(\'thesis_summaryList\')"><img id="imgthesis_summaryListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right"/></a></div>');
        // thesis summary text field
        echo '<textarea id="thesisSummaryText" class="textOff" name="thesis_summaryHelp" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'thesisSummaryText\')" onblur="changeTextClass(\'thesisSummaryText\')"  onkeyup="textAreaAdjust(this)" placeholder="edit '.$thesis_summaryLabel.' help" value="" />';

        // argument summaries
        echo '<fieldset class="On">
                <legend>'.$argSumLabel.': <input  size="30"  type="text" name="argSum_label" placeholder="edit '.$argSumLabel.' label" value="" /></legend> ';
                printf('<label for="arguments_summaries" class="boxInst"><a class="tip conclusion-args-help optional" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/>&#160;'.$argument_summaryLabel.'</a>: <input type="text" name="argumentSummary_label" placeholder="edit '.$argument_summaryLabel.' label" size="30" value="" /></label>');
        echo '&#160;<a id="conclusion-args-info" href="javascript:toggleInfo(\'argument_summaryList\')"><img id="imgargument_summaryList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="arguments_summaries" class="boxPop" style="display:block">'.$argument_summaryHelp.'';
        printf('&#160;<a class="tip conclusion-args-help" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
        // argument summary words
        echo'<div id="argument_summaryList" class="boxFloat" style="display:none"><h4>'.$argument_summaryLabel.' </h4><p class="instruct">'.$argument_summaryConnectTitle.': <input type="text" name="argumentSummaryConnect_label"  size="30" placeholder="edit '.$argument_summaryLabel.' word help text" value="" /></p><p class="maintext">'.$argument_summaryConnect.'</p><textarea id="argumentSummaryConnectList" class="textOff" name="argumentSummary_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'argumentSummaryConnectList\')" onblur="changeTextClass(\'argumentSummaryConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$argument_summaryLabel.' word list" value="" />';
        printf('&#160;<a class="conclusion-args-info" href="javascript: toggleInfo(\'argument_summaryList\')"><img id="imgargument_summaryListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right"/></a></div>');
        // argument summary text field
        echo '<textarea id="argumentSummaryText" class="textOff" name="argument_summaryHelp" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'argumentSummaryText\')" onblur="changeTextClass(\'argumentSummaryText\')"  onkeyup="textAreaAdjust(this)" placeholder="edit '.$argument_summaryLabel.' help" value="" />
                <br />';

        // consequences
         printf('<label for="consequences" class="boxInst"><a class="tip conclusion-conseq-help optional" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element" /> '.$consqLabel.'</a>: <input  size="30"  type="text" name="consequences_label" placeholder="edit '.$consqLabel.' label" value="" /></label>');
        echo '&#160;<a id="conclusion-conseq-info" href="javascript:toggleInfo(\'consequencesList\')"><img id="imgconsequencesList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="consequences" class="boxPop" style="display:block">'.$consqHelp.'';
        printf('&#160;<a class="tip conclusion-conseq-help" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></span>');
        // consequences words
        echo'<div id="consequencesList" class="boxFloat" style="display:none"><h4>'.$consqLabel.' </h4><p class="instruct">'.$consqConnectTitle.': <input type="text" name="consqConnect_label"  size="30" placeholder="edit '.$consqLabel.' word help text" value="" /></p><p class="maintext">'.$consqConnect.'</p>
        <textarea id="consqConnectList" class="textOff" name="consequences_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'consqConnectList\')" onblur="changeTextClass(\'consqConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$consqLabel.' word list" value="" />';
        printf('&#160;<a class="conclusion-conseq-info" href="javascript: toggleInfo(\'consequencesList\')"><img id="consequencesListClose" src="../graphics/close.png" class="buttonText" title="close"  style="float:right" /></a></div>');
        // consequences text field
        echo '<textarea id="consequencesText" class="textOff" name="consequences_help" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'consequencesText\')" onblur="changeTextClass(\'consequencesText\')"  onkeyup="textAreaAdjust(this)" placeholder="edit '.$consqLabel.' help" value="" />
                </fieldset>';

        // closing
        printf('<label for="closing" class="boxInst"><a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp"  title="help for this element"/> '.$closingLabel.'</a>: <input  size="30"  type="text" name="closing_label" placeholder="edit '.$closingLabel.' label" value="" /></label>');
        echo '&#160;<a id="conclusion-closing-info" href="javascript:toggleInfo(\'closingList\')"><img id="imgclosingList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="closing" class="boxPop" style="display:block">'.$closingHelp.'';
        printf('&#160;<a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
        // closing words
        echo'<div id="closingList" class="boxFloat" style="display:none"><h4>'.$closingLabel.' </h4><p class="instruct">'.$closingConnectTitle.'
        : <input type="text" name="closingConnect_label"  size="30" placeholder="edit '.$closingLabel.' word help text" value="" /></p><p class="maintext">'.$closingConnect.'</p>
        <textarea id="closingConnectList" class="textOff" name="closing_connectList" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'closingConnectList\')" onblur="changeTextClass(\'closingConnectList\')" onkeyup="textAreaAdjust(this)" placeholder="edit '.$closingLabel.' word list" value="" />';
        printf('&#160;<a id="closingListClose" class="tip conclusion-closing-info" href="javascript: toggleInfo(\'closingList\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"/></a></div>');
        // closing text field
        echo '<textarea id="closingText" class="textOff" name="closing_help" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'closingText\')" onblur="changeTextClass(\'closingText\')"  onkeyup="textAreaAdjust(this)" placeholder="edit '.$closingLabel.' help" value="" />
                </fieldset></td></tr>';

// conForm buttons
        echo'<tr><td align="center">
                <input type="image" value="submit" name="saveCon" class="buttonText" src="../graphics/save.png" title="save changes to conclusion" align="middle" />&#160;&#160;&#160;
                <input id="conclusion-cancel" type="image" value="submit" class="buttonText" name="cancelCon" src="../graphics/cancel.png" title="cancel changes to conclusion" align="middle" />
                </td></tr></table>
                </form></span></td>';
        echo '</tr></table></form></fieldset>';
        }
}

// saves changes to CONCLUSION and goes to display view (conView)
function saveCon($dom) {
   if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
   // $file=$_POST['currentFile'];

        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $conclusion = $dom->getElementsByTagName('conclusion')->item(0);

         //REPLACE conclu label----------------------
        $concluLabel = $conclusion->getAttribute('label');
        if (isset($_POST['conclu_label'])&&($_POST['conclu_label']!='')){
                $insertConcluLabel=$_POST['conclu_label'];
                $conclusion->setAttribute('label',''. $insertConcluLabel .'');
                 $concluLabel = $conclusion->getAttribute('label');
            }else{ //do nothing
        };

         //REPLACE summary label----------------------
        $summaryLabel = $conclusion->getAttribute('summaryLabel');
        if (isset($_POST['summary_label'])&&($_POST['summary_label']!='')){
                $insertSummaryLabel=$_POST['summary_label'];
                $conclusion->setAttribute('summaryLabel',''. $insertSummaryLabel .'');
                 $summaryLabel = $conclusion->getAttribute('summaryLabel');
            }else{ //do nothing
        };
        //REPLACE thesis_summary label----------------------
        $thesis_summaryLabel=$dom->getElementsByTagName('thesis_summary')->item(0);
        if (isset($_POST['thesisSummary_label'])&&($_POST['thesisSummary_label']!='')){
                $insertThesisSummaryLabel=$_POST['thesisSummary_label'];
                $thesis_summaryLabel->setAttribute('label',''. $insertThesisSummaryLabel .'');
            }else{ //do nothing
        };
       //REPLACE thesis_summary help----------------------
         $thesis_summaryHelp=$dom->getElementsByTagName('thesis_summary')->item(0);
        if (isset($_POST['thesis_summaryHelp'])&&($_POST['thesis_summaryHelp']!='')){
                $insertThesisSummaryHelp=$_POST['thesis_summaryHelp'];
                $content = nl2br($insertThesisSummaryHelp);
                $insertThesisSummaryHelp = trim($content);
                $thesis_summaryHelp->setAttribute('help',''. $insertThesisSummaryHelp .'');
            }else{ //do nothing
        };

         //REPLACE thesis_summary connective list text --------------------
        $thesis_summaryConnectTitle = $dom->getElementsByTagName('thesis_summary')->item(0);
        if (isset($_POST['thesisSummaryConnect_label'])&&($_POST['thesisSummaryConnect_label']!='')) {
                $insertThesisSummaryConnectTitle=$_POST['thesisSummaryConnect_label'];
                $thesis_summaryConnectTitle->setAttribute('connectiveTitle',''. $insertThesisSummaryConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE thesis_summary connective word list --------------------
        $thesis_summaryConnect = $dom->getElementsByTagName('thesis_summary')->item(0);
        if (isset($_POST['thesisSummary_connectList'])&&($_POST['thesisSummary_connectList']!='')) {
                $insertThesisSummaryConnectList=$_POST['thesisSummary_connectList'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertThesisSummaryConnectList);
                $insertThesisSummaryConnectList = trim($content);
                $thesis_summaryConnect->setAttribute('connective',''. $insertThesisSummaryConnectList .'');
                }else {	// do nothing
                };

        //REPLACE argSum (general summaries) label ----------------------
       $argSumLabel = $conclusion->getAttribute('argSumLabel');
        if (isset($_POST['argSum_label'])&&($_POST['argSum_label']!='')){
                $insertArgSumLabel=$_POST['argSum_label'];
                $conclusion->setAttribute('argSumLabel',''. $insertArgSumLabel .'');
                $argSumLabel = $conclusion->getAttribute('argSumLabel');
        }else{ //do nothing
        };
        //REPLACE argument_summary help----------------------
         $argument_summaryHelp=$dom->getElementsByTagName('argument_summary')->item(0);
        if (isset($_POST['argument_summaryHelp'])&&($_POST['argument_summaryHelp']!='')){
                $insertArgumentSummaryHelp=$_POST['argument_summaryHelp'];
                $content = nl2br($insertArgumentSummaryHelp);
                $insertArgumentSummaryHelp = trim($content);
                $argument_summaryHelp->setAttribute('help',''. $insertArgumentSummaryHelp .'');
            }else{ //do nothing
        };

        //REPLACE argument_summary label ----------------------
        $argument_summaryLabel=$dom->getElementsByTagName('argument_summary')->item(0);
        if (isset($_POST['argumentSummary_label'])&&($_POST['argumentSummary_label']!='')){
                $insertArgument_summaryLabel=$_POST['argumentSummary_label'];
                $argument_summaryLabel->setAttribute('label',''. $insertArgument_summaryLabel .'');
        }else{ //do nothing
        };

        //REPLACE argument_summary connective list text --------------------
        $argument_summaryConnectTitle = $dom->getElementsByTagName('argument_summary')->item(0);
        if (isset($_POST['argumentSummaryConnect_label'])&&($_POST['argumentSummaryConnect_label']!='')) {
                $insertArgumentSummaryConnectTitle=$_POST['argumentSummaryConnect_label'];
                $argument_summaryConnectTitle->setAttribute('connectiveTitle',''. $insertArgumentSummaryConnectTitle .'');
                }else {	// do nothing
                };

        //REPLACE argument_summary connective word list --------------------
        $argument_summaryConnect = $dom->getElementsByTagName('argument_summary')->item(0);
        if (isset($_POST['argumentSummary_connectList'])&&($_POST['argumentSummary_connectList']!='')) {
                $insertArgumentSummaryConnectList=$_POST['argumentSummary_connectList'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertArgumentSummaryConnectList);
                $insertArgumentSummaryConnectList = trim($content);
                $argument_summaryConnect->setAttribute('connective',''. $insertArgumentSummaryConnectList .'');
                }else {	// do nothing
                };

        //REPLACE consequences label ----------------------
        $consqLabel=$dom->getElementsByTagName('consequences')->item(0);
        if (isset($_POST['consequences_label'])&&($_POST['consequences_label']!='')){
                $insertConsqLabel=$_POST['consequences_label'];
                $consqLabel->setAttribute('label',''. $insertConsqLabel .'');
        //	$consequences->setAttribute('label',''. $insertConsequencesLabel .'');
        }else{ //do nothing
        };
         //REPLACE consequences_ help----------------------
         $consqHelp=$dom->getElementsByTagName('consequences')->item(0);
        if (isset($_POST['consequences_help'])&&($_POST['consequences_help']!='')){
                $insertConsqHelp=$_POST['consequences_help'];
                $content = nl2br($insertConsqHelp);
                $insertConsqHelp = trim($content);
                $consqHelp->setAttribute('help',''. $insertConsqHelp .'');
            }else{ //do nothing
        };

        //REPLACE consq connective list text --------------------
        $consqConnectTitle = $dom->getElementsByTagName('consequences')->item(0);
        if (isset($_POST['consqConnect_label'])&&($_POST['consqConnect_label']!='')) {
                $insertArgumentSummaryConnectTitle=$_POST['consqConnect_label'];
                $consqConnectTitle->setAttribute('connectiveTitle',''. $insertArgumentSummaryConnectTitle .'');
                }else {	// do nothing
                };
        //REPLACE consq connective word list --------------------
        $consqConnect = $dom->getElementsByTagName('consequences')->item(0);
        if (isset($_POST['consequences_connectList'])&&($_POST['consequences_connectList']!='')) {
                $insertConsqConnectList=$_POST['consequences_connectList'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertConsqConnectList);
                $insertConsqConnectList = trim($content);
                $consqConnect->setAttribute('connective',''. $insertConsqConnectList .'');
                }else {	// do nothing
                };

        //REPLACE closing label ----------------------
        $closingLabel=$dom->getElementsByTagName('closing')->item(0);
        if (isset($_POST['closing_label'])&&($_POST['closing_label']!='')){
                $insertClosingLabel=$_POST['closing_label'];
                $closingLabel->setAttribute('label',''. $insertClosingLabel .'');
        }else{ //do nothing
        };

       //REPLACE closing help ----------------------
        $closingHelp=$dom->getElementsByTagName('closing')->item(0);
        if (isset($_POST['closing_help'])&&($_POST['closing_help']!='')){
                $insertClosingHelp=$_POST['closing_help'];
                $content = nl2br($insertClosingHelp);
                $insertClosingHelp = trim($content);
                $closingHelp->setAttribute('help',''. $insertClosingHelp .'');
        }else{ //do nothing
        };
        //REPLACE closing connective list text --------------------
        $closingConnectTitle = $dom->getElementsByTagName('closing')->item(0);
        if (isset($_POST['closingConnect_label'])&&($_POST['closingConnect_label']!='')) {
                $insertClosingConnectTitle=$_POST['closingConnect_label'];
                $closingConnectTitle->setAttribute('connectiveTitle',''. $insertClosingConnectTitle .'');
                }else {	// do nothing
                };
         //REPLACE closing connective word list --------------------
        $closingConnect = $dom->getElementsByTagName('closing')->item(0);
        if (isset($_POST['closing_connectList'])&&($_POST['closing_connectList']!='')) {
                $insertClosingConnectList=$_POST['closing_connectList'];
                // to keep line breaks nl2br, trim
                $content = nl2br($insertClosingConnectList);
                $insertClosingConnectList = trim($content);
                $closingConnect->setAttribute('connective',''. $insertClosingConnectList .'');
                }else {	// do nothing
                };

        //REPLACE notepad for conclusion-----------------------------
        $noteCon = $conclusion->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteCon'])){
                $insertNoteCon=$_POST['noteCon'];
                $content = nl2br($insertNoteCon);
                $insertNoteCon = trim($content);
                $noteCon->nodeValue = $insertNoteCon;
                $insertNoteId = "noteCon";
                $noteCon->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        conView($dom,$_POST);
        }

// ----------- end CONCLUSION ---------------------

// BEGIN LOADING functions ----------------------------------------------------

// loading the source xml file
// input from start.php -> getFile value=newFile or selectedFile OR newFileName value=$file from chooseFile form

if(isset($_POST['essayFile'])){ $existingFile = $_POST['essayFile']; }
//$existingFile = $_POST['essayFile'];
if(isset($_POST['newFileName'])){ $newFile = $_POST['newFileName']; }
//$newFile = $_POST['newFileName'];
if(isset($_POST['loadFile'])){ $loadFile = $_POST['loadFile']; }
//$loadFile = $_POST['loadFile'];
if(isset($_POST['saveAsFilename'])){ $saveAsFile = $_POST['saveAsFilename']; }
//$saveAsFile = $_POST['saveAsFilename'];
if(isset($_POST['currentFile'])){ $currentFile = $_POST['currentFile']; }
//$currentFile = $_POST['currentFile'];


if(($_POST['getFile']== "selectedFile")) //button name
        {
   //load existing file from start page
   $file = basename($existingFile);
       }
        elseif(($_POST['getFile']== "newFile" ))
        {
       // start new essay loading base essay file and saving with new name
        $dom = new domDocument;
        $dom->load('essayBase.xml');

        $file = basename($newFile);
        $dom->save($file);
        $dom->load($file);
        }
        elseif (isset ($_POST['loadFile'])) {
        //load existing file from essay page
        $file = basename($loadFile);
        }
        elseif (isset ($_POST['saveAsFilename'])) {
        //save file under a new name and load it
         $dom = new domDocument;
            $dom->load($currentFile);
            $file = basename($saveAsFile);
            $dom->save($file);
            $dom->load($file);
        }
        else{
          // for inline save of changes
          $file=$_POST['currentFile'];
    //    exit('Failed to load XML. <a href="start.php">GO BACK</a>');
        };

        $dom = new domDocument;

if (file_exists($file)) {
        $dom->load($file);
        }else {
                exit('Cannot load your document!. Please <a href="start.php">GO BACK</a> and select an existing file with an xml extension or start a new essay.');
        };


$dom = ($dom);
$root = $dom->getElementsByTagName('root');
$arguments =  $dom->getElementsByTagName('arguments');
$noId=0;

//html header
head();
recordTime();
newFileSelect();



// change filename

// CONTENT

// show appropriate display - edit form (*Form), graphic(*Display) or text view (*View)
// -- NAME --
if(isset($_POST['editName_x'])) //button name
{
        nameForm($dom, $_POST);
        }elseif(isset($_POST['cancelName_x'])){
        nameView($dom, $_POST);
        }else {
        saveName($dom,$_POST); //contains nameView
};
// -- end NAME --

//-- TITLE --
if(isset($_POST['editTitle_x']))
{
        titleForm($dom, $_POST);
        }elseif(isset($_POST['cancelTitle_x'])){
        titleDisplay($dom, $_POST);
        }else {
        saveTitle($dom,$_POST); //contains titleDisplay
};
// -- end TITLE --

// -- INTRODUCTION --
if(isset($_POST['editIntro_x']))
{
        introForm($dom, $_POST); // contains editing form
        }elseif(isset($_POST['viewIntro_x'])){
        introView($dom, $_POST);  // graphic
        }elseif(isset($_POST['cancelIntro_x'])){
        introView($dom, $_POST);  //contains text with help
        }
        else {
        saveIntro($dom, $_POST);  // contains display
        };
// -- end INTRODUCTION --

// -- argHeads --
if(isset($_POST['saveArgHeads_x']))
{
    saveArgHeads($dom, $_POST);
        }else {// do nothing
}
// -- end argHeads --

// -- argHelp --
if(isset($_POST['saveArgHelp_x']))
{
    saveArgHelp($dom, $_POST);
        }else {// do nothing
}
// -- end argHelp --

// -- ARGUMENTS --
if(isset($_POST['editArg_x'])) {
  argForm($dom);
 }
 elseif (isset ($_POST['saveArg_x'])) {

        saveArg($dom,$file); //contains argView
        }
 elseif(isset($_POST['viewGraph_x'])){
        argView($dom, $_POST); // graphic
        }
 elseif(isset($_POST['viewArg_x'])){
        argDisplay($dom, $_POST); // graphic
        }
 elseif(isset($_POST['cancelArg_x'])){
        argView($dom, $_POST); //contains text with help
        }
 elseif (isset ($_POST['moveArgDown_x'])) {
   moveArgDown($dom,$file); //contains argDisplay
 }
 elseif (isset ($_POST['addArg_x'])) {
   addArg($dom,$file); //contains argDisplay
 }
 elseif (isset ($_POST['deleteArg_x'])) {
   deleteArg($dom,$file); //contains argDisplay and deleteIfArg
 }
 else {
   argView($dom);
 }
// -- end ARGUMENTS --

// CONCLUSION
if(isset($_POST['editCon_x']))
{
        conForm($dom, $_POST); // contains editing form
        }elseif(isset($_POST['viewCon_x'])){
        conView($dom, $_POST);  //graphic
        }elseif(isset($_POST['cancelCon_x'])){
        conView($dom, $_POST); // contains text with help
        }
        else {
        saveCon($dom,$_POST); //contains conView
};

footer();

?>
