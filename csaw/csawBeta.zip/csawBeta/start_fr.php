<?php

/* by kalli benetos
Argumentative essay online tool
August 2012
*/

//phpinfo ();
//session_start();
error_reporting(E_ALL);

// FROM  http://php.net/manual/en/security.magicquotes.disabling.php
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}


function login() {
        //put sha1() encrypted password here - example is 'hello'
$password = '5324fe91536f2bea3b26c930f64eedffa223a9db';

session_start();
if (!isset($_SESSION['loggedIn'])) {
    $_SESSION['loggedIn'] = false;
}

if (isset($_POST['password'])) {
    if (sha1($_POST['password']) == $password) {
        $_SESSION['loggedIn'] = true;
    } else {
        die ('Mot de passe incorrect. Retourner à la page précedente.');
    }
}

if (!$_SESSION['loggedIn']):

echo'<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg" xml:lang="en" lang="en">
<head><title>C-SAW Connexion</title>
<script language="javascript" src="essay.js" type="text/javascript" ></script>
<link href="form.css" rel="stylesheet" type="text/css" /></head>
  <body>
  <div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
  <div style="margin-left:20%;margin-right:20%;padding: 3em;border: 1pt dashed #9BACB0;">
    <h4>Connectez-vous avec votre compte C-SAW</h4>
    <form method="post">
    Account type: <input type="radio" id="acctTeacher" name="acctType" value="teacher" />
	&#13;Je suis un(e) enseignant(e) &#13; <input type="radio" id="acctStudent" name="acctType" value="student" />&#160;Je suis un(e) étudiant(e) <br /><br />
		User name: <input type="text" name="user" id="userText" class="textOff" onfocus="changeTextClass(\'userText\')" onblur="changeTextClass(\'userText\')" /> <br />
      Mot de passe : <input type="password" name="password" id="passText" class="textOff" onfocus="changeTextClass(\'passText\')" onblur="changeTextClass(\'passText\')" /> <br />
      <input type="submit" name="submit" value="connexion" class="buttonText"/>
    </form>
    </div>
	<div style="margin-left:20%;margin-right:20%;padding: 3em;border: 1pt dashed #9BACB0;">
    <h4>Create a new account</h4>
    <form method="post">
	Type de compte: <input type="radio" id="nAccountTeacher" name="nAccount" value="nTeacher" />
	Je suis un(e) enseignant(e) &#13; <input type="radio" id="nAccountStudent" name="nAccount" value="nStudent" />&#160;Je suis un(e) étudiant(e) <br />
      Créer un mot de passe: <input type="text" name="nPassword" id="newpassText" class="textOff" onfocus="changeTextClass(\'newpassText\')" onblur="changeTextClass(\'newpassText\')" /> <br />
	  Répéter le mot de passe: <input type="text" name="nPassword" id="newpassText2" class="textOff" onfocus="changeTextClass(\'newpassText2\')" onblur="changeTextClass(\'newpassText2\')" /> <br />
      <input type="submit" name="submit" value="créer un mot de passe" class="buttonText"/>
    </form>
    </div>

  </body>
</html>';

   exit();
endif;

}

//require('login.php');

header ("Content-type: application/xhtml+xml");
//HTML global display page functions

function head() {

  // include log/start_tfr.php, start the log session from this point
  include("log/start.php");

echo '<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg" xml:lang="en" lang="en">

<head><meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>C-SAW</title>
<script language="javascript" src="essay.js" type="text/javascript"></script>
<link href="form.css" rel="stylesheet" type="text/css" />
</head><body>
<div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer<br/><br/></h2>
<div style="position: absolute; right: 8%;top: 40px"><a href="javascript:viewClick(\'userguide_fr.htm\')" ><img src="../graphics/userguide.png" alt="Manuel&#160;d&#39;utilisateur" title="Manuel&#160;d&#39;utilisateur" border="0" class="buttonText" /></a>
</div><div style="height: 120px;"></div> ';
}


function fileSelect(){

// account type seleciton
$acctType= $_POST['acctType'];
if(($_POST['acctType']== "teacher")) {
    $acctType="teach_fr.php";
}
else {$acctType="csaw_fr.php";
}
// begin STUDENT file selection form
echo'<div style="margin-left:20%;margin-right:20%;border: 1pt dashed #9BACB0;padding:2em;">
        <form id="fileChoice" name="chooseFile" action="'.$acctType.'" method="post">';

// get account type - student = csaw.php, teacher = teach.php
if ($acctType=='csaw_fr.php') {
// student file select
echo '<p><input type="radio" id="eFile" name="getFile" value="selectedFile" />
 <select name="essayFile">';
 $dir = "./"; // root
 $files = scandir($dir);
 foreach ($files as $file) {
         if (substr_compare($file, ".xml", -4) == 0) {
                 echo "<option value=\"$dir/$file\">$file</option>";
         }
 }
 echo'</select><br/><div class="instruct" style="margin-left:2em;">Modifiez un de vos fichiers </div></p>';

 // select from student work files
 echo'<p><input type="radio" id="nFile" name="getFile" value="selectedTemplate" />
        <select name="essayTemplate">';
 $dir = "./"; // root
 $files = scandir($dir);
 foreach ($files as $file) {
         if (substr_compare($file, ".xml", -4) == 0) {
                 echo "<option value=\"$dir/$file\">$file</option>";
         }
 }
 echo'</select><br/>';
 // select from teacher templates
 echo '<div class="instruct" style="padding-left:2em;">Sélectionnez un modèle proposé pour commencer une nouvelle dissertation</div></p>
        <p>&#13;<br/></p>
        <p style="text-align:center;">
        <input type="submit" value="soumettre" class="buttonText" onclick="btnSearchClick();" /></p>
        </form></div> ';
}
// TEACHER template file selection
        else {
            // select from existing personal teacher templates
            echo'<h2>Template Maker</h2>
            <p><input type="radio" id="nFile" name="getFile" value="selectedFile" />
            <select name="essayFile">';

 $dir = "./"; // root
 $files = scandir($dir);
 foreach ($files as $file) {
         if (substr_compare($file, ".xml", -4) == 0) {
                 echo "<option value=\"$dir/$file\">$file</option>";
         }
 }
 echo'</select><br/><div class="instruct" style="padding-left:2em;">Sélectionnez un modèle à modifier </div></p>';
 // create new template using essayBase.xml
  echo'<p><input type="radio" id="nFile" name="getFile" value="newFile" />
    <input type="text" cols="50"  id="eFile2" name="newFileName" /><br/>';
    echo '<div class="instruct" style="padding-left:2em;">Créer un nouveau modèle (donnez un nom de fichier avec l&#39;extention <strong>.xml</strong> à la fin, sans accents ni espaces, par exemple: modele_JeanDupont.xml).</div></p>
        <p>&#13;<br/></p>
        <p style="text-align:center;">
        <input type="submit" value="soumettre" class="buttonText" onclick="btnSearchClick();" /></p>
        </form></div>';
    }
}

function footer(){
	echo '<div style="height: 150px;"></div>
	<p align="center">
<a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">C-SAW</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="mailto:kalliopi.benetos@unige.ch" property="cc:attributionName" rel="cc:attributionURL">Kalliopi Benetos</a> is licensed under a <br/><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US">Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License</a>.
	</p></body></html>';}

login();
head();
fileSelect();

footer();
