<?php
    session_start();
    $_SESSION['loggedIn'] = false;
?>


    <html>

    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>C-SAW boot log out</title>
        <link href="bootstrap4/css/bootstrap.min.css" rel="stylesheet" type="text/css">
        <link href="form.css" rel="stylesheet" type="text/css">
    </head>

    <body>

        <div class="container-fluid banner" style="padding-top:20px; padding-bottom:0px;">
            <div class="row" style="padding:0em 2em 2em 2em;">
                <div class="col-md-3"> <img src="../graphics/csaw_logo500-150.png" class="img-fluid" alt="Responsive image"> </div>
                <div class="col-md-6"> <img src="../graphics/pixel.png" style="max-height:100%;min-height:6em;">
                    <div style="position:absolute; bottom:0;">
                        <h1>Computer-Supported Argumentative&nbsp;Writer</h1>
                    </div>
                </div>
                <div class="col-md-3"> </div>
            </div>
            <div class="row">
                <div class="col-md-3"> </div>
                <div class="col-md-6">
                    <div class="boxLog" style="padding: 2em 3em 3em 3em; text-align:center">

                        <h2>You have logged out. You may <a href="login.html" class="buttonText">log in</a> again.</h2>
                    </div>



                </div>
                <div class="col-md-3"> </div>
            </div>
            <div class="col-md-12" style="padding-top:2em; padding-bottom:2em;">
                <p style="font-size:0.8em; text-align:center;">
                    <a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/"><img alt="Creative Commons License" style="border-width:0" src="https://i.creativecommons.org/l/by-nc-sa/4.0/80x15.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">C-SAW:Computer-Supported Argumentative Writer</span> <br>by <span xmlns:cc="http://creativecommons.org/ns#" property="cc:attributionName">Kalliopi Benetos</span> is licensed under a <br><a rel="license" href="http://creativecommons.org/licenses/by-nc-sa/4.0/">Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.</p>
            </div>
        </div>
        <script src="jquery/jquery.js"></script>

        <!-- Tether -->
        <script src="https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js" integrity="sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB" crossorigin="anonymous"></script>
        <script src="bootstrap4/js/bootstrap.min.js"></script>
        <script src="essay.js"></script>


    </body>

    </html>