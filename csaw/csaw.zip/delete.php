<?php

function getRole($name){
	$res= getUser($name)->fetchArray();
	$role= $res['role'];
    	return $role;
}

function getUser($name){
	$db = new SQLite3('database/user.db');
	$res = $db->query("select * from users where name like '".$name."'");
	return $res;
}

session_start();
if(isset($_POST['file_name'])){
	//we open the database
	$db= new SQLite3('database/user.db');
	$role= getRole($_SESSION['name']);

	if($role == "teacher"){
		//we delete the specified file
		$res= $db->query("delete from teachers where name='".$_POST['file_name']."'");
	}	
	elseif($role == "student"){
		//we delete the specified file
		$res= $db->query("delete from students where name='".$_POST['file_name']."'");
	}
	//we go back to the dashboard
	header("Location:dashGenerator.php");
}
else{
	echo "info pas trouvé\n";
}
?>
