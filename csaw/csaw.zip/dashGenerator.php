<?php
//Definition of strucutral functions
function loadStudDashTop(){
echo "
<!doctype html>
<html>
<head>
    <meta charset='UTF-8'>
        <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
	    <meta http-equiv='x-ua-compatible' content='ie=edge'>
	        <title>C-SAW Student dashboard</title>
		    <link href='bootstrap4/css/bootstrap.min.css' rel='stylesheet' type='text/css'>

    <link href='form.css' rel='stylesheet' type='text/css'>
    </head>

    <body>
    <div class='container-fluid banner' style='padding-top:20px; padding-bottom:0px;'>
        <div class='row' style='padding:0em 2em 2em 2em;'>
            <div class='col-md-3'><img src='../graphics/csaw_logo500-150.png' class='img-fluid' alt='C-SAW logo'> </div>
            <div class='col-md-6'> <img src='../graphics/pixel.png' style='max-height:100%;min-height:6em;'>
                <div style='position:absolute; bottom:0;'>
                    <h1>Student dashboard</h1>
                </div>
            </div>
            <div class='col-md-3' style='text-align:right'>
             <a id='user-guide' href='javascript:viewClick(\"userguide.htm\")'>
                    <img src='../graphics/userguide.png' alt='help' border='0' title='User guide' class='buttonText' /></a>
                <a href='logout.php'><img src='../graphics/logout.png' title='Log out' alt='log out' class='buttonText'></a>
            </div>
        </div>
";
}

function loadStudDashTemplates(){
	loadStudDashTemplatesTop();
	loadStudDashTemplatesRow();
	loadStudDashTemplatesBottom();
}

function loadStudDashTemplatesTop(){
	echo "
        <div class='row'>
            <div class='col-md-1'></div>
            <div class='col-md-10' style='overflow:auto;'>
                <h2 class='largeText tabTitle'>Available templates</h2>
                <table class='boxLog table-striped table' style='width:100%;'>
                    <thead>
                        <tr>
                            <td>template name</td>
                            <td>published by</td>
                            <td class='center'>use</td>
                            <td class='center'>description</td>
                        </tr>
                    </thead>
                    <tbody>
";
}

function loadStudDashTemplatesRow(){
$db= new SQLite3('database/user.db');

$res= $db->query("select * from teachers where shared_group in (select name from groups where students like '%".$_SESSION['name']."%');");
while($row= $res->fetchArray()){ 
	$template_name= $row['name'];
	$owner= $row['owner'];
	$description= $row['description'];
echo "
                        <tr>
                            <td><span class='placeholderText'>".$template_name."</span></td>
                            <td>".$owner."</td>
                            <td class='center'>
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#duplicateModal' onclick='javascript:fileSelected(\"".$name."\")'>
					edit
				    </button>
                            </td>
                            <td class='center'>
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#descriptionModal' onclick='javascript:description(\"".$description."\")'>
					<!--<a href='#'><img src='../graphics/help16.png' class='buttonText' alt='info' title='info'></a>-->
					info
				    </button>
                            </td>
                        </tr>
";
}
}

function loadStudDashTemplatesBottom(){
echo "
                    </tbody>
                </table>

		    </div>
			<div class='col-md-1'></div>
			    <div class='col-md-1'></div>
				<div class='col-md-10'>
					<nav aria-label='Page navigation example'>
					    <ul class='pagination'>
						    <li class='page-item'><a class='page-link' href='#'>Previous</a></li>
						    <li class='page-item'><a class='page-link' href='#'>1</a></li>
						    <li class='page-item'><a class='page-link' href='#'>2</a></li>
						    <li class='page-item'><a class='page-link' href='#'>3</a></li>
						    <li class='page-item'><a class='page-link' href='#'>Next</a></li>
						</ul>
					</nav>
			    </div>
			<div class='col-md-1'></div>
		</div>
";
}

function loadStudDashEssays(){
	loadStudDashEssaysTop();
	loadStudDashEssaysRow();
	loadStudDashEssaysBottom();
}

function loadStudDashEssaysTop(){
	echo "
        <div class='row'>
            <div class='col-md-1'></div>
            <div class='col-md-10'>
                <h2 class='largeText tabTitle'>My templates</h2>
                <table class='boxLog table-striped table' style='width:100%;'>
                    <thead>
                        <tr>
                            <td>template name</td>
                            <td class='center'>template used</td>
                            <td>date created</td>
			    <td>date modified</td>
                            <td class='center'>status</td>
                            <td class='center'>share</td>
                            <td class='center'>more options</td>
                        </tr>
                    </thead>
                    <tbody>
";
}

function loadStudDashEssaysRow(){
$db= new SQLite3('database/user.db');
$res= $db->query("select * from students where owner='".$_SESSION['name']."';");
while($row= $res->fetchArray()){ 
	$file_name= $row['name'];
	$date_created= $row['date_created'];
	$date_modified= $row['date_modified'];
	$template_used= $row['template_used'];
	echo "
                        <tr>
                            <td><span class='placeholderText'>".$file_name."</span></td>
                            <td><span class='placeholderText'>".$template_used."</span></td>
                            <td><span class='placeholderText'>".$date_created."</span></td>
                            <td><span class='placeholderText'>".$date_modified."</span></td>
                            <td class='center'>
                                    <select class='form-control' name='templateStatus' id='templateStatus'>
									<option selected='selected'>draft</option>
									<option>submitted</option>
								</select>
                            </td>
                            <td class='center'>
				<button type='button' class='buttonText' data-toggle='modal' data-target='#shareModal'>share</button>
                            </td>
                            <td class='center'>
                                <div class='dropdown show'>
                                    <a class='dropdown-toggle' href='https://example.com' id='dropdownMenuLink' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><img src='../graphics/more16.png' class='buttonText' alt='more' title='more options'>
                                    </a>
                                    <div class='dropdown-menu' aria-labelledby='dropdownMenuLink'>
					<form action='csaw.php' method='post'>
						<input type='submit' class='dropdown-item' value='view'>
					</form>
					<form action='csaw.php' method='post'>
						<!-- load teacher edit mode -->
						<input type='submit' class='dropdown-item' value='edit'>
					</form>
						<!-- create a copy and rename -->
					    <button type='button' class='dropdown-item' data-toggle='modal' data-target='#duplicateModal' onclick='javascript:fileSelected(\"".$file_name."\")'>duplicate</button>
					<form action='delete.php' method='post'>
						<!-- delete  -->
						<input type='hidden' name='file_name' value='".$file_name."'>
						<input type='submit' class='dropdown-item' value='delete'>
					</form>
                                    </div>
                                </div>
                            </td>
                        </tr>
";
}
}

function loadStudDashEssaysBottom(){
	echo "
                    </tbody>
                </table>

            </div>
            <div class='col-md-1'></div>
            <div class='col-md-1'></div>
            <div class='col-md-10' style='align:right'>
                <nav aria-label='Page navigation example'>
                <ul class='pagination'>
                    <li class='page-item'><a class='page-link' href='#'>Previous</a></li>
                    <li class='page-item'><a class='page-link' href='#'>1</a></li>
                    <li class='page-item'><a class='page-link' href='#'>2</a></li>
                    <li class='page-item'><a class='page-link' href='#'>3</a></li>
                    <li class='page-item'><a class='page-link' href='#'>Next</a></li>
                </ul>
                </nav>
            </div>
            <div class='col-md-1'></div>
        </div>
";
}

function loadStudDashBottom(){
echo "
<div class='col-md-12' style='padding-top:2em; padding-bottom:2em;'>
            <p style='font-size:0.8em; text-align:center;'>
                <a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'><img alt='Creative Commons License' style='border-width:0' src='https://i.creativecommons.org/l/by-nc-sa/4.0/80x15.png' /></a><br /><span xmlns:dct='http://purl.org/dc/terms/' property='dct:title'>C-SAW:Computer-Supported Argumentative Writer</span> <br>by <span xmlns:cc='http://creativecommons.org/ns#' property='cc:attributionName'>Kalliopi Benetos</span> is licensed under a <br><a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'>Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.</p>
        </div>
    </div>
    <script src='essay.js'></script>
    <script src='jquery/jquery.js'></script>

    <!-- Tether -->
    <script src='jquery/'></script>
    <script src='bootstrap4/js/bootstrap.min.js'></script>
</body>

<!-- Modal -->
<div class='modal fade' id='duplicateModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
	<div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form id='modal1' action='duplicate.php' method='post'>
				<div class='modal-header'>
				<h5 class='modal-title' id='exampleModalLabel'>Give your template a new name</h5>
				<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
				<span aria-hidden='true'>&times;</span>
				</button>
				</div>
				<div class='modal-body'>
					<label>Title</label><br>
					<input type='text' name='prompt_title' id='title' class='textOff' onfocus='changeTextClass(\"userText\")' onblur='changeTextClass(\"userText\")' /><br>
					<label>Description</label><br>
					<input type='text' name='prompt_description'>
					<input type='hidden' name='file_name' value=''>
				</div>
				<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancel</button>
					<input type='submit' name='Submit' class='buttonText' value='Ok'>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal -->
<div class='modal fade' id='descriptionModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'> <div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form name='modal2' action='duplicate.php' method='post'>
				<div class='modal-header'>
					<h5 class='modal-title' id='exampleModalLabel'>Description</h5>
					<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
					</button>
				</div>
				<div class='modal-body'>
					<label id='file_description'></label>
				</div>
				<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancel</button>
				</div>
			</form>
		</div>
	</div>
</div>
</html>
";
}

function loadTeachDashTop(){
	echo "
	<!doctype htm
		    <meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
		        <meta http-equiv='x-ua-compatible' content='ie=edge'>
			    <title>C-SAW teacher dashboard</title>
			        <link href='bootstrap4/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
				    <link href='bootstrap4/font-awesome/css/font-awesome.min.css' rel='stylesheet' type='text/css'>

    <link href='form.css' rel='stylesheet' type='text/css'>
</head>

<body>
    <div class='container-fluid banner' style='padding-top:20px; padding-bottom:0px;'>
        <div class='row' style='padding:0em 2em 2em 2em;'>
            <div class='col-md-3'><img src='../graphics/csaw_logo500-150.png' class='img-fluid' alt='C-SAW logo'> </div>
            <div class='col-md-6'> <img src='../graphics/pixel.png' style='max-height:100%;min-height:6em;'>
                <div style='position:absolute; bottom:0;'>
                    <h1>Teacher dashboard</h1>
                </div>
            </div>
            <div class='col-md-3' style='text-align:right'>
                <a id='user-guide' href=\"javascript:viewClick('userguide.htm')\" ></a>
                    <img src='../graphics/userguide.png' alt='help' border='0' title='User guide' class='buttonText' /></a>
                <a href='logout.php'><img src='../graphics/logout.png' title='Log out' alt='log out' class='buttonText'></a>
            </div>
        </div>
";
}

function loadTeachDashTemplates1(){
	loadTeachDashTemplates1Top();
	loadTeachDashTemplates1Rows();
	loadTeachDashTemplates1Bottom();
}

function loadTeachDashTemplates1Top(){
echo "
        <div class='row'>
		<div class='col-md-1'></div>
			<div class='col-md-10' style='overflow:auto;'>
				<h2 class='largeText tabTitle'>Standard teacher templates</h2>
					<table class='boxLog table-striped table' style='width:100%;'>
					    <thead>
					    <tr>
			 <td >template name</td>
			 <td >date created</td>
			 <td >date modified</td>
                         <td class='center'>view</td>
                         <td class='center'>create new from</td>
                         <td class='center'>description</td>
                        </tr>
                    </thead>
                    <tbody>
";
}

function loadTeachDashTemplates1Rows(){
$db= new SQLite3('database/user.db');
$res= $db->query("select name, date_created, date_modified, description from admins;");
while($row= $res->fetchArray()){ 
	$name= $row['name'];
	$date_created= $row['date_created'];
	$date_modified= $row['date_modified'];
	$description= $row['description'];
	echo "
				<tr>
				    <td><span class='placeholderText'>$name</span></td>
				    <td><span class='placeholderText'>$date_created</span></td>
				    <td><span class='placeholderText'>$date_modified</span></td>
				    <td class='center'>
					
					<form id='form' action='csaw.php' method='post'>
					<a href='#'><input type='image' src='../graphics/view16.png' class='buttonText' alt='view' title='view'></a>
					</form>
				    </td>
				    <td class='center'>
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#duplicateModal' onclick='javascript:fileSelected(\"".$name."\")'>
					edit
				    </button>
				    </td>
				    <td class='center'>
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#descriptionModal' onclick='javascript:description(\"".$description."\")'>
					<!--<a href='#'><img src='../graphics/help16.png' class='buttonText' alt='info' title='info'></a>-->
					info
				    </button>
				    </td>
				</tr>
	";
	}
}

function loadTeachDashTemplates1Bottom(){
echo "
                    </tbody>
                </table>

            </div>
            <div class='col-md-1'></div>
            <div class='col-md-1'></div>
            <div class='col-md-10'>
                <nav aria-label='Page navigation example'>
                    <ul class='pagination'>
                        <li class='page-item'><a class='page-link' href='#'>Previous</a></li>
                        <li class='page-item'><a class='page-link' href='#'>1</a></li>
                        <li class='page-item'><a class='page-link' href='#'>2</a></li>
                        <li class='page-item'><a class='page-link' href='#'>3</a></li>
                        <li class='page-item'><a class='page-link' href='#'>Next</a></li>
                    </ul>
                </nav>
            </div>
            <div class='col-md-1'></div>
        </div>
";
}

function loadTeachDashTemplates2(){
	loadTeachDashTemplates2Top();
	loadTeachDashTemplates2Row();
	loadTeachDashTemplates2Bottom();
}

function loadTeachDashTemplates2Top(){
	echo "
        <div class='row'>
	    <div class='col-md-1'></div>
		<div class='col-md-10' >
			<h2 class='largeText tabTitle'>My templates</h2>
				<table class='boxLog table-striped table' style='width:100%;'>
				    <thead>
				    <tr>
					<td>template name</td>
			    <td>standard</td>
			    <td>date created</td>
			    <td>date modified</td>
                            <td class='center'>status</td>
                            <td class='center'>description</td>
                            <td class='center'>more options</td>                          
                        </tr>
                    </thead>
                    <tbody>
";
}

function loadTeachDashTemplates2Row(){
$db= new SQLite3('database/user.db');
$res= $db->query("select name, date_created, date_modified, description, standard, status from teachers;");
while($row= $res->fetchArray()){ 
	$name= $row['name'];
	$date_created= $row['date_created'];
	$date_modified= $row['date_modified'];
	$description= $row['description'];
	$status= $row['status'];
	$standard= $row['standard'];
	echo "
                        <tr>
                            <td><span class='placeholderText'>$name</span></td>
                            <td><span class='placeholderText'>$standard</span></td>
                            <td><span class='placeholderText'>$date_created</span></td>
			    <td><span class='placeholderText'>$date_modified</span></td>

                            <td class='center'>
                                <a href='#'>$status</a>
                            </td>
                            <td class='center'>
                                <!--<a href='#'><img src='../graphics/help16.png' class='buttonText' alt='info' title='info'></a>-->
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#descriptionModal' onclick='javascript:description(\"".$description."\")'>info</button>
                            </td>
                            <td class='center'>                              
                                <div class='dropdown show'>
                                    <a class='dropdown-toggle' href='https://example.com' id='dropdownMenuLink' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><img src='../graphics/more16.png' class='buttonText' alt='more' title='more options'>
                                    </a>
                                    <div class='dropdown-menu' aria-labelledby='dropdownMenuLink'>
                                       <!-- load student view -->
					
                                <form action='csaw.php' method='post'>
					<input type='submit' class='dropdown-item' value='view'>
                                </form>
                                <form action='csaw.php' method='post'>
                                        <!-- load teacher edit mode -->
					<input type='submit' class='dropdown-item' value='edit'>
                                </form>
                                        <!-- create a copy and rename -->
				    <button type='button' class='dropdown-item' data-toggle='modal' data-target='#duplicateModal' onclick='javascript:fileSelected(\"".$name."\")'>duplicate</button>
                                <form action='delete.php' method='post'>
                                        <!-- delete  -->
					<input type='hidden' name='file_name' value='".$name."'>
					<input type='submit' class='dropdown-item' value='delete'>
                                </form>
				    <button type='button' class='dropdown-item' data-toggle='modal' data-target='#shareModal' onclick='javascript:share1(\"".$name."\")'>share</button>
                                    </div>
                                </div>
                            </td>
                           
                        </tr>
";
}
}

function loadTeachDashBottom(){
	echo "
	<div class='col-md-12' style='padding-top:2em; padding-bottom:2em;'>
		            <p style='font-size:0.8em; text-align:center;'>
			                    <a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'><img alt='Creative Commons License' style='border-width:0' src='https://i.creativecommons.org/l/by-nc-sa/4.0/80x15.png' /></a><br /><span xmlns:dct='http://purl.org/dc/terms/' property='dct:title'>C-SAW:Computer-Supported Argumentative Writer</span> <br>by <span xmlns:cc='http://creativecommons.org/ns#' property='cc:attributionName'>Kalliopi Benetos</span> is licensed under a <br><a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'>Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.</p>
					            </div>
						        </div>
							    <script src='essay.js'></script>
    <script src='jquery/jquery.js'></script>

    <!-- Tether -->
    <script src='jquery/'></script>
    <script src='bootstrap4/js/bootstrap.min.js'></script>
</body>

<!-- Modal -->
<div class='modal fade' id='duplicateModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
	<div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form id='modal1' action='duplicate.php' method='post'>
				<div class='modal-header'>
				<h5 class='modal-title' id='exampleModalLabel'>Give your template a new name</h5>
				<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
				<span aria-hidden='true'>&times;</span>
				</button>
				</div>
				<div class='modal-body'>
					<label>Title</label><br>
					<input type='text' name='prompt_title' id='title' class='textOff' onfocus='changeTextClass(\"userText\")' onblur='changeTextClass(\"userText\")' /><br>
					<label>Description</label><br>
					<input type='text' name='prompt_description'>
					<input type='hidden' name='file_name' value=''>
				</div>
				<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancel</button>
					<input type='submit' name='Submit' class='buttonText' value='Ok'>
				</div>
			</form>
		</div>
	</div>
</div>

<!-- Modal -->
<div class='modal fade' id='descriptionModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'> <div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form name='modal2' action='duplicate.php' method='post'>
				<div class='modal-header'>
					<h5 class='modal-title' id='exampleModalLabel'>Description</h5>
					<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
					</button>
				</div>
				<div class='modal-body'>
					<label id='file_description'></label>
				</div>
				<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancel</button>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal -->
<div class='modal fade' id='shareModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'>
	<div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form action='share.php' method='post' name='modal3'>
				<div class='modal-header'>
					<h5 class='modal-title' id='exampleModalLabel'>Select your group to share this document</h5>
					<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
					</button>
				</div>
				<div class='modal-body'>
";
				getGroup();
echo "
				</div>
				<div class='modal-footer'>
					<button type='button' class='buttonText' data-dismiss='modal'>Cancel</button>
				    <button type='button' class='dropdown-item' data-toggle='modal' data-target='#groupModal'>new shared group</button>
					<input type='submit' class='buttonText' onclick='javascript:unshare()' value='unshare'>
				</div>
			</form>
		</div>
	</div>
</div>
<!-- Modal -->
<div class='modal fade' id='groupModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'> <div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form name='modal4' action='group.php' method='post'>
				<div class='modal-header'>
					<h5 class='modal-title' id='exampleModalLabel'>Give your template a new name</h5>
					<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
					</button>
				</div>
				<div class='modal-body'>
					<label id='file_description'>name of the new shared group</label><br>
					<input type='text' name='name'><br>
					<input type='hidden' name='action' class='buttonText' value=''>
";
				getStudents();
echo "
				</div>
				<div class='modal-footer'>
					<button type='button' class='buttonText' data-dismiss='modal'>Cancel</button>
					<input type='submit' name='Submit' class='buttonText' value='Ok' onclick='javascript:addGroup()'>
				</div>
			</form>
		</div>
	</div>
</div>
</html>
";
}

function getStudents(){
$db= new SQLite3('database/user.db');

$res= $db->query("select * from users where role='student';");
while($row= $res->fetchArray()){ 
	$student_name= $row['name'];
	echo "<input type='checkbox' name='students[]' value='".$student_name."')>";
	echo "<label>".$student_name."</label><br>";
}
}

function getGroup(){
$db= new SQLite3('database/user.db');

//$_SESSION['name'] represent the user's name
$res= $db->query("select distinct name from groups where owner='".$_SESSION['name']."'");
echo "<input type='hidden' value='' name='shared_group'>";
echo "<input type='hidden' value='' name='file_name'>";
echo "<input type='hidden' value='' name='share'>";
while($row= $res->fetchArray()){ 
	$group_name= $row['name'];
	echo "<input type='submit' value='".$group_name."' onclick='javascript:share2(\"".$group_name."\")'><br>";
}
}

function loadTeachDashTemplates2Bottom(){
	echo "
                    </tbody>
                </table>

            </div>
            <div class='col-md-1'></div>
            <div class='col-md-1'></div>
            <div class='col-md-10' style='align:right'>
                <nav aria-label='Page navigation example'>
                <ul class='pagination'>
                    <li class='page-item'><a class='page-link' href='#'>Previous</a></li>
                    <li class='page-item'><a class='page-link' href='#'>1</a></li>
                    <li class='page-item'><a class='page-link' href='#'>2</a></li>
                    <li class='page-item'><a class='page-link' href='#'>3</a></li>
                    <li class='page-item'><a class='page-link' href='#'>Next</a></li>
                </ul>
                </nav>
            </div>
            <div class='col-md-1'></div>
        </div>
";
}

function loadAdminDashTop(){
	//display the top of the adminDashboard
	echo"
	<!doctype html>
	<html>
	<head>
	<meta charset='UTF-8'>
	<meta name='viewport' content='width=device-width, initial-scale=1, shrink-to-fit=no'>
	<meta http-equiv='x-ua-compatible' content='ie=edge'>
	<title>C-SAW Admin dashboard</title>
	<link href='bootstrap4/css/bootstrap.min.css' rel='stylesheet' type='text/css'>
	<!--<link href='bootstrap4/lavish-bootstrap.css' rel='stylesheet' type='text/css'>
	-->
	<link href='form.css' rel='stylesheet' type='text/css'>
	</head>

	<body>
	<div class='container-fluid banner' style='padding-top:20px; padding-bottom:0px;'>
		<div class='row' style='padding:0em 2em 2em 2em;'>
			<div class='col-md-3'><img src='../graphics/csaw_logo500-150.png' class='img-fluid' alt='C-SAW logo'> </div>
			<div class='col-md-6'> <img src='../graphics/pixel.png' style='max-height:100%;min-height:6em;'>
				<div style='position:absolute; bottom:0;'>
					<h1>Administrator dashboard</h1>
				</div>
			</div>
			<div class='col-md-3' style='text-align:right'>
		    <a id='user-guide' href='javascript:viewClick(\"userguide.htm\")' >
			    <img src='../graphics/userguide.png' alt='help' border='0' title='User guide' class='buttonText' /></a>
		    <a href='logout.php'><img src='../graphics/logout.png' title='Log out' alt='log out' class='buttonText'></a></div>
		</div>
";
}

function loadAdminDashTemplate(){
	loadAdminDashTemplateTop();
	loadAdminDashTemplateRow();
	loadAdminDashTemplateBottom();
}

function loadAdminDashTemplateTop(){
echo "
		<div class='row'>
		<div class='col-md-1'></div>
        <!-- description popup -->
            <div id='description-dialog' class='modal ' role='dialog'>
                    <div class='modal-dialog'>
                        <!-- Modal content-->
                        <div class='modal-content'>
                            <div class='modal-header'>
                               
                                <h4 class='modal-title'>Standard A info</h4>
                            </div>
                            <div class='modal-body'>
                                <p id='desc'>This is a basic essay structure using a thesis-antithesis-synthesis argument model. It includes an introduction and conclusion.</p>
                                <div id='descForm' style='display: none'><form>
                                    <textarea class='boxLog' name='description' rows='5' cols='50'>insert descripion here</textarea>  
                                </form></div>
                            </div>
                            <div class='modal-footer'>
                                <button type='button' class='buttonText' id='editDesc'>edit</button>
                                <button type='button' class='buttonText' id='saveDesc' style='display: none'>save</button> 
                                <button type='button' class='buttonText' id='cancelDesc' style='display: none'>cancel</button>
                                <button type='button' class='buttonText' data-dismiss='modal' id='closeDesc'>Close</button>
                            </div>
                        </div>

                    </div>
                </div>
            <!-- description popup end -->
        <!-- share popup -->
            <div id='share-dialog' class='modal ' role='dialog'>
                    <div class='modal-dialog'>
                        <!-- Modal content-->
                        <div class='modal-content'>
                            <div class='modal-header'>
                               
                                <h4 class='modal-title'>Share template</h4>
                            </div>
                            <div class='modal-body' id='share'>
                               <h2>Select people to share template with</h2>
    <select id='sbOne' multiple='multiple'>
        <option value='1'>Alpha</option>
        <option value='2'>Beta</option>
        <option value='3'>Gamma</option>
        <option value='4'>Delta</option>
        <option value='5'>Epsilon</option>
    </select>

    <select id='sbTwo' multiple='multiple'>
        <option value='6'>Zeta</option>
        <option value='7'>Eta</option>
    </select>

    <br />

    <input type='button' id='left' value='<' />
    <input type='button' id='right' value='>' />
    <input type='button' id='leftall' value='<<' />
    <input type='button' id='rightall' value='>>' />
                            </div>
                            <div class='modal-footer'>
                                <button type='submit' class='buttonText' id='saveShare'>save</button>
                                <button type='button' class='buttonText' data-dismiss='modal' id='cancelShare'>cancel</button>
                                
                            </div>
                        </div>

                    </div>
                </div>
            <!-- share popup end -->         


		<div class='col-md-10' >
            
			<h2 class='largeText tabTitle'>Standard templates</h2>
			<table class='boxLog table-striped table'  style='width:100%;'>
				<thead>
				<tr><td>template name</td>
					<td>date created</td>
					<td>date modified</td>
					<td>status</td>
					<td>owner</td>
                    <td class='center'>description</td>
					<td class='center'>more options</td>
                    
					</tr>
				</thead>
				<tbody>
";
}

function loadAdminDashTemplateRow(){
$db= new SQLite3('database/user.db');
$res= $db->query("select * from admins;");
while($row= $res->fetchArray()){ 
	$file_name= $row['name'];
	$date_created= $row['date_created'];
	$date_modified= $row['date_modified'];
	$description= $row['description'];
	$status= $row['status'];
	$template= $row['template'];
echo "
					<tr>
						<td><span class='placeholderText'>".$file_name."</span></td>
						<td><span class='placeholderText'>".$date_created."</span></td>
						<td><span class='placeholderText'>".$date_modified."</span></td>
                        <td style='width:10%'><form action='#'>
								<select class='form-control' name='templateStatus2' id='templateStatus2'>
									<option selected='selected'>draft</option>
									<option>published</option>
								</select>
							</form></td>
						<td class='placeholderText'>admin</td>
                        <td class='center'>
                    <!-- description -->
				    <button type='button' class='buttonText' data-toggle='modal' data-target='#descriptionModal' onclick='javascript:description(\"".$description."\")'>
					<!--<a href='#'><img src='../graphics/help16.png' class='buttonText' alt='info' title='info'></a>-->
					info
					</button>
			<td class='center'>                              
                                <div class='dropdown show'>
                                    <a class='dropdown-toggle' href='https://example.com' id='dropdownMenuLink' data-toggle='dropdown' aria-haspopup='true' aria-expanded='false'><img src='../graphics/more16.png' class='buttonText' alt='more' title='more options'></a>
                                    <div class='dropdown-menu' aria-labelledby='dropdownMenuLink'>
					<form name='edit' method ='post' action='teach.php'>
						<input type='hidden' id='essayFile' name='existingFile' value='".$file_name."'>
						<input type='submit' name='getFile' class='dropdown-item' value='edit' ><!-- load selected template into teach.php -->
						<a class='dropdown-item' href='#'>duplicate</a>
						<a class='dropdown-item' href='#'>delete</a>
						<a class='dropdown-item' href='#' data-toggle='modal' data-target='#share-dialog'>share</a><!-- select from available students -->
					</form>
                                    </div>
                                </div>
			</td>
					</tr>
";
}
}

function loadAdminDashTemplateBottom(){
echo "
				</tbody>
			</table>
		</div>
		<div class='col-md-1'></div>
        <div class='col-md-1'></div>
            <div class='col-md-10' style='align:right'>
                
	                        <ul class='pagination'>
				                        <li class='page-item'><a class='page-link' href='#'>Previous</a></li>
							                        <li class='page-item'><a class='page-link' href='#'>1</a></li>
										                        <li class='page-item'><a class='page-link' href='#'>2</a></li>
													                        <li class='page-item'><a class='page-link' href='#'>3</a></li>
																                        <li class='page-item'><a class='page-link' href='#'>Next</a></li>
																			                    </ul>
																					                
																					                </div>
																							            <div class='col-md-1'></div>
																								    	</div>
";
}


function loadAdminDashBottom(){
echo "
	<div class='col-md-12' style='padding-top:2em; padding-bottom:2em;'>
		<p style='font-size:0.8em; text-align:center;'> 
			<a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'>
				<img alt='Creative Commons License' style='border-width:0' src='https://i.creativecommons.org/l/by-nc-sa/4.0/80x15.png' />
			</a><br />
			<span xmlns:dct='http://purl.org/dc/terms/' property='dct:title'>C-SAW:Computer-Supported Argumentative Writer</span> <br>
			by 
			<span xmlns:cc='http://creativecommons.org/ns#' property='cc:attributionName'>Kalliopi Benetos</span> 
			is licensed under a 
			<br>
			<a rel='license' href='http://creativecommons.org/licenses/by-nc-sa/4.0/'>Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License</a>.
		</p>
	</div>
</div>
    <script src='essay.js'></script>
<script src='jquery/jquery.js'></script> 

<!-- Tether --> 
<script src='https://cdnjs.cloudflare.com/ajax/libs/tether/1.2.0/js/tether.min.js' integrity='sha384-Plbmg8JY28KFelvJVai01l8WyZzrYWG825m+cZ0eDDS1f7d/js6ikvy1+X+guPIB' crossorigin='anonymous'></script> 
<script src='bootstrap4/js/bootstrap.min.js'></script>
    <script>
        $(document).ready(function(){
    $('#editDesc').click(function(){
        $('#descForm, #saveDesc, #cancelDesc').show();
        $('#desc, #editDesc, #closeDesc').hide();
    });
    $('#saveDesc').click(function(){
        $('#descForm, #saveDesc, #cancelDesc').hide();
        $('#desc, #editDesc, #closeDesc').show();
    });
    $('#cancelDesc').click(function(){
        $('#descForm, #saveDesc, #cancelDesc').hide();
        $('#desc, #editDesc, #closeDesc').show();
    });       
});
    </script>
    <script type='text/javascript'>
        $(function () {
            function moveItems(origin, dest) {
                $(origin).find(':selected').appendTo(dest);
            }

            function moveAllItems(origin, dest) {
                $(origin).children().appendTo(dest);
            }

            $('#left').click(function () {
                moveItems('#sbTwo', '#sbOne');
            });

            $('#right').on('click', function () {
                moveItems('#sbOne', '#sbTwo');
            });

            $('#leftall').on('click', function () {
                moveAllItems('#sbTwo', '#sbOne');
            });

            $('#rightall').on('click', function () {
                moveAllItems('#sbOne', '#sbTwo');
            });
        });
    </script>
</body>

<!-- Modal -->
<div class='modal fade' id='descriptionModal' tabindex='-1' role='dialog' aria-labelledby='exampleModalLabel' aria-hidden='true'> <div class='modal-dialog' role='document'>
		<div class='modal-content'>
			<form name='modal2' action='duplicate.php' method='post'>
				<div class='modal-header'>
					<h5 class='modal-title' id='exampleModalLabel'>Description</h5>
					<button type='button' class='buttonText' data-dismiss='modal' aria-label='Close'>
					<span aria-hidden='true'>&times;</span>
					</button>
				</div>
				<div class='modal-body'>
					<label id='file_description'></label>
				</div>
				<div class='modal-footer'>
					<button type='button' class='btn btn-secondary' data-dismiss='modal'>Cancel</button>
				</div>
			</form>
		</div>
	</div>
</div>
</html>
";
}


function getUser($name){
	$db = new SQLite3('database/user.db');
	$res = $db->query("select * from users where name like '".$name."'");
	return $res;
}

function getRole($name){
	$res= getUser($name)->fetchArray();
	$role= $res['role'];
    	return $role;
}

function dashGenerator($role){
	if($role == "student"){
		loadStudDashTop();
		loadStudDashTemplates();
		loadStudDashEssays();
		loadStudDashBottom();
	}	
	elseif($role == "teacher"){
		loadTeachDashTop();
		loadTeachDashTemplates1();
		loadTeachDashTemplates2();
		loadTeachDashBottom();
	}
	else{
		loadAdminDashTop();
		loadAdminDashTemplate();
		loadAdminDashBottom();
	}
}

//code part
//Native code to begin the user session
session_start();
$role= getRole($_SESSION["name"]);
//generate the appropriate dashboard according the user's role
dashGenerator($role);
?>
	
