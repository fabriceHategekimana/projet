
function browserCheck(){
	if(navigator.userAgent.indexOf("Firefox")!=-1){
		var versionindex=navigator.userAgent.indexOf("Firefox")+8
		if (parseInt(navigator.userAgent.charAt(versionindex))>=1.5)

 alert("You are using a browser that is incompatible with the C-SAW software. Please go to <a href='http://tecfa.unige.ch/staf/staf-k/benetos/thesis/devvis/userguide.htm'>the User Guide</a> for further instructions.")
}
}

 function submitForm() { // submits form
        document.getElementById("fileChoice").submit();
    }
    function btnSearchClick()
    {
        if (document.getElementById("fileChoice")) {
            setTimeout("submitForm()", 5000); // set timout
       }
    }


function noArgs(){
alert("You need to keep least one argument. No changes have been made.");
}


function fileSelect(){

        alert("<div style='margin-left:30%;margin-right:30%;border: 1pt dashed #9BACB0;'><form name='chooseFile' action='editHTML5.php' method='post'><p><input type='radio' id='eFile' name='getFile' value='selectedFile' /><input type='file' cols='20'  id='eFile2' name='essayFile' /><br/><div class='instruct' style='margin-left:2em;'>Select an existing essay</div></p><p><input type='radio' id='nFile' name='getFile' value='newFile' /><input type='text' cols='30'  id='eFile2' name='newFileName' /><br/><div class='instruct' style='padding-left:2em;'>Begin a new essay (give your file a new name with a .xml file ending, e.g. MyEssay.xml)</div></p><p>&#13;<br/></p><p style='text-align:center;'><input type='submit' value='submit choice' class='buttonText'/></p></form></div> ");
}


// jquery date picker
$(function() {
                 $("#dateSet").datepicker({dateFormat: "mm-dd-yy"});
                 });

/* for save as file dialogs */
$( function() {
    $( "#saveAsdialog" ).dialog();
  } );





 // draggable info words
$(function() {
 // for intro words drags
    $( "#importanceList, #conflictList, #solutionList" ).draggable({ containment: "#introTable", scroll: false, stack: "div",  opacity: 0.60 });
    $("#importanceList, #conflictList, #solutionList");
 // for arg words drags
    $(".boxFloat, .boxArg").load(function(event) {
       var $list = $(this).attr("id");
 //   console.log($list);
       var $table = $(this).parentsUntil(".whichTable").parent();
//    console.log($table);
    $("#" + $list).draggable({ containment: $table, scroll: false, stack: "div" });
    $(".boxArg").resizable({handles: "e, w, se, sw"});
    });
// for conclusion words drags
    $( "#thesis_summaryList, #argument_summaryList, #consequencesList, #closingList" ).draggable({ containment: "#concluTable", scroll: false, stack: "div" });
// disables drag when in text
    $(".boxFloat, .boxArg").draggable({ cancel: ".maintext, .instruct, .optional, textarea, input, .stick" });
    $(".maintext, .instruct, .optional, textarea, input, .stick").css("cursor", "text");
    $(".maintext, .instruct, .optional, textarea, input, .stick").enableSelection();

});

// displays or hides form fields text and displays or hides appropriate toggle or input button on side
function toggleForm(id) {
label = id;
img = "edit" + id;
input = "cancel" + id;
// see if I can add increment to xml
labelElement = document.getElementById(label);
imgElement = document.getElementById(img);
inputElement = document.getElementById(input);

if ((labelElement.style.display=='none')){
   	labelElement.style.display='block';
	imgElement.style.display='none';
	inputElement.style.display='block';
	}else{
	labelElement.style.display='none'
	imgElement.style.display='block';
	inputElement.style.display='none';
	}
}

// displays or hides form fields text
function toggleNote(id) {
label = id;
img = "note" + id;

// see if I can add increment to xml
labelElement = document.getElementById(label);
imgElement = document.getElementById(img);

if ((labelElement.style.display=='none')){
	labelElement.style.display='block';
	imgElement.src = "../graphics/close.png";
	imgElement.title = "close note";
	}else{
	labelElement.style.display='none'
	imgElement.src = "../graphics/note.png";
	imgElement.title = "edit note";
	}
}




// displays or hides help text
function toggleLabel(id) {
label = id;
img = "img" + id;

// see if I can add increment to xml
labelElement = document.getElementById(label);
imgElement = document.getElementById(img);

if ((labelElement.style.display=='none')){
	labelElement.style.display='block';
	imgElement.src = "../graphics/close.png";
	imgElement.title = "close";
	}else{
	labelElement.style.display='none'
	imgElement.src = "../graphics/help.png";
	imgElement.title = "help for this element";
	}
}

// displays or hides info words text
function toggleInfo(id) {
label = id;
img = "img" + id;

// see if I can add increment to xml
labelElement = document.getElementById(label);
imgElement = document.getElementById(img);

if ((labelElement.style.display=='none')){
	labelElement.style.display='block'
	imgElement.src = "../graphics/infoclose.png";
	imgElement.title = "close connecting words";
	}else{
	labelElement.style.display='none'
	imgElement.src = "../graphics/info.png";
	imgElement.title = "connecting words";
	}

}


// show/hide svg labels
function toggleIn(id) {
hint = id;
hintElement = document.getElementById(hint);
hintElement.style.display='block';
}
function toggleOut(id) {
hint = id;
hintElement = document.getElementById(hint);
hintElement.style.display='none';
}


function toggleIcon(id) {
label = id;
icon = "img" + id;

labelElement = document.getElementById(label);
imgElement = document.getElementById(icon);

if (labelElement.style.display=='none'){
	labelElement.style.display='block'
	imgElement.src = "../graphics/hide.png";
	imgElement.title = "hide text view";
	}else{
	labelElement.style.display='none'
	imgElement.src = "../graphics/tview.png";
	imgElement.title = "view text for this element";
	}

}

//enable/disable forms
  function enableSimpleArg(form)
  {
    if (!form.sArg.checked){
            form.sArg.focus();
 //      form.sArg.checked=true;
	 }
  }

  function enableCounterArg(form)
  {
    if (!form.cArg.checked)
	    {
	        form.cArg.focus();
//		 form.cArg.checked=true;
		}
  }




// activates simple and counterargument forms
  function changeClass(id) {
	 activeArg=document.getElementById(id);
	 if (activeArg.className=='Off') {
	 activeArg.className='On';
	 } else{
		 activeArg.className='Off';
	 }
  }

// displays or hides simple arg form
function toggleFormPart(id) {
label = id;
labelElement = document.getElementById(label);
if ((labelElement.style.display=='none')){
	labelElement.style.display='block';
	}else{
	labelElement.style.display='none'
	}
}

// displays or hides simple arg form
function toggleInline(id) {
label = id;
labelWords = document.getElementById(label);
if ((labelWords.style.display=='none')){
	labelWords.style.display='inline';
	}else{
	labelWords.style.display='none'
	}
}

 /* displays or hides simple arg form  -- OLD
function includeArgElement(id) {
label = id;
labelElement = document.getElementById(label);
if ((labelElement.style.display=='none')){
	labelElement.style.display='block';
	}else{
	labelElement.style.display='none'
	}
}
*/
 /* displays or hides simple arg SVG -- OLD
function includeArgSVG(id) {
label = id;
labelElement = document.getElementById(label);
if ((labelElement.style.display=='none')){
	labelElement.style.display='block';
	}else{
	labelElement.style.display='none'
	}
}
*/

  // highlights text fields from svg mouseover
  function changeTextClass(id) {

	 activeField=document.getElementById(id);
	 if (activeField.className=='textOff') {
	 activeField.className='textOn';
	 } else{
		 activeField.className='textOff';
	 }
  }


  function saveFileAs() {
  Title="Save file as (give a new name ending in .xml)";
  Text="my new file";
  }


    // lists of connectives for fields.

// help and information window
  function fbWindow() {
	  var htmlpage= " ";
    var win_opt= "toolbar=no,location=no,directories=no,status=no,menubar=no,";
	win_opt += "scrollbars=yes,resizable=yes,copyhistory=0,";
	win_opt += "width=350,height=300";

	// new window
	popup= window.open("","Title",win_opt);

	// window content
	popup.document.open();

	//bring window to front
	  popup.focus();

	htmlpage += "<html><head><title>" + Title + "</title><link href='form.css' rel='stylesheet' type='text/css'></head><body>";
	htmlpage += "<p class='instruct'>" + Title + "</p>";
	htmlpage += " <p class='maintext'> "+ Text + " </p> ";
	//htmlpage += "<form>"
	htmlpage += "<p align='center'> <input class='button' type='button' value=' close window ' " + "onClick='window.close()'></p>"
	//htmlpage += "</form>";
	htmlpage += "</body></html>";
	popup.document.write(htmlpage);
	popup.document.close();
}



//open and print version and go back to master page
function printdoc(){
	window.print();
	history.back(1);
}

//simple views window
var view;

// user guide
function viewClick(url) {
  view= window.open(url,'view text','directories=yes,menubar=yes,scrollbars=yes,resizable=yes,top=50,left=50,width=640,height=700');
  view.focus();
}

// print and textHelpOnly views
function popup(form) {
    window.open('','formpopup','height=700,width=680,left=10,top=10,resizable=yes,scrollbars=yes,toolbar=no,menubar=no,location=no,directories=no,status=yes');
    form.target = 'formpopup';
    view.focus(this);
}

// dynamically increasing the height of textarea while typing
function textAreaAdjust(o) {
    o.style.height = "1px";
    o.style.height = (15+o.scrollHeight)+"px";
}

function fileSelected(name){ 
	//alert(name);
	document.forms["modal1"].elements["file_name"].value= name;
}

function description(description){ 
	//alert(name);
	document.getElementById("file_description").innerHTML= description;
}

function share1(file_name){ 
	//alert(shared_group);
	document.forms["modal3"].elements["file_name"].value= file_name;
}

function share2(shared_group){ 
	//alert(shared_group);
	document.forms["modal3"].elements["share"].value= "share";
	document.forms["modal3"].elements["shared_group"].value= shared_group;
}

function unshare(){ 
	document.forms["modal3"].elements["share"].value= "unshare";
}

function addGroup(){ 
	document.forms["modal4"].elements["action"].value= "add";
}
/*
//graph views window
var graph;
function viewGraph(url) {
  graph= window.open(url,'view graphic map','menubar=yes,scrollbars=yes,resizable=yes,width=380,height=540');
  graph.focus();
}
//popup editing window
var editThis;
function editView(url) {
  editThis= window.open(url,'open editing view','menubar=yes,scrollbars=yes,resizable=yes,width=600,height=540');
  editThis.focus();
}
*/







