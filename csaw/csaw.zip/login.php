<?php
//commentaire
//permission
umask(0);
//put sha1() encrypted password here - example is 'hello'
//$password = '5324fe91536f2bea3b26c930f64eedffa223a9db';
//$password = 'e88ca6592d43c77a05b17c3023dcd06093c61647';

//definition of registering and loging functions
function getUser($name){
	$db = new SQLite3('database/user.db');
	$res = $db->query("select * from users where name like '".$name."'");
	return $res;
}

function getUserName($name){
	$res= getUser($name)->fetchArray();
	$name= $res['name'];
    	return $name;
}

function getPassword($name){
	$res= getUser($name)->fetchArray();
	$password= $res['password'];
    	return $password;
}

function getRole($name){
	$res= getUser($name)->fetchArray();
	$role= $res['role'];
    	return $role;
}

function isNameAlreadyUsed($name){
	$user2= getUserName($name);
	if(isset($user2)){ 
		$res= true;
	}
	else{ 
		$res= false;
	}
	return $res;
}

function isSamePassword($password1, $password2){
	if($password1 == $password2){
		return true;
	}
	else{
		return false;
	}
}

function register($name, $password1, $password2, $role){
	if(isNameAlreadyUsed($name)){
		echo "Error: the name is already used\n";
	}
	else { 
		if(isSamePassword($password1, $password2)){
			echo "account created\n";
			createAccount($name, $password1, $role);
		}
		else{
			echo "Error: The given passwords don't match.\n";
		}
	}
}

function createAccount($name, $password, $role){
	echo "save \n";
	if($role == "student"){
		save($name, $password, $role);
		//sendConfirmationMail($name);
	}
	else{
		save($name, $password, $role);
		//adminConfirmation();
	}
}

function save($name, $password, $role){
	chmod("database/user.db", 0777); 
	$db = new SQLite3('database/user.db');
	//insert data in the user table
	$db->query("insert into users (name, password, role) values ('".$name."', '".sha1($password)."', '".$role."')");

	if($role == "student"){
		$db->query("insert into students (name, essays, teacher) values ('".$name."', ' ', ' ')"); 
	}
	elseif($role == "teacher"){
		$db->query("insert into teachers (name, template, students) values ('".$name."', ' ', ' ')"); 
	}
	else{
		echo "You can't register as an administrator\n";
	}
}

function sendConfirmationMail($name){
	$to = $name;
	$subject = "csaw mail";

	$message = "You have been registered. \n You can log in and check your account.";

	// Always set content-type when sending HTML email
	 $headers = "MIME-Version: 1.0" . "\r\n";
	 $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";

	 // More headers
	 $headers .= 'From: <csaw>' . "\r\n";

	 mail($to,$subject,$message,$headers);
}

function adminConfirmation($name){
	//will send a mail to the administrator
	//the administrator will decide the user can be a teacher
	echo "admin confirmation\n";
}

//---------------------------------------code to log in---------------------

function loadPage(){
	echo "success\n";
}

function errorAtConnectionMessage(){
	echo "the connexion failed\n";
}

function login($name, $password){
	if(isNameAlreadyUsed($name)){
		$password2= getPassword($name);
		if(isSamePassword(sha1($password), $password2)){
			$loggedIn= true;
			getRole($name);
			loadPage();
		}
		else{
			$loggedIn= false;
			errorAtConnectionMessage();
		}
	}
	else{
		errorAtConnectionMessage();
	}
	return $loggedIn;
}

//beginning of the code
session_start();
if (!isset($_SESSION['loggedIn'])) {
    $_SESSION['loggedIn'] = false;
}

//test for log in
if(isset($_POST['user']) and isset($_POST['password'])){
	$loggedIn= login($_POST['user'], $_POST['password']);
	if($loggedIn == false){
		echo "wrong password\n";	
	}
	else{
		$_SESSION["name"]= $_POST['user'];
		$_SESSION['loggedIn'] = true;
		$role= getRole($_POST['user']);
		//to move to the next page
		header("Location:dashGenerator.php");
	}
}
//test for register
elseif(isset($_POST['nEmail']) and isset($_POST['nPassword1']) and isset($_POST['nPassword2']) and (isset($_POST['nTeacher']) or isset($_POST['nStudent']))){
	if(isset($_POST['nStudent'])){
		$role= "student";
	}
	else{
		$role= "teacher";
	}
	register($_POST['nEmail'], $_POST['nPassword1'],$_POST['nPassword2'], $role);
	header("Location:login.html");
}


if (!$_SESSION['loggedIn']): ?>

<html>
<head><title>C-SAW Login</title>
<script language="javascript" src="essay.js" type="text/javascript" ></script>
<link href="form.css" rel="stylesheet" type="text/css" /></head>
  <body>
  <div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
  <div style="margin-left:30%;margin-right:30%;padding: 3em;border: 1pt dashed #9BACB0;">
    <p>You need to login</p>
    <form method="post">
      Password: <input type="password" name="password"/> <br />
      <input type="submit" name="submit" value="Login" class="buttonText"/>
    </form>
    </div>
  </body>
</html>

<?php
exit();
endif;
?>

