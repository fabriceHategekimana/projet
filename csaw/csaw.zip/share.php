<?php
session_start();
if(isset($_POST['shared_group']) and isset($_POST['file_name'])){
	$db= new SQLite3('database/user.db');

	$shared_group= $_POST['shared_group'];
	$file_name= $_POST['file_name'];
	$owner= $_SESSION['name'];

	if($_POST['share'] != "unshare"){

		$db->query("update teachers set shared_group='".$shared_group."', status='shared' where (name='".$file_name."' and owner='".$_SESSION['name']."')");
	}
	else{
		$db->query("update teachers set shared_group='-', status='unshared' where (name='".$file_name."' and owner='".$_SESSION['name']."')");
	}
header("Location:dashGenerator.php");
}
else{
	echo "Try to launch this page by using a dashboard and the 'share' option\n";
}

?>
