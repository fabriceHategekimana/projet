<?php
session_start();
if(isset($_POST['name'])){
	$db= new SQLite3('database/user.db');
	if($_POST['action'] == "add"){
		$students= implode(",", $_POST['students']);
		$db->query("insert into groups (owner, name, students) values ('".$_SESSION['name']."','".$_POST['name']."','".$students."');");
	}
header("Location:dashGenerator.php");
}
else{
	echo "voila\n";
}
?>
