<?php

/* by kalli benetos
Argumentative essay online tool
April 2014
*/

// All files created by this script will have permissions rw-rw-rw/666.
umask(0);

//phpinfo ();
session_start();

error_reporting(E_ALL);
//phpinfo();

// FROM  http://php.net/manual/en/security.magicquotes.disabling.php
if (get_magic_quotes_gpc()) {
    $process = array(&$_GET, &$_POST, &$_COOKIE, &$_REQUEST);
    while (list($key, $val) = each($process)) {
        foreach ($val as $k => $v) {
            unset($process[$key][$k]);
            if (is_array($v)) {
                $process[$key][stripslashes($k)] = $v;
                $process[] = &$process[$key][stripslashes($k)];
            } else {
                $process[$key][stripslashes($k)] = stripslashes($v);
            }
        }
    }
    unset($process);
}



header ("Content-type: application/xhtml+xml");

//HTML global display page functions

function recordTime() {
time();
//echo date("d/m/y : H:i:s", time());
}

function getUser($name){
	$db = new SQLite3('database/user.db');
	$res = $db->query("select * from users where name like '".$name."'");
	return $res;
}

function getRole($name){
	$res= getUser($name)->fetchArray();
	$role= $res['role'];
    	return $role;
}

function getUsersFiles($type_of_file){
	//$_SESSION["name"] is the user name
	$role= getRole($_SESSION["name"]);
	$db= new SQLite3('database/user.db');
	if($role == "admin"){
		$res= $db->query("select * from admins;");
		while($row= $res->fetchArray()){ 
			$file_name= $row['name'];
			echo "<option value='$file_name'>".$file_name."</option>";
		}
	}
	elseif($role == "teacher"){
		//$_SESSION["name"] is the user name
		$res= $db->query("select * from teachers where owner='".$_SESSION['name']."';");
		while($row= $res->fetchArray()){ 
			$file_name= $row['name'];
			echo "<option value='$file_name'>".$file_name."</option>";
		}
	}
	elseif($role == "student"){
		if($type_of_file == "essay"){
			//$_SESSION["name"] is the user name
			$res= $db->query("select * from students where owner='".$_SESSION['name']."';");
		}
		elseif($type_of_file == "template"){
			$res= $db->query("select * from teachers where shared_group in (select name from groups where students like '%".$_SESSION['name']."%');");
		}
			while($row= $res->fetchArray()){ 
				$file_name= $row['name'];
				echo "<option value='$file_name'>".$file_name."</option>";
			}
	}
}

function head() {
echo '<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" xmlns:svg="http://www.w3.org/2000/svg" xml:lang="en" lang="en">

<head><meta http-equiv="Content-type" content="text/html; charset=UTF-8" />
<title>C-SAW Writer</title>';
// stylesheets
echo'<link href="form.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.structure.css" rel="stylesheet" type="text/css" />
<link href="jquery/jquery-ui.theme.css" rel="stylesheet" type="text/css" />';


// external jquery standand, ui and form check plugin
echo '<script language="javascript" src="jquery/jquery.js" type="text/javascript" />
<script language="javascript" src="jquery/jquery-ui.js" type="text/javascript" />';

// scripts for c-saw functions
echo '<script language="javascript" src="essay.js" type="text/javascript" />';

// order log/log.js loading, this client-side script defines functions to log user's activity
echo '<script language="javascript" src="log/log.js" type="text/javascript"/>';

echo '
</head><body>
<div style="position: absolute; left: 8%;top: 20px"><img src="../graphics/logo.png" alt="csaw" title="C-SAW"/></div>
<h2 align="center"><br/>Computer-Supported Argumentative Writer</h2>
<div style="position: absolute; right: 8%;top: 40px">
<a id="user-guide" href="javascript:viewClick(\'userguide.htm\')" ><img src="../graphics/userguide.png" alt="help" border="0" title="User guide" class="buttonText" /></a>&#160;&#160;<a href="logout.php" ><img src="../graphics/logout.png" alt="log out" border="0" title="Log out" class="buttonText" /></a>
</div>
<!-- TOP MENU ANCHORED LINKS
<h3 align="center"><a href="#heading" class="button">&#160;heading and title&#160;</a>
&#160;&#160; <a href="#intro"  class="button">&#160;introduction&#160;</a>
&#160;&#160; <a href="#arguments" class="button">&#160;arguments&#160;</a>
&#160;&#160; <a href="#conclusion" class="button">&#160;conclusion&#160;</a>
</h3> -->';
}

function newFileSelect(){
   echo'<h3> Current file loaded: '.$GLOBALS["file"].'</h3>';

// buttons for loading other files

// Choose another xml file to load FORM
echo '<div class="container">'; //tabs container
        echo'<div class="tabs" style="display:inline-block"><a id="load-essay" class="buttonTab" href="javascript: toggleLabel(\'chooseFileForm\')">load an essay</a>
        <div id="chooseFileForm" class="boxFileselect" style="display:none">
        <form name="chooseFile" method ="post" action="' . $_SERVER["PHP_SELF"] . '">

 <select name="loadFile">';
 //$dir = "./"; // for tests
 //$files = scandir($dir);

 //foreach ($files as $file) {

         //if (substr_compare($file, ".xml", -4) == 0) {
                 //echo "<option value=\"$dir/$file\">$file</option>";
         //}
 //}
 getUsersFiles("essay");

 echo'</select><br/><span class="instruct">Select one of your existing essays to load</span>
 <p class="instruct">
 <input type="submit" value="load essay" class="buttonText" style="cursor:pointer"/>&#160;<a id="load-essayCancel" class="buttonText" href="javascript: toggleLabel(\'chooseFileForm\')">cancel</a></p>
</form></div>
</div>';

// Select a teacher template -- currently same as load FORM above -- MUST include a save as popup!!!
      echo'<div class="tabs" style="display:inline-block"><a id="load-template" class="buttonTab" href="javascript: toggleLabel(\'chooseTemplateForm\')">load an essay template</a>
        <div id="chooseTemplateForm" class="boxFileselect" style="display:none">
        <form name="chooseFile" method ="post" action="' . $_SERVER["PHP_SELF"] . '">

 <select name="loadFileTemp">';
 //$dir = "./"; // for tests
 //$files = scandir($dir);

// foreach ($files as $file) {

         //if (substr_compare($file, ".xml", -4) == 0) {
                 //echo "<option value=\"$dir/$file\">$file</option>";
         //}
 //}
getUsersFiles("template");

 echo'</select><br/><span class="instruct">Select a teacher template to load</span>
 <p class="instruct">
 <input type="submit" value="load essay" class="buttonText" style="cursor:pointer"/>&#160;<a id="load-templateCancel" class="buttonText" href="javascript: toggleLabel(\'chooseTemplateForm\')">cancel</a></p>
</form></div>
</div>';

// Save as new xml personal file FORM
echo'<div class="tabs" style="display:inline-block">
        <a id="save-as-new-file" class="buttonTab" href="javascript: toggleLabel(\'saveAsFileForm\')">save as new essay</a>

        <div id="saveAsFileForm" class="boxFileselect" style="display:none">
        <form name="saveAsFile" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
        <p class="instruct">
        <input type="text" cols="40"  id="eFile2" name="saveAsFilename" /><br/>Give your file a new name with a .xml file ending, e.g. MyEssay.xml</p><p><input type="submit" value="save file as" class="buttonText" />&#160;<a id="saveAsEssayCancel" class="buttonText" href="javascript: toggleLabel(\'saveAsFileForm\')">cancel</a></p></form></div>
        </div>';

echo '</div><p/>';}


function footer(){
        echo '<div align="center">';
//<!--      TRACE global loaded '.$GLOBALS["file"].' file='.$file.' -->

        echo '<form name ="helpTextView" method ="post" action="textHelpOnly.php" target="popUp"
        onsubmit="popup(this);" style="display:inline!important;">
        <input type="hidden" name="toPopFile" value="'.$GLOBALS["file"].'" />
        <input id="view-tips" type="image" value="submit"  class="buttonText" title="text view with help" src="../graphics/viewtips.png" align="middle" />
        <span class="iconText"> view text with help </span></form>

        <form name ="printView" method ="post" action="printOnly.php" target="popUp" onsubmit="popup(this);" style="display:inline!important;">
        <input type="hidden" name="toPopFile" value="'.$GLOBALS["file"].'" />
        <input id="print-view" type="image" value="submit"  class="buttonText" title="print view" src="../graphics/printview.png" align="middle" />
        <span class="iconText"> print view </span></form>
</div>

<fieldset><p align="center" style="font-size:0.8em"><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US"><img alt="Creative Commons License" style="border-width:0" src="http://i.creativecommons.org/l/by-nc-nd/3.0/88x31.png" /></a><br /><span xmlns:dct="http://purl.org/dc/terms/" property="dct:title">C-SAW</span> by <a xmlns:cc="http://creativecommons.org/ns#" href="mailto:kalliopi.benetos@unige.ch" property="cc:attributionName" rel="cc:attributionURL">Kalliopi Benetos</a> is licensed under a <br /><a rel="license" href="http://creativecommons.org/licenses/by-nc-nd/3.0/deed.en_US">Creative Commons Attribution-NonCommercial-NoDerivs 3.0 Unported License</a>.</p></fieldset></body></html>';}


//-----------NAME ------------------------------------------------
// name - displays content and editing form fields
function nameForm($dom){
        $heading = $dom->getElementsByTagName('heading');

foreach ($heading as $head){
        $author=$head->getElementsByTagName('author')->item(0);
        $first_name = $author->getElementsByTagName('first_name')->item(0);
        $last_name = $author->getElementsByTagName('last_name')->item(0);

        $authorLabel = $author->getAttribute('label');
        $firstNameLabel = $first_name->getAttribute('label');
        $lastNameLabel = $last_name->getAttribute('label');

        echo '<a name="heading"></a><fieldset>
                <legend>'.$authorLabel.'</legend>

                <form name ="edit_name" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <table width="100%"  border="0" cellpadding="3" cellspacing="0">
                <tr><td align="center" valign="top" width="5%">
                <input type="image" value="submit" class="buttonText" name="saveName" src="../graphics/save.png " title="save changes to '.$authorLabel.'" align="middle" /><br/>
                <input type="image" value="submit" class="buttonText" name="cancelName" src="../graphics/cancel.png " title="cancel changes to '.$authorLabel.'" align="middle" />
                </td><td width="95%" valign="top">
                <label class="instruct">'.$firstNameLabel.'</label>
                <input type="text" name="first_name" id="firstnameText" class="textOff" onfocus="changeTextClass(\'firstnameText\')" onblur="changeTextClass(\'firstnameText\')"   value="', stripslashes($first_name->nodeValue) ,'" />
                <label class="instruct">'.$lastNameLabel.'</label>
                <input type="text" name="last_name" id="lastnameText" class="textOff" onfocus="changeTextClass(\'lastnameText\')" onblur="changeTextClass(\'lastnameText\')" value="', $last_name->nodeValue ,'" />';
        echo'</td></tr></table></form></fieldset>';
        }
}

// name - displays content and give edit option
function nameView($dom){
        $heading = $dom->getElementsByTagName('heading');
foreach ($heading as $head){
        $author=$head->getElementsByTagName('author')->item(0);
        $first_name = $author->getElementsByTagName('first_name')->item(0);
        $last_name = $author->getElementsByTagName('last_name')->item(0);

        $authorLabel = $author->getAttribute('label');
        $firstNameLabel = $first_name->getAttribute('label');
        $lastNameLabel = $last_name->getAttribute('label');

        echo '<a name="heading"></a><fieldset>
                <legend>'.$authorLabel.'</legend>

                <table width="100%"  border="0" cellpadding="3" cellspacing="0">
                <tr><td align="center" valign="top" width="5%">
                <form name ="edit_name" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />';

        echo '<input type="image" value="submit" class="buttonText" name="editName" src="../graphics/edit.png" title="edit '.$authorLabel.'" align="middle" /></form>';
        echo '</td><td width="95%" valign="top"><label class="instruct">'.$firstNameLabel.': </label>',$first_name->nodeValue,' &#160;&#160;&#160;
                <label class="instruct">'.$lastNameLabel.': </label>', $last_name->nodeValue ,'';
        echo'</td></tr></table></fieldset>';

        }
}

// saves changes to NAME and goes to display view (nameView)
function saveName($dom) {
 if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
 //       $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $heading = $dom->getElementsByTagName('heading')->item(0);
        $author=$heading->getElementsByTagName('author')->item(0);
        $authorLabel = $heading->getAttribute('label');

        //REPLACE first_name ----------------------
        $firstName=$dom->getElementsByTagName('first_name')->item(0);
        if (isset($_POST['first_name'])){
                $insertFirstName=$_POST['first_name'];
                $firstName->nodeValue = $insertFirstName;
      //          $insertFirstNameLabel = "first name:";
      //          $firstName->setAttribute('label',''. $insertFirstNameLabel .'');
        }else{ //do nothing
        };

        //REPLACE last_name ----------------------
        $lastName=$dom->getElementsByTagName('last_name')->item(0);
        if (isset($_POST['last_name'])){
                $insertLastName=$_POST['last_name'];
                $lastName->nodeValue = $insertLastName;
       //         $insertLastNameLabel = "last name:";
          //      $lastName->setAttribute('label',''. $insertLastNameLabel .'');
        }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        nameView($dom,$_POST);
        }

// end NAME ---------------------

//------TITLE--------------------------------------------------------

// titleDisplay - displays Title info and view to edit option
function titleDisplay($dom){
                $heading = $dom->getElementsByTagName('heading');

        foreach ($heading as $head){
                $headLabel = $head->getAttribute('label');
                $essay_title = $head->getElementsByTagName('essay_title')->item(0);
                $title = $essay_title->getElementsByTagName('title')->item(0);
                $subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
                $date = $essay_title->getElementsByTagName('date')->item(0);
                $noteHead = $head->getElementsByTagName('notepad')->item(0);
                // labels and help
                $essay_titleLabel = $essay_title->getAttribute('label');
                $titleLabel = $title->getAttribute('label');
                $titleHelp = $title->getAttribute('help');
                $subtitleLabel = $subtitle->getAttribute('label');
                $subtitleHelp = $subtitle->getAttribute('help');
                $dateLabel = $date->getAttribute('label');


        echo '<fieldset><legend>'.$essay_titleLabel.'</legend>
        <form name="edit_title" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
        <table width="100%"  border="0" cellpadding="3" cellspacing="0">
        <tr>
        <td valign="top" align="center" width="5%">';
        printf ('<a id="title-edit" class="genTip" href="javascript: toggleForm(\'titleForm\')"><img id="edittitleForm" src="../graphics/edit.png" alt="view" border="0" title="edit '.$essay_titleLabel.'" class="buttonText" style="display:block;"/></a>
                <input id="canceltitleForm" type="image" value="submit" class="buttonText" name="cancelTitle" src="../graphics/cancel.png" title="cancel changes to '.$essay_titleLabel.'" align="middle" style="display:none;"/>');

        echo '</td>
        <td valign="top" width="30%">';
                echo '<label class="instruct">'.$titleLabel.': </label><span class="txt">'.$title->nodeValue.' </span>
                <br/><label class="instruct optional">'.$subtitleLabel.': </label>', $subtitle->nodeValue ,'<br/>
                <label class="instruct">'.$dateLabel.': </label>', $date->nodeValue ,'
        </td>

        <td valign="top" width="65%">';
/*		------title notepad view------
        <fieldset class="notepad">
        <legend>notepad</legend>
                <!-- <label for="head_notes" class="boxInst">notes for heading section</label><br/>-->
                ',$noteHead->nodeValue ,'
        </fieldset>
*/
                echo '<span id="titleForm" class="boxForm" style="display:none">';
                echo '<!-- repeated <p> Current file loaded: '.$GLOBALS["file"].'</p>
                <form name ="edit_title" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" /> -->

        <table width="100%"  border="0" cellpadding="3" cellspacing="0"><tr>';
        echo '<td valign="top" ><fieldset class="On">
                <label for="title" class="boxInst">';
        printf('<a class="tip title-help" href="javascript: toggleLabel(\'title\')"><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$titleLabel.'</a>');
        echo '</label><br/>
                <span id="title" class="boxPop" style="display:none">'.$titleHelp.'';
        printf('<a class="title-help" href="javascript: toggleLabel(\'title\')"><img src="../graphics/close.png " class="buttonHelp" alt="close" title="close" style="float:right" /></a>');
        echo '</span>
                <textarea class="textOff" id="titletext" name="title" cols="50" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'titletext\')" onblur="changeTextClass(\'titletext\')"  onkeyup="textAreaAdjust(this)">', $title->nodeValue ,'</textarea>
                <br/>
                <label for="subtitle" class="boxInst">';
        printf('<a class="tip subtitle-help optional" href="javascript: toggleLabel(\'subtitle\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$subtitleLabel.'</a>');
        echo '</label><br/>
                <span id="subtitle" class="boxPop" style="display:none">'.$subtitleHelp.'';
        printf('<a class="subtitle-help" href="javascript: toggleLabel(\'subtitle\')"><img src="../graphics/close.png " class="buttonHelp" alt="close" title="close" style="float:right" /></a>');
        echo '</span><textarea class="textOff" id="subtitletext" name="subtitle" rows="2" onfocus="textAreaAdjust(this);changeTextClass(\'subtitletext\')" onblur="changeTextClass(\'subtitletext\')"  onkeyup="textAreaAdjust(this)">', $subtitle->nodeValue ,'</textarea><br/>
                <label for="date" class="instruct">'.$dateLabel.'</label>
                <br/> <input id="dateSet" type="text" name="date" value="', $date->nodeValue ,'" size="25" />

                </fieldset></td>';
/*
                <td valign="top" width="10%"><fieldset class="notepad">
                <legend>notepad</legend>
                <!-- <label for="head_notes" class="boxInst">notes for heading section</label><br/>-->
                <textarea name="noteHead" cols="28" rows="12" class="notes">',$noteHead->nodeValue ,'</textarea>
                </fieldset></td>
                */
        echo'	</tr><tr><td align="center">';
        echo '<input type="image" value="submit" class="buttonText" name="saveTitle" src="../graphics/save.png " title="save changes to '.$essay_titleLabel.'" align="middle" />&#160;&#160;
                <input type="image" value="submit" class="buttonText" name="cancelTitle" src="../graphics/cancel.png " title="cancel changes to '.$essay_titleLabel.'" align="middle" />';
                echo'</td></tr></table>
                <!-- repeated form-->
                </span>';
        echo '</td>
        </tr>
        </table>
        </form></fieldset>';

                }
}


// saves changes to TITLE and goes to display view (titleDisplay)
function saveTitle($dom) {
 if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
 //        $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $heading = $dom->getElementsByTagName('heading')->item(0);
  //      $essay_title=$heading->getElementsByTagName('essay_title')->item(0);

   //      $title = $essay_title->getElementsByTagName('title')->item(0);
  //       $subtitle = $essay_title->getElementsByTagName('subtitle')->item(0);
 //        $date = $essay_title->getElementsByTagName('date')->item(0);

//         $essay_titleLabel = $essay_title->getAttribute('label');
    //     $titleLabel = $title->getAttribute('label');
  //       $subtitleLabel = $subtitle->getAttribute('label');
    //     $dateLabel = $date->getAttribute('label');
  //       $titleHelp = $title->getAttribute('help');
 //        $subtitleHelp = $subtitle->getAttribute('help');

        //REPLACE title ----------------------
        $title=$dom->getElementsByTagName('title')->item(0);
        if (isset($_POST['title'])){
                $insertTitle=$_POST['title'];
                $title->nodeValue = $insertTitle;
      //          $insertTitleLabel = "title";
       //         $title->setAttribute('label',''. $insertTitleLabel .'');
        }else{ //do nothing
        };

        //REPLACE subtitle ----------------------
        $subtitle=$dom->getElementsByTagName('subtitle')->item(0);
        if (isset($_POST['subtitle'])){
                $insertSubtitle=$_POST['subtitle'];
                $subtitle->nodeValue = $insertSubtitle;
          //      $insertSubtitleLabel = "subtitle";
            //    $subtitle->setAttribute('label',''. $insertSubtitleLabel .'');
        }else{ //do nothing
        };

        //REPLACE date ----------------------
        $date=$dom->getElementsByTagName('date')->item(0);
        if (isset($_POST['date'])){
                $insertDate=$_POST['date'];
                $date->nodeValue = $insertDate;
           //     $insertDateLabel = "date (Month dd, yyyy)";
           //     $date->setAttribute('label',''. $insertDateLabel .'');
        }else{ //do nothing
        };

        //REPLACE notepad-----------------------------
        $noteHead = $heading->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteHead'])){
                $insertNoteHead=$_POST['noteHead'];
                $content = nl2br($insertNoteHead);
                $insertNoteHead = trim($content);
                $noteHead->nodeValue = $insertNoteHead;
                $insertNoteId = "noteHead";
                $noteHead->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        titleDisplay($dom,$_POST);
        }



//-----------INTRODUCTION ------------------------------------------------

// displays svg graphic form, edit and view with text help
function introView($dom){
        $introduction = $dom->getElementsByTagName('introduction');


foreach ($introduction as $intro){
        $thesis=$intro->getElementsByTagName('thesis')->item(0);
        $state_thesis = $thesis->getElementsByTagName('state_thesis')->item(0);

        $outline = $thesis->getElementsByTagName('outline')->item(0);
        $importance = $outline->getElementsByTagName('importance')->item(0);
        $conflict = $outline->getElementsByTagName('conflict')->item(0);
        $solution = $outline->getElementsByTagName('solution')->item(0);

        //svg elements
        $colorPro = "#467A4B";
   //     $colorCon = "#499BC4";
        $colorLine = "#98A48A";

        $labelThesis = $thesis->getAttribute('label');
        $labelThesisId = $thesis->getAttribute('svgLabel');
        $labelStateThesis = $state_thesis->getAttribute('label');
        $labelStateThesisId = $state_thesis->getAttribute('svgLabel');
        $labelConflict = $conflict->getAttribute('label');
        $labelConflictId = $conflict->getAttribute('svgLabel');
        $labelImp = $importance->getAttribute('label');
        $labelImpId = $importance->getAttribute('svgLabel');
        $labelSol = $solution->getAttribute('label');
        $labelSolId = $solution->getAttribute('svgLabel');
        //svg elements end
        $noteIntro = $intro->getElementsByTagName('notepad')->item(0);

        // Labels and help
        $introLabel=$intro->getAttribute('label');
        $thesisLabel = $thesis->getAttribute('label');
        $state_thesisLabel = $state_thesis->getAttribute('label');
        $state_thesisHelp = $state_thesis->getAttribute('help');

        $outlineLabel = $outline->getAttribute('label');
        $importanceLabel = $importance->getAttribute('label');
        $importanceHelp = $importance->getAttribute('help');
        $importanceConnectTitle = $importance->getAttribute('connectiveTitle');
        $importanceConnect = $importance->getAttribute('connective');
        $importanceListState= $importance->getAttribute('connectInclude');


        $conflictLabel = $conflict->getAttribute('label');
        $conflictHelp = $conflict->getAttribute('help');
        $conflictConnectTitle = $conflict->getAttribute('connectiveTitle');
        $conflictConnect = $conflict->getAttribute('connective');
        $conflictListState= $conflict->getAttribute('connectInclude');


        $solutionLabel = $solution->getAttribute('label');
        $solutionHelp = $solution->getAttribute('help');
        $solutionConnectTitle = $solution->getAttribute('connectiveTitle');
        $solutionConnect = $solution->getAttribute('connective');
        $solutionListState= $solution->getAttribute('connectInclude');

        $noteIntroLabel = $noteIntro->getAttribute('label');


// Introduction svg display start

        // SVG graph - detecting if textnodes are whitespace only
        $textThesis = $state_thesis->nodeValue;
        $textThesisNode = $dom->createTextNode("$textThesis");
        $wsThesis = $textThesisNode->isWhitespaceInElementContent();

        $textConflict = $conflict->nodeValue;
        $textConflictNode = $dom->createTextNode("$textConflict");
        $wsConflict = $textConflictNode->isWhitespaceInElementContent();

        $textSol = $solution->nodeValue;
        $textSolNode = $dom->createTextNode("$textSol");
        $wsSol = $textSolNode->isWhitespaceInElementContent();

        $textImp = $importance->nodeValue;
        $textImpNode = $dom->createTextNode("$textImp");
        $wsImp = $textImpNode->isWhitespaceInElementContent();

        $introScale=1;
        if ($wsThesis){$colorThesis='#FFFFFF';}else{$colorThesis='#467A4B';};
        if ($wsConflict){
                $colorConflict='#FFFFFF';
                }else{
                $colorConflict='#467A4B';
                $introScale=$introScale+0.5;};
        if ($wsSol){
                $colorSol='#FFFFFF';
                }else{
                $colorSol='#467A4B';
                $introScale=$introScale+0.5;};
        if ($wsImp){$colorImp='#FFFFFF';}else{$colorImp='#467A4B';};
        if (($wsThesis)||($wsImp)){$colorIntro='#FFFFFF';}else{$colorIntro='#467A4B';};
        if ((!$wsThesis)&&(!$wsImp)){$introScale=$introScale+0.5;};


// Dispay code

        echo '<fieldset>
                <legend>'.$introLabel.'</legend>
                <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
                <form name ="edit_introduction" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <table border="0" cellpadding="3" cellspacing="0" width="100%" id="introTable">
                <tr>
                <td align="center" width="5%" valign="top">';
// buttons for intro  id="intro-edit" class="genTip"
printf ('<a id="intro-edit" class="genTip" href="javascript: toggleForm(\'introForm\')"><img id="editintroForm" src="../graphics/edit.png" alt="edit introduction" border="0" title="edit '.$introLabel.'" class="buttonText" style="display:block;"/></a>
        <input id="cancelintroForm" type="image" value="submit" class="buttonText" name="cancelIntro" src="../graphics/cancel.png" title="cancel changes to '.$introLabel.'" align="middle" style="display:none;"/>');

        echo '</td>
                <td valign="top" width="20%">';
        echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='55' width='180' x='0' y='0'>";
        echo "<defs>

            <rect id='nodeEmpty' width='16' height='16' stroke-width='2' />
            <rect id='nodeEmptySm' width='10' height='10'  stroke-width='2' />

            <rect id='nodeEmpty' width='16' height='6' fill='none'  stroke-width='2' />
            <circle id='optionEmpty' r='5' stroke-width='2' />
            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,34,0' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />

            <symbol id='intro'>
                <use x='18' y='8' xlink:href='#line'  />
                <use x='68' y='0' xlink:href='#lineProAa'  />
                <use x='83' y='0' xlink:href='#lineProAb'  />
                <use x='83' y='15' xlink:href='#lineProAb'  />
            </symbol>

            </defs>";

        printf ('<use x="1" y="1" xlink:href="#intro" />
                          <use x="0" y="0" id="svg-thesis" xlink:href="#nodeEmpty"  transform="translate(1,1) scale('.$introScale.')" fill="'.$colorIntro.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelThesisId.'\')" onmouseout="toggleOut(\''.$labelThesisId.'\')"
                          onclick="toggleIcon(\'introText\')" title="'.$thesisLabel.'"><title>'.$thesisLabel.'</title></use>

                          <use x="0" y="0" id="svg-state-thesis"  xlink:href="#nodeEmpty" transform="translate(52,1)" fill="'.$colorThesis.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelStateThesisId.'\'); changeTextClass(\'thesisText\')" onmouseout="toggleOut(\''.$labelStateThesisId.'\'); changeTextClass(\'thesisText\')" title="'.$state_thesisLabel.'"><title>'.$state_thesisLabel.'</title></use>

                          <use x="0" y="0" id="svg-importance" xlink:href="#nodeEmptySm" transform="translate(100,1)" fill="'.$colorImp.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelImpId.'\'); changeTextClass(\'importanceText\')" onmouseout="toggleOut(\''.$labelImpId.'\'); changeTextClass(\'importanceText\')" title="'.$importanceLabel.'"><title>'.$importanceLabel.'</title></use>

                          <use x="0" y="0" id="svg-conflict" xlink:href="#optionEmpty" transform="translate(105,21)" fill="'.$colorConflict.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConflictId.'\'); changeTextClass(\'conflictText\')" onmouseout="toggleOut(\''.$labelConflictId.'\'); changeTextClass(\'conflictText\')" title="'.$conflictLabel.'"><title>'.$conflictLabel.'</title></use>

                          <use x="0" y="0" id="svg-solution" xlink:href="#optionEmpty" transform="translate(105,36)" fill="'.$colorSol.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelSolId.'\'); changeTextClass(\'solutionText\')" onmouseout="toggleOut(\''.$labelSolId.'\'); changeTextClass(\'solutionText\')" ><title>'.$solutionLabel.'</title></use>');
        echo  " </svg>";
// SVG labels
  /*        echo "

         <img src='../graphics/transpixel.png' height='18px' style='float:right' />
                <span id='$labelThesisId' class='svgPop'>$labelThesis</span>
                <span id='$labelStateThesisId' class='svgPop' >$labelStateThesis</span>
                <span id='$labelImpId' class='svgPop' >$labelImp</span>
                <span id='$labelConflictId' class='svgPop' >$labelConflict</span>
                <span id='$labelSolId' class='svgPop'>$labelSol</span>";
*/
//Intro notepad form


        echo	'</td>';

// form for introduction
        echo '<td width="50%" valign="top"><br />';
        echo '<span id="introForm" class="boxForm" style="display:none">';
        echo '<form name="save_introduction" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
              <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
              <fieldset class="On">
              <legend><a id="intro-note-edit" class="buttonText" href="javascript: toggleNote(\'introNotepad\')"><img src="../graphics/note.png" id="noteintroNotepad" alt="show notepad" border="0" title="edit note" /></a>&#160;&#160;&#160;'.$thesisLabel.'</legend>';
               printf ('');

               echo' <label for="state_thesis" class="boxInst">';
               printf ('<a id="tip intro-state-help" class="tip intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$state_thesisLabel.'</a>');
               echo '</label>';

               echo '<div id="introNotepad" class="boxNote" style="display:none">
               <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                                <fieldset class="notepad">
                                <legend>'.$noteIntroLabel.'</legend>
                                <textarea name="noteIntro" cols="20" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)">', $noteIntro->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

              echo ' <br/>
               <span id="state_thesis" class="boxPop" style="display:none">'.$state_thesisHelp.'';
               printf ('<a class="intro-state-help" href="javascript: toggleLabel(\'state_thesis\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a>');
               echo '</span>
                        <textarea id="thesisText" class="textOff" name="state_thesis" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'thesisText\')" onblur="changeTextClass(\'thesisText\')"  onkeyup="textAreaAdjust(this)">',
                        trim($state_thesis->nodeValue),' </textarea><br/>
                                <fieldset id="importanceWrap" class="On">
                                        <legend>'.$outlineLabel.'</legend>';
                        // importance
                        printf('<label for="importance" class="boxInst"><a id="intro-importance-help" class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img  src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$importanceLabel.'</a></label>');

                        echo '&#160;<a id="intro-importance-info" href="javascript:toggleInfo(\'importanceList\');"><img id="imgimportanceList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        echo'<span id="importance" class="boxPop" style="display:none">'.$importanceHelp.'';
                        printf('&#160;<a class="tip intro-importance-help" href="javascript: toggleLabel(\'importance\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                        // importance words popup
                        echo'<div id="importanceList" class="boxFloat" style="display:none"><p class="instruct">'.$importanceConnectTitle.'</p><p class="maintext">'.$importanceConnect.'</p>';

                        printf('&#160;<a class="tip intro-importance-info-close" href="javascript: toggleInfo(\'importanceList\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                        // importance text field
                        echo '<textarea id="importanceText" class="textOff" name="importance" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'importanceText\')" onblur="changeTextClass(\'importanceText\')" onkeyup="textAreaAdjust(this)">',$importance->nodeValue,'</textarea>
                        <br/>';
                        //conflict
                        printf('<label for="conflict" class="boxInst"><a id="intro-conflict-help optional" class="tip intro-conflict-help" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$conflictLabel.'</a></label>');
                        echo '&#160;<a id="intro-conflict-info" href="javascript:toggleInfo(\'conflictList\')"><img id="imgconflictList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        printf('<span id="conflict" class="boxPop" style="display:none">'.$conflictHelp.'&#160;<a class="tip intro-conflict-help" href="javascript: toggleLabel(\'conflict\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                        // conflict words popup
                        echo '<div id="conflictList" class="boxFloat" style="display:none"><p class="optional">'.$conflictConnectTitle.'</p><p class="maintext">'.$conflictConnect.'</p>';
                        printf('<a class="intro-conflict-info-close" href="javascript: toggleInfo(\'conflictList\')"><img id="imgimportanceListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right" /></a></div>');
                        //conflict text field
                        echo '<textarea id="conflictText" class="textOff" name="conflict" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'conflictText\')" onblur="changeTextClass(\'conflictText\')" onkeyup="textAreaAdjust(this)">',$conflict->nodeValue,'</textarea><br/>';
                        // solution
                        printf('<label for="solution" class="boxInst">&#160;<a id="intro-solution-help optional" class="tip intro-solution-help" href="javascript: toggleLabel(\'solution\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$solutionLabel.'</a></label>');
                        echo '&#160;<a id="intro-solution-info" href="javascript:toggleInfo(\'solutionList\')"><img id="imgsolutionList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
                        printf('<span id="solution" class="boxPop" style="display:none">'.$solutionHelp.'&#160;<a class="tip intro-solution-help" href="javascript: toggleLabel(\'solution\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                        // solution words popup
                        echo '<div id="solutionList" class="boxFloat" style="display:none"><p class="optional">'.$solutionConnectTitle.'</p><p class="maintext">'.$solutionConnect.'</p>';
                        printf('&#160;<a class="intro-solution-info-close" href="javascript: toggleInfo(\'solutionList\')"><img id="imgsolutionListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right" /></a></div>');
                        // solution text field
                        echo '<textarea id="solutionText" class="textOff" name="solution" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'solutionText\')" onblur="changeTextClass(\'solutionText\')" onkeyup="textAreaAdjust(this)">',$solution->nodeValue,'</textarea>
                        </fieldset>';
                        echo '</fieldset>';
                       // save buttons
                        echo '<div align="center"><input id="intro_save" type="image" value="submit" class="buttonText" name="saveIntro" src="../graphics/save.png" title="save changes to '.$introLabel.'" align="middle" />&#160;&#160;
                                <input id="intro-cancel" type="image" value="submit" class="buttonText" name="cancelIntro" src="../graphics/cancel.png" title="cancel changes to '.$introLabel.'" align="middle" /></div>';
                       // end intro form
                        echo '</form></span>';
        echo '</td>';

        echo	'<td valign="top"  width="25%" align="right">';

// text view for intro
        printf ('&#160;&#160;&#160;<a id="intro-preview" class="genTip" href="javascript: toggleIcon(\'introText\')"><img id="imgintroText" src="../graphics/tview.png" alt="view" border="0" title="view text for this element" class="buttonText" /> '.$introLabel.' text</a>');
        echo '<span id="introText" class="boxForm" style="display:none">';
        echo '<table border="0" cellpadding="3" cellspacing="0" width="100%">
                                <tr>
                                <td valign="top">
                                <fieldset class="content">
                                        <legend>'.$thesisLabel.'</legend>
                                        <label for="state_thesis" class="instruct">'.$state_thesisLabel.'</label>
                                        <br/>', stripslashes($state_thesis->nodeValue),'<br/>
                                        <fieldset class="content">
                                                <legend>'.$outlineLabel.'</legend>
                                                <label for="importance" class="instruct">'.$importanceLabel.'</label><br/>', stripslashes($importance->nodeValue) ,'<br/>
                                                <label for="conflict" class="optional">'.$conflictLabel.'</label><br/>', stripslashes($conflict->nodeValue) ,'<br/>
                                                <label for="solution" class="optional">'.$solutionLabel.'</label><br/>', stripslashes($solution->nodeValue) ,'<br/>
                                        </fieldset>
                                        <fieldset class="notepad">
                                <legend>'.$noteIntroLabel.'</legend>
                                <br/>', $noteIntro->nodeValue ,' ', stripslashes($solution->nodeValue) ,'<br/>
                                </fieldset>
                                </fieldset>
                                </td>
                        </tr>
                        </table></span>';
        echo	'</td>
                </tr>
                </table></form></fieldset>';
                }
}


// saves changes to INTRODUCTION and goes to display view (introView)
function saveIntro($dom) {
    if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
  //      $file=$_POST['currentFile'];
        $root = $dom->getElementsByTagName('root');
        $message = str_replace('&#13;', '', $_SESSION["message"]);

        // retrieve the parent elements
        $introduction = $dom->getElementsByTagName('introduction')->item(0);
        $thesis=$introduction->getElementsByTagName('thesis')->item(0);

        //REPLACE state_thesis----------------------
        $stateThesis = $dom->getElementsByTagName('state_thesis')->item(0);
        if (isset($_POST['state_thesis'])) {
                $insertStateThesis=$_POST['state_thesis'];
                $content = nl2br($insertStateThesis);
                $insertStateThesis = trim($content);
                $stateThesis->nodeValue = $insertStateThesis;
 //              $insertStateThesisLabel='state your main point';
 //              $stateThesis->setAttribute('label',''. $insertStateThesisLabel .'');
                }else {	// do nothing
                };

        //REPLACE importance--------------------
        $importance = $dom->getElementsByTagName('importance')->item(0);
        if (isset($_POST['importance'])) {
                $insertImportance=$_POST['importance'];
                $content = nl2br($insertImportance);
                $insertImportance = trim($content);
                $importance->nodeValue = $insertImportance;
                }else {	// do nothing
                };

        //REPLACE conflict--------------------------
        $conflict = $dom->getElementsByTagName('conflict')->item(0);
        if (isset($_POST['conflict'])) {
                $insertConflict=$_POST['conflict'];
                $content = nl2br($insertConflict);
                $insertConflict = trim($content);
                $conflict->nodeValue = $insertConflict;
                }else {	// do nothing
                };

        //REPLACE solution--------------------------
        $solution = $dom->getElementsByTagName('solution')->item(0);
        if (isset($_POST['solution'])) {
                $insertSolution=$_POST['solution'];
                $content = nl2br($insertSolution);
                $insertSolution = trim($content);
                $solution->nodeValue = $insertSolution;
                }else {	// do nothing
                };

        //REPLACE notepad-----------------------------
        $noteIntro = $introduction->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteIntro'])){
                $insertNoteIntro=$_POST['noteIntro'];
                $content = nl2br($insertNoteIntro);
                $insertNoteIntro = trim($content);
                $noteIntro->nodeValue = $insertNoteIntro;
                $insertNoteId = "noteIntro";
                $noteIntro->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        introView($dom,$_POST);
        }



//-----------ARGUMENT ------------------------------------------------


// ARGVIEW - displays SVG graphic tree of arguments, edit (*Form), text view (*Display) options

function argView($dom){
            $arguments = $dom->getElementsByTagName('arguments')->item(0);
            $argument = $dom->getElementsByTagName('argument');
            $argumentsLabel = $dom->getElementsByTagName('arguments')->item(0)->getAttribute('label');
            $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');

        $noId= 0;
        $argsScore=1;
        $argsFill=0; //was =1

echo '<fieldset id="arguments"><legend>'.$argumentsLabel.'</legend>';
          argButtons($dom);	// argument menu links

foreach ($argument as $arg){
        // creating a unique Id for each argument that is in order
        $noId++;
        $insertId='_'.$noId.'';
        $arg->setAttribute('id',''. $insertId .'');
        $argHelp=$arg->getAttribute('help');
        // getting argument by id
        $id=$arg->getAttribute('id');

        $argLength=$dom->getElementsByTagName('argument')->length;
        //simple_argument contents
        $simpleArg=$arg->getElementsByTagName('simple_argument')->item(0);

        $rating=$simpleArg->getAttribute('rating');
       // for checkbox and svg as grey
        $simple_status=$simpleArg->getAttribute('status'); // for checkbox and svg as grey
        $simple_statusInclude=$simpleArg->getAttribute('statusInclude'); // for including simple argument

        // for whitespace "empty" or "full"
        $simple_content=$simpleArg->getAttribute('content');

        $stateArg = $arg->getElementsByTagName('state_argument')->item(0);
        $stateArgWords_status=$stateArg->getAttribute('stateArgWordsStatus'); // for checkbox to display word list edit
        $support = $arg->getElementsByTagName('support')->item(0);
                $type=$support->getAttribute('type');
                $source=$support->getAttribute('source');
        $relate = $arg->getElementsByTagName('relate')->item(0);

        //counterargument contents
        $counterArg=$arg->getElementsByTagName('counterargument')->item(0);
        $counter_status = $counterArg->getAttribute('status');
        $counter_statusInclude=$counterArg->getAttribute('statusInclude'); // for including counter argument

        $stateCounterArg=$arg->getElementsByTagName('state_counterargument')->item(0);
                $attackType=$stateCounterArg->getAttribute('attack_type');
                $counter_rating = $stateCounterArg->getAttribute('rating');
                $counter_content=$simpleArg->getAttribute('content'); // for whitespace "empty" or "full"


        $comeback=$arg->getElementsByTagName('comeback')->item(0);
        $strategyType=$comeback->getAttribute('strategy');
        $comeback_rating = $comeback->getAttribute('rating');
        $responseType = $comeback->getAttribute('response');

 // optional concluding statement
    $concluClaim=$arg->getElementsByTagName('concluClaim')->item(0);
    $concluClaimType=$concluClaim->getAttribute('revise');
    $concluClaim_rating = $concluClaim->getAttribute('rating');

        $args =  $arg->parentNode;

        $noteArg = $arg->getElementsByTagName('notepad')->item(0);
                $insertNoteId='noteArg_'.$noId.'';
                $noteArg->setAttribute('id',''.$insertNoteId.'');
        // labels and help
        $argumentLabel=$arg->getAttribute('label');
        $simpleArgLabel=$simpleArg->getAttribute('label');
        $simpleArgHelp=$simpleArg->getAttribute('help');
        $simpleArgRatingLabel =$simpleArg->getAttribute('ratingLabel');

        $stateArgLabel = $stateArg->getAttribute('label');
        $stateArgHelp = $stateArg->getAttribute('help');
        $argTypeLabel = $stateArg->getAttribute('argTypeLabel');
        $argType=$stateArg->getAttribute('type');
        $argTypeHelp= $stateArg->getAttribute('typeHelp');
        $stateArgConnectTitle = $stateArg->getAttribute('connectiveTitle');
        $stateArgConnect = $stateArg->getAttribute('connective');

        $supportLabel = $support->getAttribute('label');
        $supportHelp= $support->getAttribute('help');
        $supportConnectTitle= $support->getAttribute('connectiveTitle');
        $supportConnect= $support->getAttribute('connective');

        $sourceLabel= $support->getAttribute('sourceLabel');
        $sourceHelp= $support->getAttribute('sourceHelp');
        $source= $support->getAttribute('source');
        $relateLabel = $relate->getAttribute('label');
        $relateHelp = $relate->getAttribute('help');
        $relateConnectTitle = $relate->getAttribute('connectiveTitle');
        $relateConnect = $relate->getAttribute('connective');

        $counterArgLabel = $counterArg->getAttribute('label');
        $counterArgHelp = $counterArg->getAttribute('help');

        $stateCounterArgLabel = $stateCounterArg->getAttribute('label');
        $stateCounterArgHelp = $stateCounterArg->getAttribute('help');
        $stateCounterArgConnectTitle = $stateCounterArg->getAttribute('connectiveTitle');
        $stateCounterArgConnect = $stateCounterArg->getAttribute('connective');

        $counterArgRatingLabel =$stateCounterArg->getAttribute('ratingLabel');

        $attackType = $stateCounterArg->getAttribute('attack_type');
        $attackTypeLabel = $stateCounterArg->getAttribute('attackTypeLabel');
        $attackTypeHelp = $stateCounterArg->getAttribute('attackHelp');

        $comebackLabel = $comeback->getAttribute('label');
        $comebackHelp = $comeback->getAttribute('help');
        $comebackConnectTitle = $comeback->getAttribute('connectiveTitle');
        $comebackConnect = $comeback->getAttribute('connective');
        $responseHelp = $comeback->getAttribute('responseHelp');
        $responseTypeLabel = $comeback->getAttribute('responseTypeLabel');
        $responseType = $comeback->getAttribute('response');
        $strategyTypeLabel = $comeback->getAttribute('strategyTypeLabel');
        $strategyType = $comeback->getAttribute('strategy');
        $strategyHelp = $comeback->getAttribute('strategyHelp');
                            $comebackRatingLabel =$comeback->getAttribute('ratingLabel');

        $concluClaimLabel = $concluClaim->getAttribute('label');
        $concluClaimHelp = $concluClaim->getAttribute('help');
        $concluClaimConnectTitle = $concluClaim->getAttribute('connectiveTitle');
        $concluClaimConnect = $concluClaim->getAttribute('connective');
        $reviseTypeLabel = $concluClaim->getAttribute('reviseTypeLabel');
        $reviseType = $concluClaim->getAttribute('revise');
        $reviseHelp = $concluClaim->getAttribute('reviseHelp');
                         $concluRatingLabel =$concluClaim->getAttribute('ratingLabel');


        $argNoteLegend = $noteArg->getAttribute('legend');
        $argNoteLabel = $noteArg->getAttribute('label');
        // SVG labels
        $labelArgs = $args->getAttribute('label');
        $labelArgsId = $args->nodeName;
        $labelArgsIdSvg = ''.$labelArgsId.''.$noId.'';

        $labelSimpleArg=$simpleArg->getAttribute('label');
        $labelSimpleArgId = $simpleArg->nodeName;
        $labelSimpleArgIdSvg = ''.$labelSimpleArgId.''.$noId.'';

        $labelConArg=$counterArg->getAttribute('label');
        $labelConArgId = $counterArg->nodeName;
        $labelConArgIdSvg = ''.$labelConArgId.''.$noId.'';

        $labelStateArg=$stateArg->getAttribute('label');
        $labelStateArgId = $stateArg->nodeName;
        $labelStateArgIdSvg = ''.$labelStateArgId.''.$noId.'';

        $labelSupport=$support->getAttribute('label');
        $labelSupportId = $support->nodeName;
        $labelSupportIdSvg = ''.$labelSupportId.''.$noId.'';

        $labelRelate=$relate->getAttribute('label');
        $labelRelateId = $relate->nodeName;
        $labelRelateIdSvg = ''.$labelRelateId.''.$noId.'';

        $labelCounter=$stateCounterArg->getAttribute('label');
        $labelCounterId = $stateCounterArg->nodeName;
        $labelCounterIdSvg = ''.$labelCounterId.''.$noId.'';

        $labelComeback=$comeback->getAttribute('label');
        $labelComebackId = $comeback->nodeName;
        $labelComebackIdSvg = ''.$labelComebackId.''.$noId.'';

        $labelConcluClaim=$concluClaim->getAttribute('label');
        $labelConcluClaimId = $concluClaim->nodeName;
        $labelConcluClaimIdSvg = ''.$labelConcluClaimId.''.$noId.'';

        $multi=$id[1]; // = substr($id,-1)
        $argNo=$multi;
        $ypos = ($argNo * 64);
        $xpos = 0;

        $colorArgs = "#467A4B";
        $colorArgsStroke = "#467A4B";

        $colorProAll= "#467A4B";
        $colorProAllStroke= "#467A4B";
        $colorPro = "#467A4B";
        $colorProStroke = "#467A4B";
        $colorSupport = "#467A4B";
        $colorSupportStroke = "#467A4B";
        $colorRelate = "#467A4B";
        $colorRelateStroke = "#467A4B";

        $colorCounterAll= "#499BC4";
        $colorCounterAllStroke= "#499BC4";
        $colorCounter = "#499BC4";
        $colorCounterStroke = "#499BC4";
        $colorComeback='#499BC4';
        $colorComebackStroke='#499BC4';
        $colorConcluClaim='#499BC4';
        $colorConcluClaimStroke='#499BC4';
        $colorLine = "#98A48A";

        $argDis = 'arg';

// detecting if textnodes are whitespace only
        $textStateArg = $stateArg->nodeValue;
        $textStateArgNode = $dom->createTextNode("$textStateArg");
        $wsStateArg = $textStateArgNode->isWhitespaceInElementContent();

        $textSupport = $support->nodeValue;
        $textSupportNode = $dom->createTextNode("$textSupport");
        $wsSupport = $textSupportNode->isWhitespaceInElementContent();

        $textRelate = $relate->nodeValue;
        $textRelateNode = $dom->createTextNode("$textRelate");
        $wsRelate = $textRelateNode->isWhitespaceInElementContent();

        $textCounterArg = $stateCounterArg->nodeValue;
        $textCounterArgNode = $dom->createTextNode("$textCounterArg");
        $wsCounterArg = $textCounterArgNode->isWhitespaceInElementContent();

        $textComeback = $comeback->nodeValue;
        $textComebackNode = $dom->createTextNode("$textComeback");
        $wsComeback = $textComebackNode->isWhitespaceInElementContent();

        $textConcluClaim = $concluClaim->nodeValue;
        $textConcluClaimNode = $dom->createTextNode("$textConcluClaim");
        $wsConcluClaim = $textConcluClaimNode->isWhitespaceInElementContent();


// assigning COLORS - fill for filled nodes - detects whitespace  ALSO form status On/Off 467A4B=green, 499BC4=blue, cccccc=grey

              // for state argument node
              if (($wsStateArg)&&($simple_status=="Off")){$colorPro='#ffffff';$colorProStroke='#cccccc';
                } else if (($wsStateArg)&&($simple_status=="On")){$colorPro='#ffffff';$colorProStroke='#467A4B';
                } else if ((!$wsStateArg)&&($simple_status=="Off")) {$colorPro='#cccccc';$colorProStroke='#cccccc';
                } else {$colorPro='#467A4B';$colorProStroke='#467A4B';
              };
              // for support node
              if (($wsSupport)&&($simple_status=="Off")){$colorSupport='#ffffff';$colorSupportStroke='#cccccc';
                } else if (($wsSupport)&&($simple_status=="On")){$colorSupport='#ffffff';$colorSupportStroke='#467A4B';
                } else if ((!$wsSupport)&&($simple_status=="Off")) {$colorSupport='#cccccc';$colorSupportStroke='#cccccc';
                } else {$colorSupport='#467A4B';$colorSupportStroke='#467A4B';
              };

              // for relate node
              if (($wsRelate)&&($simple_status=="Off")){$colorRelate='#ffffff';$colorRelateStroke='#cccccc';
                } else if (($wsRelate)&&($simple_status=="On")){$colorRelate='#ffffff';$colorRelateStroke='#467A4B';
                } else if ((!$wsRelate)&&($simple_status=="Off")) {$colorRelate='#cccccc';$colorRelateStroke='#cccccc';
                } else {$colorRelate='#467A4B';$colorRelateStroke='#467A4B';
              };

              // for counterArg nodes
              if (($wsCounterArg)&&($counter_status=="Off")){$colorCounter='#ffffff';$colorCounterStroke='#cccccc';
                } else if (($wsCounterArg)&&($counter_status=="On")) {$colorCounter='#ffffff';$colorCounterStroke='#499BC4';
                } else if ((!$wsCounterArg)&&($counter_status=="Off")) {$colorCounter='#cccccc';$colorCounterStroke='#cccccc';
                } else {$colorCounter='#499BC4';$colorCounterStroke='#499BC4';
                };

             // for comeback
             if (($wsComeback)&&($counter_status=="Off")){$colorComeback='#ffffff';$colorComebackStroke='#cccccc';
                } else if (($wsComeback)&&($counter_status=="On")) {$colorComeback='#ffffff';$colorComebackStroke='#467A4B';
                } else if ((!$wsComeback)&&($counter_status=="Off")) {$colorComeback='#cccccc';$colorComebackStroke='#cccccc';
                } else {$colorComeback='#467A4B';$colorComebackStroke='#467A4B';
                };

             // for concluClaim
             if (($wsConcluClaim)&&($counter_status=="Off")){$colorConcluClaim='#ffffff';$colorConcluClaimStroke='#cccccc';
                } else if (($wsConcluClaim)&&($counter_status=="On")) {$colorConcluClaim='#ffffff';$colorConcluClaimStroke='#467A4B';
                } else if ((!$wsConcluClaim)&&($counter_status=="Off")) {$colorConcluClaim='#cccccc';$colorConcluClaimStroke='#cccccc';
                } else {$colorConcluClaim='#467A4B';$colorConcluClaimStroke='#467A4B';
                };


   // for group nodes
   if (($wsStateArg)||($wsRelate)){$colorProAll='#FFFFFF';}else{$colorProAll=$colorPro;};
   if ($simple_status=="Off"){$colorProAllStroke='#cccccc'; }else {$colorProAllStroke='#467A4B';};

   if (($wsCounterArg)||($wsComeback)){$colorCounterAll='#FFFFFF';}else{$colorCounterAll=$colorCounter;};
   if ($counter_status=="Off"){$colorCounterAllStroke='#cccccc'; } else {$colorCounterAllStroke='#499BC4';};

        // argument model different for first argument
        if ($id=='_1') {$argDis = 'arg1';}	else{$argDis = 'arg';};

        // retrieving and summing up the rating and option scores
        if ($rating=='strong') {$argScore=1.5;} else if ($rating=='acceptable'){$argScore=1;} else if ($rating=='weak'){$argScore=0.5;}else{$argScore=0;};
        if ($wsStateArg){$argScore=0;};
        if ($argScore==0){
                $argScore++;
//		$supportScore=NULL;
//		$relateScore=NULL;
        }
        if ($wsSupport){$argScale=$argScore;}else{$argScale=$argScore+0.5;};
        if ($wsRelate){$argScale=$argScore;}else{$argScale=$argScore+0.5;};


        //$supportScale=1; $relateScale=$relateScore
        if ($counter_rating=='strong') {$counterScore= 3;} else if ($counter_rating=='acceptable'){$counterScore= 2;}else{$counterScore= 1;};
        if ($wsCounterArg){$counterScore=0;};

        if ($comeback_rating=='strong') {$comebackScore= 3;} else if ($comeback_rating=='acceptable'){$comebackScore= 2;}else if ($comeback_rating=='weak'){$comebackScore= 1;}else{$comebackScore=0;};
        if ($wsComeback){$comebackScore=0;};

        if ($concluClaim_rating=='strong') {$conClaimScore= 3;} else if ($concluClaim_rating=='acceptable'){$conClaimScore= 2;}else if ($concluClaim_rating=='weak'){$conClaimScore= 1;}else{$conClaimScore=0;};
        if ($wsConcluClaim){$conClaimScore=0;};


        // using scores to manipulate the scaling of graphic nodes
        $ratingScale=($argScore + $counterScore + $comebackScore+$conClaimScore)/2 ;  // 1.5 >scale >1


        $argScale=$argScale;
        //   $argScore=$argScore/2;
        $supportScale=$argScore; // to adapt Arg node
        $relateScale=$argScore/2; // to adapt Arg node

        $counterScale=$counterScore/2;
        $comebackScale=$comebackScore/2;
        $conClaimScale=$conClaimScore/2;
        $conScale=($comebackScale + $counterScale+$conClaimScale/2)/2; //counterArgNode



        // to make nodes show up small and empty if value is zero
        if ($argScale<=0){
        $argScale=1;};
        if ($supportScale<=0){
        $supportScale=1;};
        if ($relateScale<=0){
        $relateScale=1;};

        if ($conScale<=0){$conScale=1;};
        if ($counterScale<=0){
        $counterScale=1;};
        if ($comebackScale<=0){
        $comebackScale=1;};
        if ($conClaimScale<=0){
        $conClaimScale=1;};

        // argument section score

        $argsScore++;
        $argsScale=$argsScore; // only taking the first arg into account

        // fill of args section

        $argsFill++;
        if (($wsStateArg)&&($wsCounterArg)){$argsFill=$argsFill-1;};



        // argsFill - filling general argument section box
        // if ($argsFill>=3){$colorArgs='#467A4B';}else{$colorArgs='#FFFFFF';}; //args box stays white



// form to call up edit argument form

// TRACE scales variables
//echo '<br/>ratingScale='.$ratingScale.'<br/> argsScale='.$argScale.'<br/> argDis='.$argDis.'<br/> argsScore='.$argsScore.', <br/> argsFill='.$argsFill.'<br/>colorArgs='.$colorArgs.'';

// TRACE form status
//  echo '<br/>'.$simple_status.'<br/>'.$counter_status.'<br/>colorPro='.$colorPro.'<br/>colorProStroke='.$colorProStroke.'<br/>colorCounter='.$colorCounter.'<br/>colorCounterStroke='.$colorCounterStroke.'<br/>colorSupportStroke='.$colorSupportStroke.'';


        echo'<form action="' . $_SERVER["PHP_SELF"] . '" method ="post" name ="edit_argument'.$id.'" id="edit_argument'.$id.'" class="whichTable">
                <table width="100%" border="0" cellspacing="0" cellpadding="3" class="underln " id="argTable'.$id.'">
                 <tr>
                 <td width="5%">
                 <input type="hidden" name="no_id" value="'. $noId .'" />
                 <input type="hidden" name="argument_id" value="'. $id .'" />
                 <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                 </td>
                 <td width="20%"></td>
                 <td width="50%">
                 </td>';
// button right view
        echo '<td width="25%" align="right"><a name="arg'.$id.'"></a>';
        printf ('&#160;&#160;&#160;<a class="genTip" href="javascript: toggleIcon(\'textHelp'.$id.'\')"><img id="imgtextHelp'.$id.'" src="../graphics/tview.png" alt="view" border="0" title="view text for this element" class="buttonText"/>&#160;'.$argumentLabel.''.$id.'</a>');
        echo '</td></tr>
                <tr>';
       echo' <td align="center" width="5%" valign="top" >';
 // buttons down side
        printf ('<a class="genTip arg-help" href="javascript: toggleLabel(\'argument'.$id.'\')"><img id="imgargument'.$id.'" src="../graphics/help.png" alt="help" title="help for this element" border="0" class="buttonText" /></a>');
        echo '<br /><div id="argument'.$id.'" class="boxArg" style="display:none;text-align:left;"><span class="stick">'.$argHelp.'</span>
        <a class="genTip arg-help" id="argHelp-info" href="javascript: toggleLabel(\'argument'.$id.'\')"><img id="imgargHelp" src="../graphics/close.png"  class="buttonText" title="close" style="float:right"  border="0" align="absbottom" /></a></div>';
        echo '<a class="genTip arg-edit" href="javascript: toggleForm(\'argForm'.$id.'\')"><img id="editargForm'.$id.'" src="../graphics/edit.png" alt="edit '.$argumentLabel.''.$id.'" title="edit '.$argumentLabel.''.$id.'" border="0" class="buttonText" /></a><br/> <input id="cancelargForm'.$id.'" type="image" value="submit" class="genTip arg-cancel buttonText" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" style="display:none;"/>';

        echo '<input type="image" value="submit" name="addArg" src="../graphics/addArg.png" border="0" title="add new '.$argumentLabel.' at end" align="absmiddle" class="buttonText"  /><br/>';

        // no delete allowed if only one argument exists -> removes delete button
        if (($noId==$argLength) && ($argLength==1)){// don't allow delete
   //             echo' <a class="genTip" href="javascript: noArgs()"><img src="../graphics/delete.png" alt="delete argument" border="0" title="delete argument" /></a>';
                echo' ';
        } else {
                echo'<input type="image" value="submit" class="buttonText arg-delete1" name="deleteArg" src="../graphics/delete.png" border="0" title="delete '.$argumentLabel.'" align="absmiddle" /><br/>';
        };

        // if there are no arguments to move

        if ($noId!=$dom->getElementsByTagName('argument')->length){
        echo'<input type="image" value="submit"  name="moveArgDown" src="../graphics/moveDown.png" border="0" title="move '.$argumentLabel.' down" align="absmiddle" class="buttonText" />';}
        else { //show no button
        };

        // argsFill - filling general argument section box
           if ($argLength>=3){$colorArgs='#467A4B';}else{$colorArgs='#FFFFFF';}; //args box stays white


// END buttons
        echo '</td>';

// set class in a status related variable and adjust in css
              $statusSimpleChecked=($simple_status=="On") ? "checked='checked'" : " ";
  //            $statusSimpleInclude=($simple_statusInclude=="On") ? "checked='checked'" : " ";
              $statusCounterChecked=($counter_status=="On") ? "checked='checked'" : " ";
 //          $statusCounterInclude=($counter_statusInclude=="formOn") ? "checked='checked'" : " "; // show form
               $stateArgWordsChecked=($stateArgWords_status=="inline") ? "checked='checked'" : " ";


        echo '<td align="left" valign="top" width="20%">';

//-- SVG start
    echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='96' width='180' x='0' y='0'>";
    echo "<defs>

            <rect id='argEmpty' width='16' height='6' stroke-width='2'  />
            <rect id='conEmpty' width='16' height='6' stroke-width='2'  />
            <circle id='optionEmpty' r='5' stroke-width='2'  />

            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,40,0' />
            <polyline id='lineSm' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,16,0' />
            <polyline id='lineArgA' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,0,75' />
            <polyline id='lineArg' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,0,14,16,14' />

            <polyline id='lineCon' fill='none' stroke='$colorLine' stroke-width='2' points='0,10,16,10,16,48,32,48,32,42,48,42' />
            <polyline id='lineConA' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />
            <polyline id='lineConB' fill='none' stroke='$colorLine' stroke-width='2' points='1,4,1,20,16,20' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />
            <polyline id='lineProAc' fill='none' stroke='$colorLine' stroke-width='2' points='1,20,1,36,16,36' />

            <symbol id='args'>
                <use x='0' y='0' xlink:href='#nodeEmpty' />
            </symbol>

            <symbol id='argPro'>
                <use x='69' y='8' xlink:href='#lineSm'  />
                <use x='85' y='0' xlink:href='#lineProAa'  />
                <use x='100' y='0' xlink:href='#lineProAb'  />
                <use x='100' y='15' xlink:href='#lineProAb'  />
            </symbol>

            <symbol id='argCon'>
                <use x='69' y='8' xlink:href='#lineCon'  />
                <use x='100' y='44' xlink:href='#lineConA'  />
                <use x='100' y='60' xlink:href='#lineConB'  />
            </symbol>

            <symbol id='arg'>
                <use x='65' y='14' xlink:href='#lineArgA'  />
                <use x='65' y='0' xlink:href='#lineArg'  />
                <use x='30' y='0' xlink:href='#argPro'  />
                <use x='30' y='0' xlink:href='#argCon'  />
            </symbol>

            <symbol id='arg1'>
                <use x='65' y='14' xlink:href='#lineArgA'  />
                <use x='44' y='14' xlink:href='#line'  />
                <!-- head args -->
                <use x='0' y='0' xlink:href='#args' transform='translate(1,6) scale(".$argsScale.")' fill='".$colorArgs."' stroke='#467A4B' />
                <use x='30' y='0' xlink:href='#argPro'  />
                <use x='30' y='0' xlink:href='#argCon'  />
            </symbol>

            </defs>";

// loop to display the nodes generated by svg
        printf ('<use x="0" y="0" xlink:href="#'.$argDis.'" onmouseover="toggleIn(\''.$labelArgsIdSvg.'\')" onmouseout="toggleOut(\''.$labelArgsIdSvg.'\')" title="'.$argumentLabel.'"><title>'.$argumentLabel.'</title></use>

                <use x="0" y="0" xlink:href="#argEmpty"  id="stateArgNode" transform="translate(146,2) scale('.$argScore.')" fill="'.$colorPro.'"  stroke="'.$colorProStroke.'" onmouseover="toggleIn(\''.$labelStateArgIdSvg.'\'); changeTextClass(\'stateArgText'.$id.'\')" onmouseout="toggleOut(\''.$labelStateArgIdSvg.'\'); changeTextClass(\'stateArgText'.$id.'\')"  title="'.$stateArgLabel.'"><title>'.$stateArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#optionEmpty"  id="supportNode" transform="translate(150,20)" fill="'.$colorSupport.'"   stroke="'.$colorSupportStroke.'" onmouseover="toggleIn(\''.$labelSupportIdSvg.'\'); changeTextClass(\'supportText'.$id.'\')" onmouseout="toggleOut(\''.$labelSupportIdSvg.'\'); changeTextClass(\'supportText'.$id.'\')" title="'.$supportLabel.'"><title>'.$supportLabel.'</title></use>

                <use x="0" y="0" xlink:href="#argEmpty" id="relateNode" transform="translate(146,32)" fill="'.$colorRelate.'"  stroke="'.$colorProStroke.'" onmouseover="toggleIn(\''.$labelRelateIdSvg.'\'); changeTextClass(\'relateText'.$id.'\')" onmouseout="toggleOut(\''.$labelRelateIdSvg.'\'); changeTextClass(\'relateText'.$id.'\')" title="'.$relateLabel.'"><title>'.$relateLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty"  id="counterArgNode" transform="translate(146,48) scale('.$counterScale.')" fill="'.$colorCounter.'"  stroke="'.$colorCounterStroke.'" onmouseover="toggleIn(\''.$labelCounterIdSvg.'\'); changeTextClass(\'counterText'.$id.'\')" onmouseout="toggleOut(\''.$labelCounterIdSvg.'\'); changeTextClass(\'counterText'.$id.'\')" title="'.$stateCounterArgLabel.'"><title>'.$stateCounterArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty" id="comebackNode" transform="translate(146,62) scale('.$comebackScale.')" fill="'.$colorComeback.'"  stroke="'.$colorComebackStroke.'" onmouseover="toggleIn(\''.$labelComebackIdSvg.'\'); changeTextClass(\'comebackText'.$id.'\')" onmouseout="toggleOut(\''.$labelComebackIdSvg.'\'); changeTextClass(\'comebackText'.$id.'\')" title="'.$comebackLabel.'"><title>'.$comebackLabel.'</title></use>

                <use x="0" y="0" xlink:href="#argEmpty"  id="simpleArgNode" transform="translate(82,6) scale('.$argScale.')" fill="'.$colorProAll.'" stroke="'.$colorProAllStroke.'" onmouseover="toggleIn(\''.$labelSimpleArgIdSvg.'\')" onmouseout="toggleOut(\''.$labelSimpleArgIdSvg.'\')" title="'.$simpleArgLabel.'"><title>'.$simpleArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#conEmpty"  id="counterNode" transform="translate(82,15) scale('.$conScale.')" fill="'.$colorCounterAll.'" stroke="'.$colorCounterAllStroke.'" onmouseover="toggleIn(\''.$labelConArgIdSvg.'\')" onmouseout="toggleOut(\''.$labelConArgIdSvg.'\')" title="'.$counterArgLabel.'"><title>'.$counterArgLabel.'</title></use>

                <use x="0" y="0" xlink:href="#optionEmpty"  id="concluClaimNode" transform="translate(150,80) scale('.$conClaimScale.')" fill="'.$colorConcluClaim.'"   stroke="'.$colorConcluClaimStroke.'" onmouseover="toggleIn(\''.$labelConcluClaimIdSvg.'\'); changeTextClass(\'concluClaimText'.$id.'\')" onmouseout="toggleOut(\''.$labelConcluClaimIdSvg.'\'); changeTextClass(\'concluClaimText'.$id.'\')" title="'.$concluClaimLabel.'"><title>'.$concluClaimLabel.'</title></use>
                ');
        echo "</svg>";

// svg labels mouseovers
 /*       echo "<br /><img src='../graphics/transpixel.png' height='18px' style='float:right' />
        <span id='$labelArgsId' class='svgPop'>$labelArgs</span>
                <span id='$labelSimpleArgIdSvg' class='svgPop'>$labelSimpleArg</span>
                <span id='$labelConArgIdSvg' class='svgPop'>$labelConArg</span>
                <span id='$labelStateArgIdSvg' class='svgPop'>$labelStateArg</span>
                <span id='$labelSupportIdSvg' class='svgPop'>$labelSupport</span>
                <span id='$labelRelateIdSvg' class='svgPop'>$labelRelate</span>
                <span id='$labelCounterIdSvg' class='svgPop'>$labelCounter</span>
                <span id='$labelComebackIdSvg' class='svgPop'>$labelComeback</span>
                <span id='$labelConcluClaimIdSvg' class='svgPop'>$labelConcluClaim</span>";
   */
// -- SVG end
//--	tracing status


        echo	'</td>';
        echo '<td width="50%" valign="top" >';

// START form edit display
        echo '<span id="argForm'.$id.'" class="boxForm" style="display:none">';
                echo '
                <form action="' . $_SERVER["PHP_SELF"] . '" method ="post" name ="save_argument" id="save_argument">
                <table width="100%" border="0" cellspacing="0" cellpadding="3">
                <input type="hidden" name="no_id" value="'. $noId .'" />
                <input type="hidden" name="argument_id" value="'. $id .'" />
                <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <tr><td>';
             // buttons argument check
               echo '<table width="100%">
                <tr><td class="button"><a class="buttonText arg-note-edit" href="javascript: toggleNote(\'argNotepad'.$id.'\')"><img src="../graphics/note.png" alt="edit note" border="0" title="edit note'.$id.'" id="noteargNotepad'.$id.'" /></a>
                &#160;&#160;<label for="id" >'.$argumentLabel.'</label>'.$id.'
                </td>
                <td align="right" >
                <input type="image" value="submit" class="buttonText arg-save" name="saveArg" src="../graphics/save.png" border="0" title="save changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;
                <input type="image" value="submit" class="buttonText arg-cancel" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" />  </td></tr></table>';

        echo '</td></tr>';
        // simple argument row
        echo '
                        <tr><td valign="top">';



             echo  '<fieldset class="'.$simple_status.'"  id="simpleArgument'.$id.'"><legend>';
             echo '<div id="argNotepad'. $id .'" class="boxNote" style="display:none">
                                <fieldset class="notepad">
                                <legend>'.$argNoteLegend.''.$id.'</legend>
                                <textarea name="noteArg" cols="22" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)">', $noteArg->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

                printf ('<a class="buttonText" title="show/hide '.$simpleArgLabel.' form" href="javascript: toggleFormPart(\'simpleArgumentForm'.$id.'\')">'.$simpleArgLabel.'</a> <input type="checkbox" ' . $statusSimpleChecked . ' name="sArg" onclick="changeClass(\'simpleArgument'.$id.'\')" />');
                echo '<span class="inst">&#160;'.$simpleArgHelp.'</span></legend>';

                // state argument
                echo'<div id="simpleArgumentForm'.$id.'" style="display:none">';
                 printf('<label for="state_argument" class="boxInst"><a class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"><img id="imgstate_argument'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element"/> '.$stateArgLabel.'</a></label>');
                 // wordList icon show/hide
                 echo '<span id="stateArgWords'.$id.'" style="display:'.$stateArgWords_status.'">';
                 printf('<a class="tip arg-s-state-info" href="javascript: toggleInfo(\'state_argumentList'.$id.'\')"><img id="imgstate_argumentList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /> </a>');
                echo'<span id="state_argument'.$id.'" class="boxPop" style="display:none">'.$stateArgHelp.'';
                printf('&#160;<a class="tip arg-s-state-help" href="javascript: toggleLabel(\'state_argument'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"   /></a></span>');
                echo '</span>';
                // stateArg words
                echo'<div draggable="true" id="state_argumentList'.$id.'" class="boxFloat" style="display:none"><p class="instruct">'.$stateArgConnectTitle.'</p><p class="maintext">'.$stateArgConnect.'</p>';
                printf('&#160;<a class="tip arg-s-state-info-close" href="javascript: toggleInfo(\'state_argumentList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></div>');
                // stateArg text field
                echo '<textarea id="stateArgText'.$id.'" class="textOff" name="state_argument" rows="3" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'stateArgText'.$id.'\')" onkeyup="textAreaAdjust(this)" onblur="changeTextClass(\'stateArgText'.$id.'\')">', $stateArg->nodeValue ,'</textarea><br/>';

                // support
                printf('<label for="support" class="boxInst"><a class="tip arg-s-support-help optional" href="javascript: toggleLabel(\'support'.$id.'\')"><img id="imgsupport'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$supportLabel.'</a></label>');
                printf('<a class="tip arg-s-support-info" href="javascript: toggleInfo(\'supportList'.$id.'\')"><img id="imgsupportList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText"  title="connecting words"/> </a>');
                echo'<span id="support'.$id.'" class="boxPop" style="display:none">'.$supportHelp.'';
                printf('&#160;<a class="tip arg-s-support-help" href="javascript: toggleLabel(\'support'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                 // support words
                echo'<div draggable="true" id="supportList'.$id.'" class="boxFloat" style="display:none"><p class="instruct">'.$supportConnectTitle.'</p><p class="maintext">'.$supportConnect.'</p>';
                printf('&#160;<a class="arg-s-support-info-close" href="javascript: toggleInfo(\'supportList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                // support text field
                echo '<textarea id="supportText'.$id.'" class="textOff" name="support" rows="3" onfocus="enableSimpleArg(this.form);textAreaAdjust(this); changeTextClass(\'supportText'.$id.'\')" onblur="changeTextClass(\'supportText'.$id.'\')" onkeyup="textAreaAdjust(this)">' ,$support->nodeValue,'</textarea><br/>';

                // argument type
                printf ('<label for="type" class="boxInst"><a class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"> <img id="imgtype'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element" /> '.$argTypeLabel.'</a>');
                echo '</label><span id="type'.$id.'" class="boxPop" style="display:none">'.$argTypeHelp.'<a class="tip arg-s-type-help" href="javascript: toggleLabel(\'type'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a>';
                echo '</span><select id="type" name="type" onfocus="enableSimpleArg(this.form)" >
                                                <option selected="selected">', $argType ,'</option>
                                                <option disabled="disabled">select one</option>
                                                <option>fact</option>
                                                <option>statistics and signs</option>
                                                <option>an example</option>
                                                <option>an analogy</option>
                                                <option>cause and effect</option>
                                                <option>authority</option>
                                                <option>common values</option>
                                                <option>a need to take action</option>
                                        </select><br/>';
                // source
// source non-print optional                 printf ('<label for="source" class="boxOptional"><a class="tip arg-s-source-help optional" href="javascript: toggleLabel(\'source'.$id.'\')"> <img id="imgsource'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> source</a></label>');

                printf ('<label for="source" class="boxInst"><a class="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"> <img id="imgsource'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$sourceLabel.'</a></label>');
                echo '<br/><span id="source'.$id.'" class="boxPop" style="display:none">'.$sourceHelp.'<a class="tip arg-s-source-help" href="javascript: toggleLabel(\'source'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>';
                // source text
                echo ' <textarea id="sourceText'.$id.'" name="source" rows="1" class="textOff" onfocus="enableSimpleArg(this.form);textAreaAdjust(this);changeTextClass(\'sourceText'.$id.'\')" onblur="changeTextClass(\'sourceText'.$id.'\')" onkeyup="textAreaAdjust(this)" >', $source ,'</textarea><br/>';

                // relate
                printf('<label for="relate" class="boxInst"><a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"><img id="imgrelate'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp" title="help for this element"  /> '.$relateLabel.'</a></label>');
                printf('<a class="tip arg-s-relate-info" href="javascript: toggleInfo(\'relateList'.$id.'\')"><img id="imgrelateList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /> </a>');
                echo'<span id="relate'.$id.'" class="boxPop" style="display:none">'.$relateHelp.'';
                printf('&#160;<a class="tip arg-s-relate-help" href="javascript: toggleLabel(\'relate'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                // relate words
                echo'<div draggable="true" id="relateList'.$id.'" class="boxFloat" style="display:none"><p class="instruct">'.$relateConnectTitle.'</p><p class="maintext">'.$relateConnect.'</p>';
                printf('&#160;<a class="arg-s-relate-info-close" href="javascript: toggleInfo(\'relateList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></div>');
                // relate text field
                echo '<textarea id="relateText'.$id.'" class="textOff" name="relate" rows="3" onfocus="enableSimpleArg(this.form);textAreaAdjust(this);changeTextClass(\'relateText'.$id.'\')" onblur="changeTextClass(\'relateText'.$id.'\')" onkeyup="textAreaAdjust(this)">', $relate->nodeValue ,'</textarea><br />';

                // rating
                echo '<label for="rating" class="instruct">'.$simpleArgRatingLabel.'</label>
                        <select name="rating"  onfocus="enableSimpleArg(this.form)">
                                <option selected="selected">'.$rating.'</option>
                                <option disabled="disabled">none</option>
                                <option>strong</option>
                                <option>acceptable</option>
                                <option>weak</option>
                        </select>';
                echo '</div></fieldset></td></tr>';
// end simple argument element

// ---------- counterargument ----------------------
                echo '<tr><td><fieldset class="'.$counter_status.'" id="counterArgument'.$id.'">
                <legend><a class="buttonText" title="show/hide '.$counterArgLabel.' form" href="javascript: toggleFormPart(\'counterArgumentForm'.$id.'\')">'.$counterArgLabel.'</a>';
                 $statusCounterChecked=($counter_status=="On") ? "checked='checked'" : " ";
                printf ('<input type="checkbox" ' . $statusCounterChecked . ' name="cArg" onclick="changeClass(\'counterArgument'.$id.'\')" />');
                echo '<span class="inst">&#160;'.$counterArgHelp.'</span></legend>';

                // state counterargument
                echo '<div id="counterArgumentForm'.$id.'" style="display:none"><div class="boxBg">';
                printf('<label for="state_counterargument" class="boxInst"><a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"><img id="imgstate_counterargument'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element" /> '.$stateCounterArgLabel.'</a></label>');
                printf('<a class="tip arg-c-state-info" href="javascript: toggleInfo(\'counterList'.$id.'\')"><img id="imgcounterList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words"/> </a>');
                echo'<span id="state_counterargument'.$id.'" class="boxPop" style="display:none">'.$stateCounterArgHelp.'';
                printf('&#160;<a class="tip arg-c-state-help" href="javascript: toggleLabel(\'state_counterargument'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                // state counterargument words
                echo'<div draggable="true" id="counterList'.$id.'" class="boxFloat" style="display:none"><p class="instruct">'.$stateCounterArgConnectTitle.'</p><p class="maintext">'.$stateCounterArgConnect.'</p>';
                printf('&#160;<a class="arg-c-state-info-close" href="javascript: toggleInfo(\'counterList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></div>');
                //state counterargument textfield
                echo '<textarea  id="counterText'.$id.'" class="textOff" name="state_counterargument" rows="3" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'counterText'.$id.'\')" onblur="changeTextClass(\'counterText'.$id.'\')" onkeyup="textAreaAdjust(this)">', $stateCounterArg->nodeValue , '</textarea><br/>';

                // attack c-arg type
                printf ('<label for="attack_type" class="boxInst"><a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"> <img id="imgattack_type'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element"/> '.$attackTypeLabel.'</a></label>');

                echo '<span id="attack_type'.$id.'" class="boxPop" style="display:none">'.$attackTypeHelp.'<a class="tip arg-c-type-help" href="javascript: toggleLabel(\'attack_type'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>';
                echo '<select name="attack_type" onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">', $attackType ,'</option>
                                        <option disabled="disabled">select one</option>
                                        <option>being not logical</option>
                                        <option>being untrue</option>
                                        <option>assuming that</option>
                                        <option>perhaps meaning that</option>
                                        <option>being opposed by other evidence</option>
                                        <option>alternate interpretations</option>
                                </select>
                                <p>
                        <label for="counter_rating" class="instruct">'.$counterArgRatingLabel.'</label>
                        <select name="counter_rating"  onfocus="enableCounterArg(this.form)">
                                <option selected="selected">'.$counter_rating.'</option>
                                <option disabled="disabled">none</option>
                                <option>strong</option>
                                <option>acceptable</option>
                                <option>weak</option>
                        </select></p>';
                echo '</div>';

               // comeback
                echo '<div class="boxBg">';
                printf('<p><label for="comeback" class="boxInst"><a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"><img id="imgcomeback'.$id.'" src="../graphics/help.png" alt="help" border="0"  class="buttonHelp" title="help for this element"/> '.$comebackLabel.'</a></label>');
                printf('<a class="tip arg-c-comeback-info" href="javascript: toggleInfo(\'comebackList'.$id.'\')"><img id="imgcomebackList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words"/> </a>');
                echo'<span id="comeback'.$id.'" class="boxPop" style="display:none">'.$comebackHelp.'';
                printf('&#160;<a class="tip arg-c-comeback-help" href="javascript: toggleLabel(\'comeback'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                // comeback words
                echo'<div draggable="true" id="comebackList'.$id.'" class="boxFloat" style="display:none"><p class="instruct">'.$comebackConnectTitle.'</p><p class="maintext">'.$comebackConnect.'</p>';
                printf('&#160;<a class="arg-c-comeback-info-close" href="javascript: toggleInfo(\'comebackList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                // comeback text field
                echo '<textarea id="comebackText'.$id.'" class="textOff" name="comeback" rows="3" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'comebackText'.$id.'\')" onblur="changeTextClass(\'comebackText'.$id.'\')" onkeyup="textAreaAdjust(this)">', $comeback->nodeValue ,'</textarea></p>';

                // response
                printf ('<label for="response" class="boxInst"><a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"> <img id="imgresponse'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$responseTypeLabel.' </a></label>');
                echo  '<span id="response'.$id.'" class="boxPop" style="display:none">'.$responseHelp.'<a class="tip arg-c-response-help" href="javascript: toggleLabel(\'response'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>';

                echo '<br/>
                        <span class="instruct">This response reveals</span>
                        <select name="response" onfocus="enableCounterArg(this.form)">
                                <option selected="selected">', $responseType ,'</option>
                                <option disabled="disabled">select one</option>
                                <option>opposing or alternate facts or evidence</option>
                                <option>other statistics, signs</option>
                                <option>a counter-example</option>
                                <option>an exception</option>
                                <option>an analogy</option>
                                <option>faulty logic</option>
                                <option>false data</option>
                                <option>assumptions made</option>
                                <option>alternate interpretations</option>
                        </select> <br/> ';


                // strategy
                printf ('<br/><label for="strategy" class="boxInst"><a class="tip arg-c-strategy-help" href="javascript: toggleLabel(\'strategy'.$id.'\')"> <img id="imgstrategy'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element" /> '.$strategyTypeLabel.'</a>: </label>
                    <span id="strategy'.$id.'" class="boxPop" style="display:none">'.$strategyHelp.'<a class="tip arg-c-strategy-help" href="javascript: toggleLabel(\'strategy'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');

                echo '<br/>
                        <span class="instruct">This '.$comebackLabel.'</span>
                        <select name="strategy" onfocus="enableCounterArg(this.form)">
                                <option selected="selected">', $strategyType ,'</option>
                                <option disabled="disabled">select one</option>
                                <option>refutes</option>
                                <option>acknowledges in part</option>
                                <option>revises claim</option>
                                <option>concedes to</option>
                        </select>';
                echo '<p>
                                <label for="comeback_rating" class="instruct">'.$comebackRatingLabel.'</label>
                                <select name="comeback_rating"  onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">'.$comeback_rating.'</option>
                                        <option disabled="disabled">none</option>
                                        <option>strong</option>
                                        <option>acceptable</option>
                                        <option>weak</option>
                                </select></p>';
                echo '</div>';

                // concluding statement
                echo '<div class="boxBg">';
                printf('<label for="concluClaim" class="boxInst"><a class="tip arg-c-concluClaim-help optional" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"><img id="imgconcluClaim'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$concluClaimLabel.'</a></label>');
                printf('<a class="tip arg-c-concluClaim-info" href="javascript: toggleInfo(\'concluClaimList'.$id.'\')"><img id="imgconcluClaimList'.$id.'" src="../graphics/info.png" alt="help" border="0" class="buttonText" title="connecting words" /> </a>');
                echo'<span id="concluClaim'.$id.'" class="boxPop" style="display:none">'.$concluClaimHelp.' ';
                printf('&#160;<a class="tip arg-c-concluClaim-help" href="javascript: toggleLabel(\'concluClaim'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
                // concluClaim words
                echo'<div draggable="true" id="concluClaimList'.$id.'" class="boxFloat" style="display:none"><p class="optional">'.$concluClaimConnectTitle.'</p><p class="maintext">'.$concluClaimConnect.'</p>';
                printf('&#160;<a class="arg-c-concluClaim-info-close" href="javascript: toggleInfo(\'concluClaimList'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></div>');
                // concluClaim text field
                echo '<textarea id="concluClaimText'.$id.'" class="textOff" name="concluClaim" rows="3" onfocus="enableCounterArg(this.form);textAreaAdjust(this);changeTextClass(\'concluClaimText'.$id.'\')" onblur="changeTextClass(\'concluClaimText'.$id.'\')" onkeyup="textAreaAdjust(this)">', $concluClaim->nodeValue ,'</textarea><br/>';

                // concluClaim Type
                printf ('<label for="revise" class="boxInst"><a class="tip arg-c-revise-help" href="javascript: toggleLabel(\'revise'.$id.'\')"> <img id="imgrevise'.$id.'" src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$reviseTypeLabel.' </a></label>
                <span id="revise'.$id.'" class="boxPop" style="display:none">'.$reviseHelp.'<a class="tip arg-c-revise-help" href="javascript: toggleLabel(\'revise'.$id.'\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
                echo '<br/>
                        <span class="instruct">Basis for '.$concluClaimLabel.'</span>
                        <select id="type" name="concluClaimType" onfocus="enableCounterArg(this.form)" >
                                                <option selected="selected">', $concluClaimType ,'</option>
                                                <option disabled="disabled">select one</option>
                                                <option>fact</option>
                                                <option>statistics and signs</option>
                                                <option>an example</option>
                                                <option>an analogy</option>
                                                <option>cause and effect</option>
                                                <option>common values</option>
                                                <option>a need to take action</option>
                                        </select>


                        ';
                echo '<p>
                                <label for="concluClaim_rating" class="instruct">'.$concluRatingLabel.'</label>
                                <select name="concluClaim_rating"  onfocus="enableCounterArg(this.form)">
                                        <option selected="selected">'.$concluClaim_rating.'</option>
                                        <option disabled="disabled">none</option>
                                        <option>strong</option>
                                        <option>acceptable</option>
                                        <option>weak</option>
                                </select></p>';
                echo '</div>';
                echo '</div></fieldset></td></tr><tr><td colspan="2" align="center">';

                // argument form buttons
                echo '<input type="image" value="submit" class="buttonText arg-save" name="saveArg" src="../graphics/save.png" border="0" title="save changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;
                                <input type="image" value="submit" class="buttonText arg-cancel" name="cancelArg" src="../graphics/cancel.png" border="0" title="cancel changes to '.$argumentLabel.''.$id.'" align="absmiddle" />&#160;&#160;';

        echo '</td></tr></table></form>';
        echo '</span></td>';

// END form display

        echo	'<td valign="top" width="25%">';

// START text Display
        echo '<span id="textHelp'.$id.'" class="boxPop" style="display:none">';
        echo'<table width="100%" border="0" cellspacing="0" cellpadding="3">
                <tr valign="top">
               <td align="left" valign="top" class="'.$simple_status.'Print">';

        echo '<legend class="instruct">'.$simpleArgLabel.'</legend>
        <label for="state_argument'.$id.'" class="instruct">'.$stateArgLabel.'</label>
        &#160;', $stateArg->nodeValue ,' &#160;
        <label for="support'.$id.'" class="optional">'.$supportLabel.'</label>
        &#160;' , $support->nodeValue,'&#160;';
     // printable source
        echo'<label for="source'.$id.'" class="optional">'.$sourceLabel.'</label>
        &#160;' , $support->getAttribute('source');'&#160;';
        echo '<label for="relate'.$id.'" class="instruct">'.$relateLabel.'</label>
        &#160;', $relate->nodeValue ,'&#160;<br />
        </td></tr>

        <tr><td class="'.$counter_status.'Print">
        <legend class="instruct">'.$counterArgLabel.'</legend>
        <label for="state_counterargument'.$id.'" class="instruct">'.$stateCounterArgLabel.'</label>
                &#160;', $stateCounterArg->nodeValue , '&#160;
                <label for="comeback'.$id.'" class="instruct">'.$comebackLabel.'</label>
                &#160;', $comeback->nodeValue ,'<br/>
                <label for="concluClaim'.$id.'" class="optional">'.$concluClaimLabel.'</label>
                &#160;', $concluClaim->nodeValue ,'<br/>';

// END text Display

// notepad	 display
        echo '<fieldset class="notepad">
                <legend>'.$argNoteLabel.''.$id.'</legend>', $noteArg->nodeValue ,'<br />
                </fieldset></td></tr></table>';
        echo '</span>';

        echo '</td></tr></table></form>';
        }
        echo'</fieldset>';

}
// END argView

// saves changes to ARGUMENT and goes to display view (argView)
function saveArg($dom,$file) {
        if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);


        //REPLACE state_argument----------------------
        //retrieved parent	$simpleArg
        $simpleArg = $arg->getElementsByTagName('simple_argument')->item(0);
        $stateArg = $simpleArg->getElementsByTagName('state_argument')->item(0);
        $argType=$stateArg->getAttribute('type');

        if (isset($_POST['state_argument'])) {
                $insertStateArg=$_POST['state_argument'];
                $stateArg->nodeValue = $insertStateArg;
                $insertRating=$_POST['rating'];
                $simpleArg->setAttribute('rating',''. $insertRating .'');
                $insertType = $_POST['type'];
                $stateArg->setAttribute('type',''. $insertType .'');
                $insertStatus=$_POST['simple_status'];
                $simpleArg->setAttribute('status',''. $insertStatus .'');
        }else {	// nothing to do, we just leave it
        };

        // find checked status "on" or "off"

        if (isset($_POST['sArg'])&&('checked=="checked"')) {
                                $simpleArg->setAttribute('status','On');
                                }  else {
                                $simpleArg->setAttribute('status','Off');
                                }



        //REPLACE support and its attributes--------------------
        // parent element retrieved above $simpleArg
        //retrieve the first element with name support to be replaced
        $support = $simpleArg->getElementsByTagName('support')->item(0);
        $source=$support->getAttribute('source');
        if (isset($_POST['support'])){
                $insertSupport=$_POST['support'];
                $support->nodeValue = $insertSupport;
                $insertSource = $_POST['source'];
                $support->setAttribute('source',''. $insertSource .'');
        }else{  //do nothing
        };

        //REPLACE relate  --------------------------
        // retrieved parent element arg
        //retrieve the first element with name state_argument to be replaced
        $relate=$simpleArg->getElementsByTagName('relate')->item(0);
        if (isset($_POST['relate'])){
                $insertRelate=$_POST['relate'];
                $relate->nodeValue = $insertRelate;
                }else{ //do nothing
        };

        //REPLACE state_counterargument and its attribute --------------------------
        // retrieved parent element arg
        $counterArg=$arg->getElementsByTagName('counterargument')->item(0);
        //retrieve the first element with name state_argument to be replaced
        $stateCounterArg = $counterArg->getElementsByTagName('state_counterargument')->item(0);
        if (isset($_POST['state_counterargument'])){
                $insertStateCounterArg=$_POST['state_counterargument'];
                $stateCounterArg->nodeValue = $insertStateCounterArg;
                $insertAttackType = $_POST['attack_type'];
                $stateCounterArg->setAttribute('attack_type',''. $insertAttackType .'');
                $insertCounterRating = $_POST['counter_rating'];
                $stateCounterArg->setAttribute('rating',''. $insertCounterRating .'');
                $counterStatus = $_POST['counter_status'];
                $counterArg->setAttribute('status',''. $counterStatus .'');
                $insertStatusInclude=$_POST['counter_statusInclude'];

        }else{ //do nothing
        };

          if (isset($_POST['cArg'])&&('checked=="checked"')) {
                                $counterArg->setAttribute('status','On');
                                }  else {
                                $counterArg->setAttribute('status','Off');
                                }

        //REPLACE comeback and its attributes --------------------------
        // retrieved parent element counter_argument
        //retrieve the first element with name comeback to be replaced
        $comeback = $counterArg->getElementsByTagName('comeback')->item(0);
        if (isset($_POST['comeback'])){
                $insertComeback=$_POST['comeback'];
                $comeback->nodeValue = $insertComeback;
                $insertStrategy = $_POST['strategy'];
                $comeback->setAttribute('strategy',''. $insertStrategy .'');
                $insertResponse = $_POST['response'];
                $comeback->setAttribute('response',''. $insertResponse .'');
                $comebackRating = $_POST['comeback_rating'];
                $comeback->setAttribute('rating',''. $comebackRating .'');
        }else{ //do nothing
        };

         //REPLACE concluding claim and its attributes --------------------------
        // retrieved parent element counter_argument
        //retrieve the first element with name concluClaim to be replaced
        $concluClaim = $counterArg->getElementsByTagName('concluClaim')->item(0);
        if (isset($_POST['concluClaim'])){
                $insertConcluClaim=$_POST['concluClaim'];
                $concluClaim->nodeValue = $insertConcluClaim;
                $insertRevise= $_POST['concluClaimType'];
                $concluClaim->setAttribute('revise',''. $insertRevise .'');
                $concluClaimRating = $_POST['concluClaim_rating'];
                $concluClaim->setAttribute('rating',''. $concluClaimRating .'');
        }else{ //do nothing
        };

        //REPLACE notepad for argument-----------------------------
        $noteArg = $arg->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteArg'])){
                $insertNoteArg=$_POST['noteArg'];
                $content = nl2br($insertNoteArg);
                $insertNoteArg = trim($content);
                $noteArg->nodeValue = $insertNoteArg;
                $insertNoteId = "noteArg$id";
                $noteArg->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        argView($dom);
        }
}


// deleteArg - ARGUMENT - delete an argument
// testidValue - deletes an ARGUMENT only if there is more than 1 -> when id is more than 1
function deleteArg($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);

if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);
                //remove argument with id retreived above
                $oldArgs = $arguments->removeChild($arg);

//	$noId= $dom->getElementsByTagName('argument')->length;

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show text view
        argView($dom);
        }
}

// moveArgDown - ARGUMENT - moves argument down one step
function moveArgDown($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);
                $arg=$dom->getElementsByTagName('argument');
if (isset($_POST['argument_id'])) {
$id  = $_POST['argument_id'];
                $noId  = $_POST['no_id'];
                $itemId = $noId-1;  //match item no. to id selection
                $itemIdNext = $itemId+1;

                $argUnder = $arg->item($itemId);
                $argAbove = $arg->item($itemIdNext);
                $parent = $arg->item(0)->parentNode;

                $parent->insertBefore($argAbove, $argUnder);

        //save the DOMDocument into the xml file
        $dom->save($file);
// 	echo "clicked: $noId, itemsent: $itemId , 	inserted before item: $itemIdNext "; // testing variables
        //show text view
        argView($dom);
        }
}
// addArg = ARGUMENT - adds argument at end and displays (argDisplay)
function addArg($dom,$file) {
                $arguments = $dom->getElementsByTagName('arguments')->item(0);
                //??
                $argument = $dom->getElementsByTagName('argument')->item(0);

        if (isset($_POST['argument_id'])) {
                $id  = $_POST['argument_id'];
                // Use XPath to get $arg = $dom->getElementById($id);
                $query = "//*[@id = '" . $id . "']";
                $XP = new DomXPath ($dom);
                $arg = $XP->query($query)->item(0);

                //adjusting the new id
                $noId= $dom->getElementsByTagName('argument')->length;
                $noId++;
                $newId='_'.$noId.'';

                // help text variables to modify for language to TRANSLATE
                $argumentLabel = $arguments->getElementsByTagName('argument')->item(0)->getAttribute('label');
                $argHelp = $arguments->getElementsByTagName('argument')->item(0)->getAttribute('help');
                /*'Below you have a choice of several argument formats.
                <br /><strong>1 - Simple argument: </strong>you may give a simple argument without considering an opposite point of view.
                <br /><strong>2 - Counterargument: </strong>you may give an opposing point of view to your main point and respond to it.
                <br /><strong>3 - Combine 1 and 2: </strong>you may combine an argument and a counterargument to build a complex argument. Give an <em>argument</em> for your point of view, a possible argument against your argument and then respond to <em>counterargument</em>
                <br />* Clicking the checkbox makes the forms active.';*/
                $simpleArgLabel =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('label');
                $simpleArgHelp =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('help');
                $simple_statusInclude==$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('statusInclude'); // only in writer version
                $simpleArgRatingLabel =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('ratingLabel');
                $simpleArgRatingLabel =$argument->getElementsByTagName('simple_argument')->item(0)->getAttribute('ratingLabel');

                $stateArgLabel=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('label');
                $stateArgHelp=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('help');
                $stateArgConnectTitle=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('connectiveTitle');
                $stateArgConnect=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('connective');
                $argType=$argument->getElementsByTagName('state_argument')->item(0)->getAttribute('type');
                $argTypeHelp= $argument->getElementsByTagName('state_argument')->item(0)->getAttribute('typeHelp');
                $argTypeLabel= $argument->getElementsByTagName('state_argument')->item(0)->getAttribute('argTypeLabel');

                $supportLabel= $argument->getElementsByTagName('support')->item(0)->getAttribute('label');
                $supportHelp= $argument->getElementsByTagName('support')->item(0)->getAttribute('help');
                $supportConnectTitle=$argument->getElementsByTagName('support')->item(0)->getAttribute('connectiveTitle');
                $supportConnect=$argument->getElementsByTagName('support')->item(0)->getAttribute('connective');

                $sourceLabel= $argument->getElementsByTagName('support')->item(0)->getAttribute('sourceLabel');
                $sourceHelp= $argument->getElementsByTagName('support')->item(0)->getAttribute('sourceHelp');
                $source=$argument->getElementsByTagName('support')->item(0)->getAttribute('source');
                $relateLabel = $argument->getElementsByTagName('relate')->item(0)->getAttribute('label');
                $relateHelp = $argument->getElementsByTagName('relate')->item(0)->getAttribute('help');
                $relateConnectTitle=$argument->getElementsByTagName('relate')->item(0)->getAttribute('connectiveTitle');
                $relateConnect=$argument->getElementsByTagName('relate')->item(0)->getAttribute('connective');

                $counterArgLabel=$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('label');
                $counterArgHelp =$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('help');
                $counter_statusInclude==$argument->getElementsByTagName('counterargument')->item(0)->getAttribute('statusInclude'); // only in writer version??

                $stateCounterArgHelp = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('help');
                $stateCounterArgLabel= $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('label');;
                $stateCounterArgConnectTitle=$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('connectiveTitle');
                $stateCounterArgConnect=$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('connective');
                $counterArgRatingLabel =$argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('ratingLabel');

                $attackType = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attack_type');
                $attackTypeLabel = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attackTypeLabel');
                $attackTypeHelp = $argument->getElementsByTagName('state_counterargument')->item(0)->getAttribute('attackHelp');

                $comebackLabel = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('label');
                $comebackHelp = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('help');
                $comebackConnectTitle=$argument->getElementsByTagName('comeback')->item(0)->getAttribute('connectiveTitle');
                $comebackConnect=$argument->getElementsByTagName('comeback')->item(0)->getAttribute('connective');
                $responseTypeLabel =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('responseTypeLabel');
                $responseHelp =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('responseHelp');
                $responseType = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('response');
                $strategyTypeLabel = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategyTypeLabel');
                $strategyType = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategy');
                $strategyHelp = $argument->getElementsByTagName('comeback')->item(0)->getAttribute('strategyHelp');
                $comebackRatingLabel =$argument->getElementsByTagName('comeback')->item(0)->getAttribute('ratingLabel');

                $concluClaimLabel=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('label');
                $concluClaimHelp=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('help');
                $concluClaimConnectTitle=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('connectiveTitle');
                $concluClaimConnect=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('connective');
                $reviseTypeLabel=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('reviseTypeLabel');
                $reviseType=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('revise');
                $reviseHelp=$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('reviseHelp');
                $concluRatingLabel =$argument->getElementsByTagName('concluClaim')->item(0)->getAttribute('ratingLabel');

 $newArg= $dom->createElement('argument');
        $newArg->setAttribute('id',''. $newId.'');
        $newArg->setAttribute('label',''.$argumentLabel.'');
        $newArg->setAttribute('help',''.$argHelp.'');

        $simpleArg = $dom->createElement('simple_argument');
        $simpleArg->setAttribute('label',''.$simpleArgLabel.'');
        $simpleArg->setAttribute('rating','none');
        $simpleArg->setAttribute('status','Off');
        $simpleArg->setAttribute('statusInclude','formOn');
        $simpleArg->setAttribute('content','Empty');
        $simpleArg->setAttribute('help',''.$simpleArgHelp.'');
        $simpleArg->setAttribute('ratingLabel',''.$simpleArgRatingLabel.'');


        $stateArg = $dom->createElement('state_argument');
        $stateArg->setAttribute('label',''.$stateArgLabel.'');
        $stateArg->setAttribute('help',''.$stateArgHelp.'');
        $stateArg->setAttribute('connectiveTitle',''.$stateArgConnectTitle.'');
        $stateArg->setAttribute('connective',''.$stateArgConnect.'');
        $stateArg->setAttribute('stateArgWordsStatus',''.$stateArgWordsStatus.'');
       //  $stateArg->setAttribute('stateArgWordsStatus','none'); if to be always off when new
        $stateArg->setAttribute('type','select one');
        $stateArg->setAttribute('typeHelp',''.$argTypeHelp.'');
        $stateArg->setAttribute('argTypeLabel',''.$argTypeLabel.'');

        $support = $dom->createElement('support');
        $support->setAttribute('label',''.$supportLabel.'');
        $support->setAttribute('source','');
        $support->setAttribute('help',''.$supportHelp.'');
        $support->setAttribute('sourceLabel',''.$sourceLabel.'');
        $support->setAttribute('sourceHelp',''.$sourceHelp.'');
        $support->setAttribute('connectiveTitle',''.$supportConnectTitle.'');
        $support->setAttribute('connective',''.$supportConnect.'');

        $relate = $dom->createElement('relate');
        $relate->setAttribute('label',''.$relateLabel.'');
        $relate->setAttribute('help',''.$relateHelp.'');
        $relate->setAttribute('connectiveTitle',''.$relateConnectTitle.'');
        $relate->setAttribute('connective',''.$relateConnect.'');

        $counterArg = $dom->createElement('counterargument');
        $counterArg->setAttribute('label',''.$counterArgLabel.'');
        $counterArg->setAttribute('help',''.$counterArgHelp.'');
        $counterArg->setAttribute('status','Off');
        $counterArg->setAttribute('statusInclude','formOn');

        $stateCounterArg = $dom->createElement('state_counterargument');
        $stateCounterArg->setAttribute('label',''.$stateCounterArgLabel.'');
        $stateCounterArg->setAttribute('help',''.$stateCounterArgHelp.'');
        $stateCounterArg->setAttribute('attack_type','select one');
        $stateCounterArg->setAttribute('attackHelp',''.$attackTypeHelp.'');
        $stateCounterArg->setAttribute('attackTypeLabel',''.$attackTypeLabel.'');
        $stateCounterArg->setAttribute('rating','none');
        $stateCounterArg->setAttribute('ratingLabel',''.$counterArgRatingLabel.'');

        $stateCounterArg->setAttribute('content','Empty');
        $stateCounterArg->setAttribute('connectiveTitle',''.$stateCounterArgConnectTitle.'');
        $stateCounterArg->setAttribute('connective',''.$stateCounterArgConnect.'');

        $comeback = $dom->createElement('comeback');
        $comeback->setAttribute('label',''.$comebackLabel.'');
        $comeback->setAttribute('help',''.$comebackHelp.'');
        $comeback->setAttribute('connectiveTitle',''.$comebackConnectTitle.'');
        $comeback->setAttribute('connective',''.$comebackConnect.'');
        $comeback->setAttribute('rating','none');
        $comeback->setAttribute('ratingLabel',''.$comebackRatingLabel.'');
                $comeback->setAttribute('strategyTypeLabel',''.$strategyTypeLabel.'');

        $comeback->setAttribute('strategy','select one');
        $comeback->setAttribute('strategyHelp',''.$strategyHelp.'');
        $comeback->setAttribute('response','select one');
        $comeback->setAttribute('responseHelp',''.$responseHelp.'');
               $comeback->setAttribute('responseTypeLabel',''.$responseTypeLabel.'');

        $concluClaim = $dom->createElement('concluClaim');
        $concluClaim->setAttribute('label',''.$concluClaimLabel.'');
        $concluClaim->setAttribute('help',''.$concluClaimHelp.'');
        $concluClaim->setAttribute('connectiveTitle',''.$concluClaimConnectTitle.'');
        $concluClaim->setAttribute('connective',''.$concluClaimConnect.'');
        $concluClaim->setAttribute('rating','none');
        $concluClaim->setAttribute('ratingLabel',''.$concluRatingLabel.'');
        $concluClaim->setAttribute('reviseTypeLabel',''.$reviseTypeLabel.'');
        $concluClaim->setAttribute('revise','select one');
        $concluClaim->setAttribute('reviseHelp',''.$reviseHelp.'');

        $notepad = $dom->createElement('notepad');
        $notepad->setAttribute('id','noteArg'.$newId.'');
        $notepad->setAttribute('legend','notepad for '.$argumentLabel.'');
        $notepad->setAttribute('label','notes for '.$concluClaimLabel.'');

        $arguments->appendChild($newArg);
                $newArg->appendChild($simpleArg);
                        $simpleArg->appendChild($stateArg);
                        $simpleArg->appendChild($support);
                        $simpleArg->appendChild($relate);
                $newArg->appendChild($counterArg);
                        $counterArg->appendChild($stateCounterArg);
                        $counterArg->appendChild($comeback);
                        $counterArg->appendChild($concluClaim);
                $newArg->appendChild($notepad);

        //save the DOMDocument into the xml file
        $dom->save($file);
        //show edit view
        argView($dom);
        }
}

// argButtons - ARGUMENT - sets the links in anchored links buttons
function argButtons($dom){
        $argument = $dom->getElementsByTagName('argument');
        $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');
        $noId= 0;
        $args =  $dom->getElementsByTagName('arguments');
        $argsFill = 0;
        $argLength=$dom->getElementsByTagName('argument')->length;

// TRACE args box related variables
//echo '<p>argsLength='.$argLength.', argsFill='.$argsFill.' </p>';     //argsFill undefined

foreach ($argument as $arg){
        $argumentLabel =$dom->getElementsByTagName('argument')->item(0)->getAttribute('label');
        $noId++;
        $argsFill ++;
        echo '<a href="#arg_'.$noId.'" class="button">&#160;'.$argumentLabel .'&#160;'.$noId.'</a>&#160;';
        }
}

//-----------end ARGUMENTs ------------------------------------------------


//-----------CONCLUSION ------------------------------------------------
// CONCLUSION - displays graphic and offers edit and view text help options
function conView($dom){

        $conclusion = $dom->getElementsByTagName('conclusion');

foreach ($conclusion as $con){
        $thesis_summary=$con->getElementsByTagName('thesis_summary')->item(0);
        $argument_summary = $con->getElementsByTagName('argument_summary')->item(0);
        $consequences = $con->getElementsByTagName('consequences')->item(0);
        $closing = $con->getElementsByTagName('closing')->item(0);
        $noteCon = $con->getElementsByTagName('notepad')->item(0);

        //labels and help
        $concluLabel = $con->getAttribute('label');
        $summaryLabel = $con->getAttribute('summaryLabel');
        $argSumLabel = $con->getAttribute('argSumLabel');
        $thesis_summaryLabel = $thesis_summary->getAttribute('label');
        $thesis_summaryHelp=$thesis_summary->getAttribute('help');
        $thesis_summaryConnectTitle=$thesis_summary->getAttribute('connectiveTitle');
        $thesis_summaryConnect=$thesis_summary->getAttribute('connective');

        $argument_summaryLabel = $argument_summary->getAttribute('label');
        $argument_summaryHelp = $argument_summary->getAttribute('help');
        $argument_summaryConnectTitle=$argument_summary->getAttribute('connectiveTitle');
        $argument_summaryConnect=$argument_summary->getAttribute('connective');

        $consqLabel = $consequences->getAttribute('label');
        $consqHelp = $consequences->getAttribute('help');
        $consqConnectTitle=$consequences->getAttribute('connectiveTitle');
        $consqConnect=$consequences->getAttribute('connective');

        $closingLabel = $closing->getAttribute('label');
        $closingHelp = $closing->getAttribute('help');
        $closingConnectTitle=$closing->getAttribute('connectiveTitle');
        $closingConnect=$closing->getAttribute('connective');

        $noteConLabel=$noteCon->getAttribute('label');

        // SVG variables for CONCLUSION -----------
        $labelConclu=$con->getAttribute('label');
   //     $labelConcluId = $con->getAttribute('label');
        $labelConcluId = $con->getAttribute('svgLabel');
        $labelThSum=$thesis_summary->getAttribute('label');
        $labelThSumHelp=$thesis_summary->getAttribute('help');
   //     $labelThSumId = $thesis_summary->getAttribute('label');
        $labelThSumId = $thesis_summary->getAttribute('svgLabel');
        $labelArgSum = $argument_summary->getAttribute('label');
        $labelArgSumHelp = $argument_summary->getAttribute('help');
  //      $labelArgSumId = $argument_summary->getAttribute('label');
        $labelArgSumId = $argument_summary->getAttribute('svgLabel');
        $labelConsq = $consequences->getAttribute('label');
  //      $labelConsqId = $consequences->getAttribute('label');
        $labelConsqId = $consequences->getAttribute('svgLabel');
        $labelClosing = $closing->getAttribute('label');
        $labelClosingHelp = $closing->getAttribute('help');
  //      $labelClosingId = $closing->getAttribute('label');
        $labelClosingId = $closing->getAttribute('svgLabel');

        $colorPro = "#467A4B";
     //   $colorCon = "#499BC4";
        $colorLine = "#98A48A";

        echo '<a name="conclusion"></a>	<fieldset>
                <legend>'.$concluLabel.'</legend>
                <form name="save_conclusion" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
                <!-- <p> Current file loaded: '.$GLOBALS["file"].'</p> -->
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />

                <table width="100%" border="0" cellspacing="0" cellpadding="3"  id="concluTable">
                <tr><td>&#160;</td><td>&#160;</td><td>&#160;</td><td align="right" width="25%">';
                printf ('<a id="conclusion-preview" class="genTip" href="javascript: toggleIcon(\'concluText\')">
                        <img id="imgconcluText" src="../graphics/tview.png" alt="view" border="0" title="view text for this element" class="buttonText"/> '.$concluLabel.' text</a>');

                echo '</td></tr><tr>
                <td align="center" width="5%" valign="top">';
   // buttons down side
        printf ('<a id="conclusion-edit" class="genTip" href="javascript: toggleForm(\'conForm\')"><img id="editconForm" src="../graphics/edit.png" alt="edit conclusion" border="0" title="edit '.$concluLabel.'" class="buttonText" /></a>
                <input id="cancelconForm" type="image" value="submit" class="buttonText" name="cancelCon" src="../graphics/cancel.png" title="cancel changes to '.$concluLabel.'" align="middle" style="display:none;" />');


        echo '</td>
                <td valign="top" width="20%">';
                echo "<svg xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink' height='68' width='180' x='0' y='0'>";

                // SVG for CONCLUSION -----------
        echo "<defs>

            <rect id='nodeEmpty' width='16' height='16' stroke-width='2' />
            <rect id='nodeEmptySm' width='10' height='10' stroke-width='2' />
            <circle id='optionEmpty' r='5'  stroke-width='2' />
            <polyline id='line' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,34,0' />
            <polyline id='lineSm' fill='none' stroke='$colorLine' stroke-width='2' points='0,0,16,0' />
            <polyline id='lineConclu' fill='none' stroke='$colorLine' stroke-width='2' points='34,8,34,38,52,38' />
            <polyline id='lineProAa' fill='none' stroke='$colorLine' stroke-width='2' points='0,8,16,8,16,4,32,4' />
            <polyline id='lineProAb' fill='none' stroke='$colorLine' stroke-width='2' points='1,6,1,20,16,20' />

            <symbol id='conclu'>
                <use x='18' y='8' xlink:href='#line'  />
                <use x='68' y='0' xlink:href='#lineProAa'  />
                <use x='83' y='0' xlink:href='#lineProAb'  />
                <use x='0' y='0' xlink:href='#lineConclu'  />
            </symbol>
          </defs>";

// detecting if textnodes are whitespace only
        $textThSum = $thesis_summary->nodeValue;
        $textThSumNode = $dom->createTextNode("$textThSum");
        $wsThSum = $textThSumNode->isWhitespaceInElementContent();

        $textArgSum = $argument_summary->nodeValue;
        $textArgSumNode = $dom->createTextNode("$textArgSum");
        $wsArgSum = $textArgSumNode->isWhitespaceInElementContent();

        $textConsq = $consequences->nodeValue;
        $textConsqNode = $dom->createTextNode("$textConsq");
        $wsConsq = $textConsqNode->isWhitespaceInElementContent();

        $textClosing = $closing->nodeValue;
        $textClosingNode = $dom->createTextNode("$textClosing");
        $wsClosing = $textClosingNode->isWhitespaceInElementContent();

 // adjusting fills
        if($wsThSum){$colorThSum='#FFFFFF';}else{$colorThSum='#467A4B';};
        if ($wsArgSum){$colorArgSum='#FFFFFF';}else{$colorArgSum='#467A4B';};
        if ($wsConsq){$colorConsq='#FFFFFF';}else{$colorConsq='#467A4B';};
        if ($wsClosing){$colorClosing='#FFFFFF';}else{$colorClosing='#467A4B';};
        // filling node if all necessary components are filled
        if (($wsThSum)||($wsClosing)){$colorConclu='#FFFFFF';}else{$colorConclu='#467A4B';}


        // scoring and scaling
        $concluScale=1;
        $wsConclu=$concluScale;
        if (!$wsConclu){$concluScale=$concluScale+0.4;};
        if (!$wsConsq){$concluScale=$concluScale+0.4;};
        if (($wsThSum)||($wsClosing)){$concluScale=1;};

        printf ('<use x="0" y="0" xlink:href="#conclu"  />
        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(1,1) scale('.$concluScale.')" fill="'.$colorConclu.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConcluId.'\')" onmouseout="toggleOut(\''.$labelConcluId.'\')" title="'.$summaryLabel.'"><title>'.$summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(52,1)" fill="'.$colorThSum.'" stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelThSumId.'\')" onmouseout="toggleOut(\''.$labelThSumId.'\')" title="'.$thesis_summaryLabel.'"><title>'.$thesis_summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#optionEmpty" transform="translate(105,6)" fill="'.$colorArgSum.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelArgSumId.'\')" onmouseout="toggleOut(\''.$labelArgSumId.'\')" title="'.$argument_summaryLabel.'"><title>'.$argument_summaryLabel.'</title></use>

        <use x="0" y="0" xlink:href="#optionEmpty" transform="translate(105,21)" fill="'.$colorConsq.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelConsqId.'\')" onmouseout="toggleOut(\''.$labelConsqId.'\')" title="'.$consqLabel.'"><title>'.$consqLabel.'</title></use>

        <use x="0" y="0" xlink:href="#nodeEmpty" transform="translate(52,32)" fill="'.$colorClosing.'"  stroke="'.$colorPro.'" onmouseover="toggleIn(\''.$labelClosingId.'\')" onmouseout="toggleOut(\''.$labelClosingId.'\')" title="'.$closingLabel.'"><title>'.$closingLabel.'</title></use>');
        echo "</svg>";

//	pop-up SVG labels
/*
echo "<img src='../graphics/transpixel.png' height='18px' style='float:right' />
<span id='$labelConcluId' class='svgPop'>$summaryLabel</span>
                  <span id='$labelThSumId' class='svgPop'>$labelThSum</span>
                  <span id='$labelArgSumId' class='svgPop'>$labelArgSum</span>
                  <span id='$labelConsqId' class='svgPop'>$labelConsq</span>
                  <span id='$labelClosingId' class='svgPop'>$labelClosing</span>";

*/
  // ----- end SVG for CONCLUSION -----------

/* notepad form*/

        echo'</td><td width="50%" valign="top">';

// ------------ conclusion form-------------------
        echo '<a name="conclusion"></a><span id="conForm" class="boxForm" style="display:none">
        <form name="edit_conclusion" method ="post" action="' . $_SERVER["PHP_SELF"] . '">
        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                <table width="100%" border="0" cellspacing="0" cellpadding="3" >
                <tr>
                <td valign="top" width="90%">';

        // thesis summary
        echo '<fieldset class="On">
        <legend>&#160;<a id="conclusion-note-edit" class="genTip" href="javascript: toggleNote(\'conNotepad\')"><img src="../graphics/note.png" id="noteconNotepad" alt="edit note" border="0" title="edit note" class="buttonText" /></a>&#160;&#160;'.$summaryLabel.'</legend>';

       echo '<div id="conNotepad" class="boxNote" style="display:none">
                        <input type="hidden" name="currentFile" value="'.$GLOBALS["file"].'" />
                                <fieldset class="notepad">
                                <legend>'.$noteConLabel.'</legend>
                                <textarea name="noteCon" cols="20" rows="15" class="notes" onfocus="textAreaAdjust(this)" onkeyup="textAreaAdjust(this)">', $noteCon->nodeValue ,' </textarea>
                                </fieldset>
                                </div>';

        printf(' <label for="thesis_summary" class="boxInst"><a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/> '.$thesis_summaryLabel.'</a></label>');
        echo '&#160;<a id="conclusion-thesis-info" href="javascript:toggleInfo(\'thesis_summaryList\')"><img id="imgthesis_summaryList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words"  border="0" align="absbottom" /></a><br/>';
        echo'<span id="thesis_summary" class="boxPop" style="display:none">'.$thesis_summaryHelp.'';
        printf('&#160;<a class="tip conclusion-thesis-help" href="javascript: toggleLabel(\'thesis_summary\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
        // thesis summary words
        echo'<div draggable="true" id="thesis_summaryList" class="boxFloat" style="display:none"><p class="instruct">'.$thesis_summaryConnectTitle.'</p><p class="maintext">'.$thesis_summaryConnect.'</p>';
        printf('&#160;<a class="conclusion-thesis-info-close" href="javascript: toggleInfo(\'thesis_summaryList\')"><img id="imgthesis_summaryListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right" /></a></div>');
        // thesis summary text field
        echo'<textarea class="textOff" id="thesis_summaryText" name="thesis_summary" rows="4" onfocus="textAreaAdjust(this);changeTextClass(\'thesis_summaryText\')" onblur="changeTextClass(\'thesis_summaryText\')"  onkeyup="textAreaAdjust(this)">', $thesis_summary->nodeValue ,'</textarea>';

        // argument summaries
        echo '<fieldset class="On">
                <legend>'.$argSumLabel.'</legend> ';
                printf('<label for="arguments_summaries" class="boxInst"><a class="tip conclusion-args-help optional" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element"/>&#160;'.$argument_summaryLabel.'</a></label>');
        echo '&#160;<a id="conclusion-args-info" href="javascript:toggleInfo(\'argument_summaryList\')"><img id="imgargument_summaryList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="arguments_summaries" class="boxPop" style="display:none">'.$argument_summaryHelp.'';
        printf('&#160;<a class="tip conclusion-args-help" href="javascript: toggleLabel(\'arguments_summaries\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
        // argument summary words
        echo'<div draggable="true" id="argument_summaryList" class="boxFloat" style="display:none"><p class="instruct">'.$argument_summaryConnectTitle.'</p><p class="maintext">'.$argument_summaryConnect.'</p>';
        printf('&#160;<a class="conclusion-args-info-close" href="javascript: toggleInfo(\'argument_summaryList\')"><img id="imgargument_summaryList" src="../graphics/close.png" class="buttonText" title="close" style="float:right" /></a></div>');
        // argument summary text field
        // argument summary text field
        echo '<textarea class="textOff" id="argument_summaryText" name="argument_summary" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'argument_summaryText\')" onblur="changeTextClass(\'argument_summaryText\')"  onkeyup="textAreaAdjust(this)">', $argument_summary->nodeValue ,'</textarea>
        <br />';

        // consequences
         printf('<label for="consequences" class="boxInst"><a class="tip conclusion-conseq-help optional" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/help.png" alt="help" border="0" class="buttonHelp"  title="help for this element" /> '.$consqLabel.'</a></label>');
        echo '&#160;<a id="conclusion-conseq-info" href="javascript:toggleInfo(\'consequencesList\')"><img id="imgconsequencesList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="consequences" class="boxPop" style="display:none">'.$consqHelp.'';
        printf('&#160;<a class="tip conclusion-conseq-help" href="javascript: toggleLabel(\'consequences\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right" /></a></span>');
        // consequences words
        echo'<div draggable="true" id="consequencesList" class="boxFloat" style="display:none"><p class="instruct">'.$consqConnectTitle.'</p><p class="maintext">'.$consqConnect.'</p>';
        printf('&#160;<a class="conclusion-conseq-info-close" href="javascript: toggleInfo(\'consequencesList\')"><img id="consequencesListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right"  /></a></div>');
        // consequences text field
        echo '<textarea class="textOff" id="consequencesText" name="consequences" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'consequencesText\')" onblur="changeTextClass(\'consequencesText\')"  onkeyup="textAreaAdjust(this)">', $consequences->nodeValue ,'</textarea>
        </fieldset>';

        // closing
        printf('<label for="closing" class="boxInst"><a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/help.png" alt="help" border="0"  class="buttonHelp"  title="help for this element"/> '.$closingLabel.'</a></label>');
        echo '&#160;<a id="conclusion-closing-info" href="javascript:toggleInfo(\'closingList\')"><img id="imgclosingList" class="buttonHelp" src="../graphics/info.png" alt="word help" title="connecting words" border="0" align="absbottom" /></a><br/>';
        echo'<span id="closing" class="boxPop" style="display:none">'.$closingHelp.'';
        printf('&#160;<a class="tip conclusion-closing-help" href="javascript: toggleLabel(\'closing\')"><img src="../graphics/close.png" class="buttonHelp" title="close" style="float:right"  /></a></span>');
        // closing words
        echo'<div draggable="true" id="closingList" class="boxFloat" style="display:none"><p class="instruct">'.$closingConnectTitle.'</p><p class="maintext">'.$closingConnect.'</p>';
        printf('&#160;<a class="tip conclusion-closing-info-close" href="javascript: toggleInfo(\'closingList\')"><img id="imgclosingListClose" src="../graphics/close.png" class="buttonText" title="close" style="float:right" /></a></div>');
        // closing text field
        echo '<textarea class="textOff" id="closingText" name="closing" rows="3" onfocus="textAreaAdjust(this);changeTextClass(\'closingText\')" onblur="changeTextClass(\'closingText\')"  onkeyup="textAreaAdjust(this)">', $closing->nodeValue ,'</textarea>
        </fieldset></td></tr>';

// conForm buttons
        echo'<tr><td align="center">
                <input type="image" value="submit" name="saveCon" class="buttonText" src="../graphics/save.png" title="save changes to '.$concluLabel.'" align="middle" />&#160;&#160;&#160;
                <input id="conclusion-cancel" type="image" value="submit" class="buttonText" name="cancelCon" src="../graphics/cancel.png" title="cancel changes to '.$concluLabel.'" align="middle" />
                </td></tr></table>
                </form></span></td>';
        echo '<td valign="top" align="right" width="25%">';

// conclusion display
        echo '<span id="concluText" class="boxForm" style="display:none">';
        echo'<table width="100%" border="0" cellspacing="0" cellpadding="3">
                <tr>
                <td valign="top" ><fieldset class="content">
                <legend>'.$summaryLabel.'</legend>
                <label for="thesis_summary" class="instruct">'.$thesis_summaryLabel.'</label><br/>', $thesis_summary->nodeValue ,'
                <fieldset class="content">
                <legend>'.$argSumLabel.'</legend>
                <label for="arguments_summaries" class="optional">'.$argument_summaryLabel.'</label><br/>', $argument_summary->nodeValue ,'
                <br /><label for="consequences" class="optional">'.$consqLabel.'</label><br/>', $consequences->nodeValue ,'
                </fieldset><label for="closing" class="instruct">'.$closingLabel.'</label><br/>', $closing->nodeValue ,'
                </fieldset>
                <fieldset class="notepad">
                                <legend>'.$noteConLabel.'</legend>
                                <br/>', $noteCon->nodeValue ,' <br/>
                                </fieldset></td>
        </tr>
        </table></span>';
        echo '</td></tr></table></form></fieldset>';
        }
}

// saves changes to CONCLUSION and goes to display view (conView)
function saveCon($dom) {
if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
//       $file=$_POST['currentFile'];

        $root = $dom->getElementsByTagName('root');

        // retrieve the parent elements
        $conclusion = $dom->getElementsByTagName('conclusion')->item(0);

        //REPLACE thesis_summary ----------------------
        $thesis_summary=$dom->getElementsByTagName('thesis_summary')->item(0);
        if (isset($_POST['thesis_summary'])){
                $insertThesisSummary=$_POST['thesis_summary'];
                $content = nl2br($insertThesisSummary);
                $insertThesisSummary = trim($content);
                $thesis_summary->nodeValue = $insertThesisSummary;
        //	$insertThesisSummaryLabel = "thesis summary";
        //	$thesis_summary->setAttribute('label',''. $insertThesisSummaryLabel .'');
        }else{ //do nothing
        };

        //REPLACE argument_summary ----------------------
        $argument_summary=$dom->getElementsByTagName('argument_summary')->item(0);
        if (isset($_POST['argument_summary'])){
                $insertArgument_summary=$_POST['argument_summary'];
                $content = nl2br($insertArgument_summary);
                $insertArgument_summary = trim($content);
                $argument_summary->nodeValue = $insertArgument_summary;
        //	$insertArgument_summaryLabel = "summarize main arguments";
        //	$argument_summary->setAttribute('label',''. $insertArgument_summaryLabel .'');
        }else{ //do nothing
        };

        //REPLACE consequences ----------------------
        $consequences=$dom->getElementsByTagName('consequences')->item(0);
        if (isset($_POST['consequences'])){
                $insertConsequences=$_POST['consequences'];
                $content = nl2br($insertConsequences);
                $insertConsequences = trim($content);
                $consequences->nodeValue = $insertConsequences;
        //	$insertConsequencesLabel = "consequences";
        //	$consequences->setAttribute('label',''. $insertConsequencesLabel .'');
        }else{ //do nothing
        };

        //REPLACE closing ----------------------
        $closing=$dom->getElementsByTagName('closing')->item(0);
        if (isset($_POST['closing'])){
                $insertClosing=$_POST['closing'];
                $content = nl2br($insertClosing);
                $insertClosing = trim($content);
                $closing->nodeValue = $insertClosing;
        //	$insertClosingLabel = "closing";
        //	$closing->setAttribute('label',''. $insertClosingLabel .'');
        }else{ //do nothing
        };

        //REPLACE notepad for conclusion-----------------------------
        $noteCon = $conclusion->getElementsByTagName('notepad')->item(0);
        if (isset($_POST['noteCon'])){
                $insertNoteCon=$_POST['noteCon'];
                $content = nl2br($insertNoteCon);
                $insertNoteCon = trim($content);
                $noteCon->nodeValue = $insertNoteCon;
                $insertNoteId = "noteCon";
                $noteCon->setAttribute('id',''. $insertNoteId .'');
                }else{ //do nothing
        };

        //save the DOMDocument into the xml file
        $dom->save($file);

        //show text view
        conView($dom,$_POST);
        }

// ----------- end CONCLUSION ---------------------

// BEGIN LOADING functions ----------------------------------------------------

// loading the source xml file
// input from start.php -> getFile value=newFile or selectedFile OR newFileName value=$file from chooseFile form
// undefined index error correction
if(isset($_POST['essayFile'])){ $existingFile = $_POST['essayFile']; }
//$existingFile = $_POST['essayFile'];
if(isset($_POST['essayTemplate'])){ $existingTemplate = $_POST['essayTemplate']; }
//$existingTemplate= $_POST['essayTemplate'];
if(isset($_POST['newFileName'])){ $newFile = $_POST['newFileName']; }
//$newFile = $_POST['newFileName'];
if(isset($_POST['loadFile'])){ $loadFile = $_POST['loadFile']; }
// $loadFile = $_POST['loadFile'];

if(isset($_POST['loadFileTemp'])){ $loadFileTemp = $_POST['loadFileTemp']; }
//$loadFileTemp = $_POST['loadFileTemp'];

if(isset($_POST['saveAsFilename'])){ $saveAsFile = $_POST['saveAsFilename']; }
//$saveAsFile = $_POST['saveAsFilename'];
if(isset($_POST['currentFile'])){ $file = $_POST['currentFile']; }
//$currentFile = $_POST['currentFile'];


if(($_POST['getFile']== "selectedFile")) //button name
        {
   //load existing file from start page
   $file = basename($existingFile);
       }
        elseif(($_POST['getFile']== "selectedTemplate" ))
            {
            $file = basename($existingeTemplate);
            }
        elseif(($_POST['getFile']== "newFile" ))
        {
       // start new essay loading base essay file and saving with new name
        $dom = new domDocument;
        $dom->load('essayBase.xml');

        $file = basename($newFile);
        $dom->save($file);
        $dom->load($file);
        }
        elseif (isset ($_POST['loadFile'])) {
        //load existing file from essay page
        $file = basename($loadFile);
        }
         elseif (isset ($_POST['loadFileTemp'])) {
        //load existing file from essay page
        $file = basename($loadFileTemp);
        }
        elseif (isset ($_POST['saveAsFilename'])) {
        //save file under a new name and load it
         $dom = new domDocument;
            $dom->load($currentFile);
            $file = basename($saveAsFile);
            $dom->save($file);
            $dom->load($file);
        }
        else{
          // for inline save of changes
          $file=$_POST['currentFile'];
    //    exit('Failed to load XML. <a href="start.php">GO BACK</a>');
        };

//Begining of the code
$db= new SQLite3('database/user.db');
$role= getRole($_SESSION['name']);
$res= $db->query("select * from admins where name='".$file."';");
while($row= $res->fetchArray()){ 
	$templates= $row['templates'];
}
$dom = new domDocument;
$dom->loadXML($templates);

$dom = ($dom);
$root = $dom->getElementsByTagName('root');
$arguments =  $dom->getElementsByTagName('arguments');
$noId=0;

//html header
head();
recordTime();
newFileSelect();

// change filename

// CONTENT

// show appropriate display - edit form (*Form), graphic(*Display) or text view (*View)
// -- NAME --
if(isset($_POST['editName_x'])) //button name
{
        nameForm($dom, $_POST);
        }elseif(isset($_POST['cancelName_x'])){
        nameView($dom, $_POST);
        }else {
        saveName($dom,$_POST); //contains nameView
};
// -- end NAME --

//-- TITLE --
if(isset($_POST['editTitle_x']))
{
        titleForm($dom, $_POST);
        }elseif(isset($_POST['cancelTitle_x'])){
        titleDisplay($dom, $_POST);
        }else {
        saveTitle($dom,$_POST); //contains titleDisplay
};
// -- end TITLE --

// -- INTRODUCTION --
if(isset($_POST['editIntro_x']))
{
        introForm($dom, $_POST); // contains editing form
        }elseif(isset($_POST['viewIntro_x'])){
        introView($dom, $_POST);  // graphic
        }elseif(isset($_POST['cancelIntro_x'])){
        introView($dom, $_POST);  //contains text with help
        }
        else {
        saveIntro($dom, $_POST);  // contains display
        };
// -- end INTRODUCTION --


// -- ARGUMENTS --
if(isset($_POST['editArg_x'])) {
  argForm($dom);
 }
 elseif (isset ($_POST['saveArg_x'])) {

        saveArg($dom,$file); //contains argView
        }
 elseif(isset($_POST['viewGraph_x'])){
        argView($dom, $_POST); // graphic
        }
 elseif(isset($_POST['viewArg_x'])){
        argDisplay($dom, $_POST); // graphic
        }
 elseif(isset($_POST['cancelArg_x'])){
        argView($dom, $_POST); //contains text with help
        }
 elseif (isset ($_POST['moveArgDown_x'])) {
   moveArgDown($dom,$file); //contains argDisplay
 }
 elseif (isset ($_POST['addArg_x'])) {
   addArg($dom,$file); //contains argDisplay
 }
 elseif (isset ($_POST['deleteArg_x'])) {
   deleteArg($dom,$file); //contains argDisplay and deleteIfArg
 }
 else {
   argView($dom);
 }
// -- end ARGUMENTS --

// CONCLUSION
if(isset($_POST['editCon_x']))
{
        conForm($dom, $_POST); // contains editing form
        }elseif(isset($_POST['viewCon_x'])){
        conView($dom, $_POST);  //graphic
        }elseif(isset($_POST['cancelCon_x'])){
        conView($dom, $_POST); // contains text with help
        }
        else {
        saveCon($dom,$_POST); //contains conView
};

footer();

?>
