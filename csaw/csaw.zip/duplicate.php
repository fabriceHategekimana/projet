<?php

function getRole($name){
	$res= getUser($name)->fetchArray();
	$role= $res['role'];
    	return $role;
}

function getUser($name){
	$db = new SQLite3('database/user.db');
	$res = $db->query("select * from users where name like '".$name."'");
	return $res;
}

session_start();
if(isset($_POST['prompt_title']) and isset($_POST['prompt_description'])){
	$role= getRole($_SESSION['name']);
	if($role == "teacher"){
		//we gather the given title and description, we also implicitely get the file name
		$title= $_POST['prompt_title'];
		$description= $_POST['prompt_description'];
		$file= $_POST['file_name'];
		
		//we launch the database
		$db= new SQLite3('database/user.db');
		
		//we get the xml content of the file	
		$res= $db->query("select * from admins where name='".$file."'");
		while($row= $res->fetchArray()){ 
			$template= $row['templates'];
		}
		
		//we create a new teacher template in the database
		$db->query("insert into teachers (owner, name, standard, date_created, date_modified, description, status, templates, shared_group) values ('".$_SESSION['name']."', '".$title."', '".$file."', date('now'), date('now'), '".$description."', 'unshared', '".$template."','-')");
		header("Location:dashGenerator.php");
	}
	elseif($role == "student"){
		
		//we gather the given title, we also implicitely get the file name
		$title= $_POST['prompt_title'];
		$file= $_POST['file_name'];
		
		//we launch the database
		$db= new SQLite3('database/user.db');
		
		//we get the xml content of the file	
		$res= $db->query("select * from teachers where name='".$file."'");
		while($row= $res->fetchArray()){ 
			$template= $row['templates'];
		}
		
		//we create a new teacher template in the database
		$db->query("insert into students (owner, name, template_used, date_created, date_modified, status, essays) values ('".$_SESSION['name']."', '".$title."', '".$file."', date('now'), date('now'), 'unshared', '".$template."')");
		header("Location:dashGenerator.php");
	}
}
else{
	echo "duplicate.php\n";
}
?>
